import os

for d in ['src/tenxyte', 'docs']:
    for root, dirs, files in os.walk(d):
        for file in files:
            if file.endswith('.py') or file.endswith('.md'):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                new_content = content
                new_content = new_content.replace(' /api/', ' /api/v1/')
                new_content = new_content.replace('"/api/', '"/api/v1/')
                new_content = new_content.replace("'/api/", "'/api/v1/")
                
                if new_content != content:
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(new_content)
                    print(f'Updated {filepath}')
