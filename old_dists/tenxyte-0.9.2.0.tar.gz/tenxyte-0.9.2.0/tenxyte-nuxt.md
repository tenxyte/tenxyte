# Plan de Développement de la Librairie Nuxt.js : `@tenxyte/nuxt`

Ce document définit la stratégie complète, l'architecture et la roadmap pour la création du paquet npm `@tenxyte/nuxt`. En complément de `@tenxyte/vue` (qui cible les applications client-side strictes), ce SDK est architecturé spécifiquement pour propulser l'authentification Tenxyte dans un environnement **Server-Side Rendering (SSR)** ou **Static Site Generation (SSG)** géré par Nuxt 3 (et son moteur serveur, Nitro).

---

## 1. Objectif et Vision Globale

**Vision :** Fournir le chaînon manquant pour l'écosystème Vue on-the-edge. Le but est de garantir des rendus de pages instantanés, débarrassés de tout problème d'asynchronisme de session, en s'appuyant rigoureusement sur les **HttpOnly Cookies** lus par le serveur (Nitro) avant même que le HTML ne soit envoyé au navigateur.

**Principes architecturaux :**
- **Nitro First :** L'authentification, le rafraîchissement des tokens et les protections de routes s'exécutent en amont dans les middlewares métiers de Nitro.
- **Composition et `useState` :** Hydratation fluide de la session (`user`, `isAuthenticated`) depuis le serveur vers le client sans déclencher de warnings d'hydratation (Hydration Mismatch).
- **Nuxt Module Officiel :** Le paquet est un module Nuxt certifié (`defineNuxtModule`). Les développeurs n'ont plus qu'à l'ajouter dans l'array `modules` de `nuxt.config.ts`.
- **Ré-export de Vue :** Côté client, le module s'appuie et ré-exporte les utilitaires de `@tenxyte/vue`.

---

## 2. Structure du Dépôt (Module Nuxt)

Nom du paquet NPM envisagé : `@tenxyte/nuxt`

```text
tenxyte-nuxt/
├── package.json
├── src/
│   ├── module.ts              # Le Nuxt Module (point d'entrée principal setup)
│   ├── runtime/               # Code injecté dans l'app finale
│   │   ├── server/            # Exécuté via Nitro (API et Middlewares serveurs)
│   │   │   └── middleware/
│   │   │       └── auth.ts    # Nitro eventHandler interceptant les cookies/refresh
│   │   ├── plugin.ts          # Nuxt Plugin (hydration SSR vers Client)
│   │   ├── composables/       # Auto-imports Nuxt (useAuth, useUser)
│   │   └── middleware/        # Nuxt Route Middlewares (ex: definePageMeta({ middleware: 'auth' }))
├── playground/                # Une application Nuxt de test intégrée au dépôt
└── build.config.ts          # Configuration de compilation (unbuild)
```

---

## 3. Le Paradis Nuxt 3 : SSR et Cookies

Le SDK a le même mode de fonctionnement strict que Next.js. **Les Jetons JSON Web (JWT) vivent et voyagent exclusivement sous forme de cookies sécurisés.**

### A. Flux de Lecture Serveur (Nitro Middleware)
Lorsqu'un utilisateur visite une page protégée (`/dashboard`) :
1. Le navigateur d'emblée envoie le cookie `access_token` attaché à la requête de page HTML.
2. Le `middleware.ts` dans `runtime/server` lit the cookie (`getCookie(event)`).
3. Si le token est valide, l'objet utilisateur est extrait ou récupéré vers une variable de contexte interne Nitro.
4. **Si expiré :** Nitro fait discrètement un `POST /api/v1/auth/refresh/` vers Tenxyte Django, reçoit les nouveaux JWT, attache le nouveau cookie (`setCookie(event)`) sur la réponse HTTP sortante... l'HTML se génère avec l'utilisateur connecté sans aucun bug.

### B. Le Plugin d'Hydratation
Pour que Vue 3 (Client-side) ait conscience de cet utilisateur vérifié côté serveur, le SDK utilise un *Nuxt Plugin*.

```typescript
// src/runtime/plugin.ts
import { defineNuxtPlugin, useState } from '#app'

export default defineNuxtPlugin(async (nuxtApp) => {
  // useState permet de synchroniser l'état initial Serveur -> Nav
  const session = useState('tx-session', () => null)

  if (process.server) {
    // Lecture depuis le header de requête sur le serveur
    session.value = nuxtApp.ssrContext?.event.context.tenxyteUser
  }
  
  // On injecte ça dans le Core JS/Vue (instancié côté client après hydratation)
  const tx = createTenxyteClient({...});
  tx.hydrate(session.value);

  return {
    provide: { tenxyte: tx }
  }
})
```

---

## 4. Expérience Développeur (L'API)

### L'Installation en 1 Ligne :
La magie du module (grâce au nuxt kit) fait que rien n'est à importer manuellement.

```typescript
// nuxt.config.ts
export default defineNuxtConfig({
  modules: ['@tenxyte/nuxt'],
  tenxyte: {
    baseURL: process.env.API_URL || 'http://api.mon-site.com/v1',
    appKey: process.env.APP_KEY,
  }
})
```

### Route Middleware (Protection des pages)
La librairie ajoute un middleware de route nommé global. Il suffit de l'activer dans le setup du Vue Component : 

```vue
<!-- pages/admin.vue -->
<script setup>
// Plus besoin d'importer ! Nuxt auto-importe ce qui vient de 'composables/'
const { user } = useUser();

definePageMeta({
  middleware: ['tenxyte-auth'], // Géré automatiquement par @tenxyte/nuxt
  roles: ['admin', 'manager']
})
</script>

<template>
  <h1>Console Administrative de {{ user.email }}</h1>
</template>
```

### Server API 
Si l'utilisateur déclare ses *propres* endpoint Nitro (`server/api/my-data.ts`), il obtiendra une utilité backend :

```typescript
// server/api/private-data.ts
import { requireTenxyteSession } from '#tenxyte/server';

export default defineEventHandler(async (event) => {
  // Vérifie le cookie instantanément ou renvoie 401
  const user = await requireTenxyteSession(event);
  
  return { secret: `Salut ${user.last_name}` };
});
```

---

## 5. Roadmap du Développement (`@tenxyte/nuxt`)

*Prérequis : Le Paquet `@tenxyte/vue` est publié.*

### Phase 1 : Scaffolding & Initialisation (Semaine 1)
- Création du projet via le standard (Nuxt Module Builder).
- Définition des options du module (`nuxt.config.ts` integration).
- Création du plugin SSR de base et synchronisation via `useState()`.

### Phase 2 : Middlewares Serveur & Rafraîchissement (Semaine 2)
- C'est le nœud de l'architecture. Implémenter le middleware Nitro qui intercepte les requêtes (pages et API) pour décrypter le validité des tokens.
- Développer la rotation silencieuse (Refresh Token Flow) entre Nitro Node.js et Django. Étape particulièrement délicate en SSR puisqu'il faut muter les Headers de réponse en même temps qu'on fait l'action asynchrone HTTP vers Python.

### Phase 3 : Route Middlewares & Injection Client (Semaine 3)
- Créer le `tenxyte-auth` route middleware.
- Configurer les auto-imports via Nuxt Kit (`addImportsDir`). Plus de `import { useAuth } from ...` nécessaire : ce sera standard.

### Phase 4 : Documentation & Tests (Semaine 4)
- Couvrir les fonctions serveurs complexes avec la suite Vitest spécifique à Nuxt (`@nuxt/test-utils`).
- Rédaction du guide d'implémentation (avec exemples sur la gestion des domaines/sous-domaines CORS pour que le cookie HTTP transite correctement).
- Publication sur npm.

---

### Conclusion

Le développement de `@tenxyte/nuxt` complète de manière exhaustive la branche Vue.js de votre écosystème. Bien que son fonctionnement "App Developer" repose sur les Hooks de la version réactive (`@tenxyte/vue`), l'envergure du code derrière un Module Nuxt est majoritairement du **Node.js (Nitro)** sécuritaire pour extraire l'authentification côté serveur. L'alliance d'un Django robuste, d'un rendu SSR rapide, d'une hydratation automatique via Nuxt, et d'un état réactif via Vue offre la pile technologique ultime pour un produit SaaS moderne et protégé.
