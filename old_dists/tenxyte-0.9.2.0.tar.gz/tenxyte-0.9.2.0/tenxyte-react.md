# Plan de Développement de la Librairie React : `@tenxyte/react`

Ce document définit la stratégie complète, l'architecture et la roadmap pour la création du paquet npm `@tenxyte/react`. Cette librairie s'adresse aux développeurs construisant des applications **Single Page Applications (SPA)** avec React (via Vite, Create React App, etc.) et fonctionnant strictement côté client (Client-Side Rendering). 

Elle est conçue comme une surcouche idiomatique (React Hooks & Context) au dessus du moteur agnostique `@tenxyte/js-core`.

---

## 1. Objectif et Vision Globale

**Vision :** Offrir l'expérience développeur (DX) la plus fluide possible dans l'écosystème React, en s'occupant automatiquement de la gestion de l'état global (authentification, profil, rôles) et des redondus (re-renders) liés aux changements de l'API Tenxyte.

**Principes architecturaux :**
- **Dépendance forte au Core :** `@tenxyte/react` n'effectue **aucun** appel `fetch` lui-même. Il instancie le SDK `@tenxyte/js-core` et écoute ses événements.
- **Hook-First Approach :** Tout est accessible via de petits hooks spécialisés (ex: `useAuth`, `useUser`, `useOrganization`).
- **Context API :** Un Provider global enveloppe l'application et maintient l'état réactif de la session utilisateur.
- **Headless (Sans UI) :** La librairie ne fournit *pas* de composants visuels complets (boutons, formulaires). Elle délègue cela au développeur ou au futur `@tenxyte/html-components`.

---

## 2. Structure du Dépôt

Nom du paquet NPM envisagé : `@tenxyte/react`

```text
tenxyte-react/
├── package.json
├── tsconfig.json          # Configuré pour JSX/TSX
├── src/
│   ├── index.ts           # Exports publics
│   ├── context/
│   │   └── TenxyteProvider.tsx  # Le composant <TenxyteProvider> de base
│   ├── hooks/
│   │   ├── useTenxyte.ts        # Accès direct à l'instance @tenxyte/js-core
│   │   ├── useAuth.ts           # { isAuthenticated, login, logout, isLoading }
│   │   ├── useUser.ts           # Profil de l'utilisateur ({ user, refresh })
│   │   ├── usePermissions.ts    # RBAC: { hasRole, hasPermission }
│   │   └── useB2B.ts            # { organization, switchOrg }
│   ├── components/
│   │   ├── ProtectedRoute.tsx   # Wrapper de redirection (Guards)
│   │   └── RoleGate.tsx         # Affichage conditionnel basé sur RBAC
│   └── utils/
│       └── ssr.ts               # Helpers pour alerter si la librairie est utilisée par erreur en SSR
├── tests/
│   └── hooks.test.tsx     # Tests avec @testing-library/react-hooks
└── dist/                  # Build (ESM, CJS, d.ts)
```

---

## 3. Fonctionnement Cœur : Le Provider

Toute application devra envelopper sa racine avec le `<TenxyteProvider>`. Ce Provider :
1. Initialise l'instance du `@tenxyte/js-core`.
2. Gère le cycle de rafraîchissement au montage de l'application (Tente de recharger la session via le *refresh_token* stocké si l'onglet a été fermé).
3. Maintient un état global réactif (`isLoading`, `isAuthenticated`, `user`).

```tsx
// Exemple d'intégration (main.tsx ou App.tsx) :

import { TenxyteProvider } from '@tenxyte/react';

function App() {
  return (
    <TenxyteProvider
      baseURL="https://api.mon-projet.com/api/v1"
      appKey="MON_APP_KEY"
      storage="localStorage"  // Directement transféré au js-core
    >
      <MaRouteurApp />
    </TenxyteProvider>
  );
}
```

---

## 4. L'API (Les Hooks)

Les développeurs interagiront à 99% avec ces Hooks. L'avantage du Provider est qu'il mettra automatiquement à jour l'UI quand les données changent (ex: si l'accès expire, `isAuthenticated` passe à `false` et l'UI réagit instantanément).

### `useAuth()`
Expose l'état actuel et les méthodes de connexion d'authentification.

```tsx
const { isAuthenticated, isLoading, login, logout, error } = useAuth();

// Utilisation typique :
// <button onClick={() => login(email, password)}>Connexion</button>
```

### `useUser()`
Met à disposition le profil local (extrait du JWT pour éviter les requêtes API inutiles) ou rafraîchi via `/me/`.

```tsx
const { user, refetchProfile } = useUser();

// <div>Bienvenue {user.first_name} ! </div>
```

### `usePermissions()` / `useRoles()`
Pour gérer le RBAC (Role-Based Access Control) nativement dans React.

```tsx
const { hasRole, canView } = usePermissions();

if (!hasRole('admin')) {
  return <Navigate to="/dashboard" />;
}
```

Le fait d'avoir le `@tenxyte/js-core` en base permet à ces fonctions d'être performantes (lecture depuis le Payload JWT décodé et caché en mémoire).

---

## 5. Gardiens d'UI et de Route (Components)

Même si la librairie est "Headless", elle fournira quelques Wrappers utilitaires pour simplifier le JSX.

### `<ProtectedRoute>`
Pour sécuriser facilement des pages avec `react-router-dom`.

```tsx
<Route path="/admin" element={
  <ProtectedRoute fallback={<Navigate to="/login" />}>
    <AdminPanel />
  </ProtectedRoute>
} />
```

### `<RoleGate>`
Permet d'afficher ou masquer des portions de page selon les droits. C'est l'équivalent des balises templates Django `{% if 'admin' in user_roles %}`.

```tsx
<RoleGate requireRole="manager" requireAll={true}>
  <DeleteButton />
</RoleGate>
```

---

## 6. Roadmap du Développement (`@tenxyte/react`)

*Prérequis : Le Paquet `@tenxyte/js-core` doit être publié au minimum en version beta (ex: `1.0.0-beta.1`).*

### Phase 1 : Contexte & État Initial (Semaine 1)
- Mise en place du dépôt React (TypeScript) et configuration de Vite/Rollup pour packager une librairie.
- Développement du `<TenxyteProvider>`.
- Intégration du cycle de vie de session avec le JS Core (gérer la restauration de token `onMount`).

### Phase 2 : Les Hooks (Semaine 2)
- Implémentation de `useAuth()`.
- Implémentation de `useUser()` et gestion réactive du changement de profil.
- Tests complets avec React Testing Library (mock du JS Core).

### Phase 3 : Sécurité, Roles et B2B (Semaine 3)
- Implémentation des Hooks RBAC (`usePermissions`, `useRole`).
- Implémentation des Hooks B2B (`useOrganization`, `useB2B`) si la gestion multi-tenant est active dans Tenxyte.
- Création des composants de contrôle d'accès (`<RoleGate>`, `<ProtectedRoute>`).

### Phase 4 : Documentation & Intégration (Semaine 4)
- Création d'un dossier `examples/vite-react-ts` prouvant que tout fonctionne de bout en bout avec l'API Django de test.
- Rédaction de la documentation avec TSDoc et README.
- Publication sur NPM.

---

### Conclusion

La librairie `@tenxyte/react` agira comme un **Data Layer (Couche de données) réactif**. Le développeur React n'aura jamais à se soucier de headers d'autorisation, de tokens à rafraîchir en tâche de fond, ni d'appels `fetch`. L'objectif est de transformer une implémentation sécurité backend complexe en une simple syntaxe `<RoleGate>` et de simples conditions if `isAuthenticated` dans les composants React.
