# Plan de Création du Dépôt `package/html-components` pour Tenxyte

Ce document définit la stratégie complète, l'architecture et la roadmap pour la création du dépôt `tenxyte-html-components`. L'objectif est de fournir un ensemble de composants UI "prêts à l'emploi", agnostiques (Vanilla JS / Web Components) ou adaptables (HTML/CSS purs) qui s'intègrent nativement avec toutes les fonctionnalités backend du framework Tenxyte.

---

## 1. Objectif et Vision Globale

**Vision :** Permettre aux développeurs frontend ou full-stack de construire une interface d'authentification robuste et sécurisée en quelques minutes, en appelant simplement des composants HTML prédéfinis qui dialoguent automatiquement avec l'API REST de Tenxyte.

**Principes architecturaux :**
- **Framework Agnostic :** Utilisation de Web Components (`<template>`, Custom Elements) ou de HTML/CSS/Vanilla JS classique pour être compatible avec Django Templates, React, Vue, Angular, etc.
- **Zéro Configuration (Optionnel) :** Les composants gèrent eux-mêmes l'état (JWT, accès tokens, headers `X-Access-Key` et `X-Access-Secret`).
- **Accessibilité (a11y) :** Conformité avec les standards WCAG (navigation clavier, ARIA attributes).
- **Thémable :** Utilisation de variables CSS (Custom Properties) pour adapter facilement les composants à la charte graphique de n'importe quelle marque.

---

## 2. Structure du Dépôt

Nom du paquet NPM envisagé : `@tenxyte/html-components`

```text
tenxyte-html-components/
├── package.json
├── README.md
├── src/
│   ├── lib/                   # Wrappers ou initialisation de @tenxyte/js-core
│   ├── components/            # Code source des Web Components
│   │   ├── auth/              # Login, Register, Social
│   │   ├── security/          # 2FA, Passkeys, OTP
│   │   ├── b2b/               # Organisation switcher, roles
│   │   └── ui/                # Boutons, inputs, alertes de base
│   ├── styles/                # Variables CSS, thèmes par défaut
│   └── index.js               # Entrypoint d'export
├── dist/                      # Fichiers packagés (UMD, ESM, CSS locaux)
├── examples/                  # Exemples d'intégration (Django, Vanilla, React)
├── docs/                      # Histoire des composants (Storybook ou équivalent)
└── tests/                     # Tests E2E (Playwright ou Cypress)
```

---

## 3. Intégration des Fonctionnalités Tenxyte

Le projet exposera une suite de composants couvrant l'ensemble du périmètre fonctionnel de l'API Tenxyte.

### A. Authentification Core (`/api/v1/auth/`)
- **`<tx-login>`** : Gère l'authentification par email/mot de passe, sauvegarde automatique du JWT, et fallback vers le mode 2FA si requis par le backend.
- **`<tx-register>`** : Formulaire d'inscription gérant la validation frontend et les réponses d'API (ex: "vérification email requise").
- **`<tx-social-login>`** : Boutons de connexion Oauth2 (Google, GitHub, Microsoft, Facebook) interconnectés avec les routes `/auth/social/*`.
- **`<tx-magic-link>`** : Formulaires de requête et de validation pour l'authentification sans mot de passe.

### B. Sécurité Avancée
- **`<tx-passkey-auth>`** : Bouton et flux WebAuthn transparent (Begin -> Complete) pour l'inscription et la connexion via biométrie.
- **`<tx-2fa-setup>`** : Affiche le QR Code (généré via la route API), demande le code TOTP de confirmation.
- **`<tx-otp-verify>`** : Composant de validation de code à 6 chiffres envoyé par Email ou SMS (Twilio/SendGrid).
- **`<tx-password-reset>`** : Flux de demande et de redéfinition avec vérification de la force du mot de passe liée aux règles de Tenxyte (ex: blocage des mdp blacklistés HIBP).

### C. Gestion des Accès et Profil (RBAC)
- **`<tx-user-profile>`** : Tableau de bord basique permettant la modification des informations utilisateur et la révocation des sessions actives.
- **`<tx-protected>`** : *Wrapper* conditionnel (ex: `<tx-protected require-role="admin"> ... </tx-protected>`) qui masque ou affiche son contenu en fonction des claims du JWT ou des endpoints `/me/roles/`.

### D. Organisations et Multi-tenant (B2B)
- **`<tx-org-switcher>`** : Menu déroulant pour basculer facilement entre les organisations de l'utilisateur (mettant à jour le contexte global).
- **`<tx-org-invitation>`** : Formulaire pour inviter des membres par email et leur assigner des rôles (Admin, Member, etc.).

---

## 4. Implémentation et Dépendance au Core SDK (`@tenxyte/js-core`)

Pour garantir l'évolutivité et éviter la duplication de code, les composants HTML doivent **impérativement utiliser le SDK Tenxyte JS (`@tenxyte/js-core`) comme dépendance principale**.
Le développement de `@tenxyte/js-core` doit donc être réalisé **AVANT** celui de `html-components`. Les Web Components se contenteront d'être une surcouche UI qui instancie et appelle les méthodes métier du SDK Core.

Responsabilités déléguées à `@tenxyte/js-core` et exploitées par les composants :
1. **API Interceptor :** Gestion automatique de l'injection des headers :
   - `Authorization: Bearer <access_token>`
   - `X-Access-Key: <app_key>`
   - `X-Access-Secret: <app_secret>`
2. **Refresh Token Flow :** Interception transparente des erreurs `401 Unauthorized` pour appeler `/api/v1/auth/refresh/` et rejouer la requête modifiée.
3. **Session State :** Stockage hybride (au choix du développeur) :
   - En mémoire (sécurité stricte, effacé au refresh).
   - LocalStorage (pratique pour SPAs).
   - Prise en charge des cookies `HttpOnly` (recommandé pour la prod avec Django).
4. **Rate Limiting & Lockout :** Si une réponse `429 Too Many Requests` ou un compte bloqué est détecté, tous les composants propagent une alerte visuelle et désactivent les boutons d'action.

---

## 5. Personnalisation (Theming)

Le CSS sera construit autour de variables CSS au niveau `:root` pour faciliter l'intégration :

```css
:root {
  --tx-primary-color: #2563eb;
  --tx-border-radius: 6px;
  --tx-font-family: 'Inter', system-ui, sans-serif;
  --tx-error-color: #dc2626;
  --tx-input-bg: #ffffff;
  --tx-text-color: #1f2937;
}
```

Les développeurs pourront encapsuler les composants dans un conteneur et redéfinir ces variables.

---

## 6. Roadmap du Dépôt

### Phase 1 : Infrastructure & Authentification de Base (Semaines 1-2)
- Configuration du dépôt (NPM, Vite pour Web Components) et installation de `@tenxyte/js-core`.
- Wrapper d'initialisation pour connecter les composants à l'instance globale du client JS.
- Composants `<tx-login>`, `<tx-register>`, `<tx-logout>` interfacés avec le SDK.
- Composants UI de base (inputs supervisés avec messages d'erreur de l'API).

### Phase 2 : Sécurité & Oauth (Semaines 3-4)
- Implémentation de la rotation de token (Refresh logic).
- Développement des composants `<tx-social-login>` et `<tx-magic-link>`.
- Intégration du flux 2FA (TOTP) : activation, désactivation, validation lors du login.

### Phase 3 : Futur-Proof & B2B (Semaines 5-6)
- Implémentation WebAuthn / Passkeys (`<tx-passkey-auth>`).
- Composants de gestion d'organisation (`<tx-org-switcher>`).
- Composants RBAC (Rôles & Permissions UI).

### Phase 4 : Documentation & Qualité (Semaine 7)
- Storybook (Documentation interactive listant les props, events et slots).
- Tests E2E automatisés (Cypress).
- Publication de la version `1.0.0` sur NPM.
- Ajout d'une Github Action pour le linting (ESLint, Prettier) et les tests automatiques.

---

### Conclusion

La création de `package/html-components` représente la brique front-end ultime pour compléter l'offre "Production-ready [...] in minutes" de Tenxyte. En fournissant ces éléments visuels prêts à consommer l'API avancée (JWT, 2FA, Passkeys, Multi-app), Tenxyte deviendra une solution *full-stack* incontournable.
