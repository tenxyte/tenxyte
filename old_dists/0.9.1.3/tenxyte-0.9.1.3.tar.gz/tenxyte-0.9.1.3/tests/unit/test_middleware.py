"""
Tests unitaires pour le middleware ApplicationAuthMiddleware.

Vérifie que les settings TENXYTE_EXEMPT_PATHS et TENXYTE_EXACT_EXEMPT_PATHS
sont correctement appliqués.
"""

from tenxyte.conf import auth_settings
api_prefix = auth_settings.API_PREFIX

import pytest
from unittest.mock import Mock, patch, MagicMock
from django.http import HttpResponse, JsonResponse
from django.test import RequestFactory, override_settings




@pytest.fixture
def request_factory():
    return RequestFactory()


@pytest.fixture
def get_response():
    """Simule une vue qui retourne 200."""
    def _get_response(request):
        return HttpResponse("OK", status=200)
    return _get_response


@pytest.fixture
def middleware(get_response):
    return __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)


class TestExemptPathsPrefixMatch:
    """Test que TENXYTE_EXEMPT_PATHS (prefix match) est appliqué."""

    def test_default_admin_path_is_exempt(self, middleware, request_factory):
        """Le chemin /admin/ est exempté par défaut."""
        request = request_factory.get('/admin/')
        response = middleware(request)
        assert response.status_code == 200

    def test_default_admin_subpath_is_exempt(self, middleware, request_factory):
        """Les sous-chemins de /admin/ sont exemptés par défaut (prefix match)."""
        request = request_factory.get('/admin/login/')
        response = middleware(request)
        assert response.status_code == 200

    def test_default_health_path_is_exempt(self, middleware, request_factory):
        """Le chemin /api/v1/health/ est exempté par défaut."""
        request = request_factory.get(f'{api_prefix}/health/')
        response = middleware(request)
        assert response.status_code == 200

    def test_default_docs_path_is_exempt(self, middleware, request_factory):
        """Le chemin /api/v1/docs/ est exempté par défaut."""
        request = request_factory.get(f'{api_prefix}/docs/')
        response = middleware(request)
        assert response.status_code == 200

    def test_non_exempt_path_requires_auth(self, middleware, request_factory):
        """Un chemin non exempté requiert l'authentification application."""
        request = request_factory.get(f'{api_prefix}/users/')
        response = middleware(request)
        assert response.status_code == 401

    @override_settings(TENXYTE_EXEMPT_PATHS=[
        '/admin/',
        f'{api_prefix}/health/',
        f'{api_prefix}/docs/',
        f'{api_prefix}/public/',
    ])
    def test_custom_exempt_paths_are_applied(self, get_response, request_factory):
        """Les chemins personnalisés dans TENXYTE_EXEMPT_PATHS sont appliqués."""
        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)

        # /api/v1/public/ doit être exempté
        request = request_factory.get(f'{api_prefix}/public/')
        response = mw(request)
        assert response.status_code == 200

        # /api/v1/public/some-resource/ doit aussi être exempté (prefix)
        request = request_factory.get(f'{api_prefix}/public/some-resource/')
        response = mw(request)
        assert response.status_code == 200

    @override_settings(TENXYTE_EXEMPT_PATHS=[
        '/admin/',
        f'{api_prefix}/health/',
        f'{api_prefix}/docs/',
        f'{api_prefix}/public/',
    ])
    def test_custom_exempt_paths_non_listed_still_requires_auth(self, get_response, request_factory):
        """Un chemin non listé dans les paths personnalisés requiert toujours l'auth."""
        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)

        request = request_factory.get(f'{api_prefix}/users/')
        response = mw(request)
        assert response.status_code == 401

    @override_settings(TENXYTE_EXEMPT_PATHS=['/custom/'])
    def test_overriding_removes_defaults(self, get_response, request_factory):
        """Surcharger TENXYTE_EXEMPT_PATHS remplace les défauts, pas les complète."""
        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)

        # /custom/ est exempté
        request = request_factory.get('/custom/path/')
        response = mw(request)
        assert response.status_code == 200

        # /admin/ N'est plus exempté car les défauts sont remplacés
        request = request_factory.get('/admin/')
        response = mw(request)
        assert response.status_code == 401


class TestExactExemptPaths:
    """Test que TENXYTE_EXACT_EXEMPT_PATHS (exact match) est appliqué."""

    def test_default_api_v1_root_is_exempt(self, middleware, request_factory):
        """Le chemin exact /api/v1/ est exempté par défaut."""
        request = request_factory.get(f'{api_prefix}/')
        response = middleware(request)
        assert response.status_code == 200

    def test_exact_match_does_not_match_subpaths(self, middleware, request_factory):
        """Le match exact ne s'applique PAS aux sous-chemins."""
        request = request_factory.get(f'{api_prefix}/something/')
        response = middleware(request)
        assert response.status_code == 401

    @override_settings(TENXYTE_EXACT_EXEMPT_PATHS=[f'{api_prefix}/', '/'])
    def test_custom_exact_exempt_paths_are_applied(self, get_response, request_factory):
        """Les chemins exacts personnalisés dans TENXYTE_EXACT_EXEMPT_PATHS sont appliqués."""
        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)

        # / doit être exempté
        request = request_factory.get('/')
        response = mw(request)
        assert response.status_code == 200

        # /api/v1/ doit aussi être exempté
        request = request_factory.get(f'{api_prefix}/')
        response = mw(request)
        assert response.status_code == 200

    @override_settings(TENXYTE_EXACT_EXEMPT_PATHS=[f'{api_prefix}/', '/'])
    def test_custom_exact_exempt_subpath_not_exempt(self, get_response, request_factory):
        """Les sous-chemins ne sont PAS exemptés par match exact."""
        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)

        request = request_factory.get(f'{api_prefix}/users/')
        response = mw(request)
        assert response.status_code == 401

    @override_settings(TENXYTE_EXACT_EXEMPT_PATHS=['/'])
    def test_overriding_exact_removes_defaults(self, get_response, request_factory):
        """Surcharger TENXYTE_EXACT_EXEMPT_PATHS remplace les défauts."""
        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)

        # / est exempté
        request = request_factory.get('/')
        response = mw(request)
        assert response.status_code == 200

        # /api/v1/ N'est plus exempté (défaut remplacé)
        request = request_factory.get(f'{api_prefix}/')
        response = mw(request)
        assert response.status_code == 401


class TestFullUserSettings:
    """
    Test de la configuration complète fournie par l'utilisateur:

    TENXYTE_EXEMPT_PATHS = [
        '/admin/',
        f'{api_prefix}/health/',
        f'{api_prefix}/docs/',
        f'{api_prefix}/public/',
    ]

    TENXYTE_EXACT_EXEMPT_PATHS = [
        f'{api_prefix}/',
        '/',
    ]
    """

    @override_settings(
        TENXYTE_EXEMPT_PATHS=[
            '/admin/',
            f'{api_prefix}/health/',
            f'{api_prefix}/docs/',
            f'{api_prefix}/public/',
        ],
        TENXYTE_EXACT_EXEMPT_PATHS=[
            f'{api_prefix}/',
            '/',
        ],
    )
    def test_all_prefix_paths_exempt(self, get_response, request_factory):
        """Tous les chemins préfixés sont exemptés."""
        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)

        exempt_paths = [
            '/admin/',
            '/admin/login/',
            '/admin/dashboard/stats/',
            f'{api_prefix}/health/',
            f'{api_prefix}/health/status/',
            f'{api_prefix}/docs/',
            f'{api_prefix}/docs/swagger/',
            f'{api_prefix}/public/',
            f'{api_prefix}/public/terms/',
        ]
        for path in exempt_paths:
            request = request_factory.get(path)
            response = mw(request)
            assert response.status_code == 200, f"Path {path} should be exempt but got {response.status_code}"

    @override_settings(
        TENXYTE_EXEMPT_PATHS=[
            '/admin/',
            f'{api_prefix}/health/',
            f'{api_prefix}/docs/',
            f'{api_prefix}/public/',
        ],
        TENXYTE_EXACT_EXEMPT_PATHS=[
            f'{api_prefix}/',
            '/',
        ],
    )
    def test_all_exact_paths_exempt(self, get_response, request_factory):
        """Tous les chemins exacts sont exemptés."""
        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)

        exact_exempt = ['/', f'{api_prefix}/']
        for path in exact_exempt:
            request = request_factory.get(path)
            response = mw(request)
            assert response.status_code == 200, f"Path {path} should be exempt but got {response.status_code}"

    @override_settings(
        TENXYTE_EXEMPT_PATHS=[
            '/admin/',
            f'{api_prefix}/health/',
            f'{api_prefix}/docs/',
            f'{api_prefix}/public/',
        ],
        TENXYTE_EXACT_EXEMPT_PATHS=[
            f'{api_prefix}/',
            '/',
        ],
    )
    def test_protected_paths_require_auth(self, get_response, request_factory):
        """Les chemins non exemptés requièrent l'authentification."""
        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)

        protected_paths = [
            f'{api_prefix}/users/',
            f'{api_prefix}/auth/login/',
            f'{api_prefix}/auth/register/',
            f'{api_prefix}/private/data/',
            f'{api_prefix}//something/',
            '/other/',
        ]
        for path in protected_paths:
            request = request_factory.get(path)
            response = mw(request)
            assert response.status_code == 401, f"Path {path} should require auth but got {response.status_code}"

    @override_settings(
        TENXYTE_EXEMPT_PATHS=[
            '/admin/',
            f'{api_prefix}/health/',
            f'{api_prefix}/docs/',
            f'{api_prefix}/public/',
        ],
        TENXYTE_EXACT_EXEMPT_PATHS=[
            f'{api_prefix}/',
            '/',
        ],
    )
    def test_error_response_format(self, get_response, request_factory):
        """Vérifie le format de la réponse d'erreur 401."""
        import json
        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)

        request = request_factory.get(f'{api_prefix}/users/')
        response = mw(request)
        assert response.status_code == 401
        data = json.loads(response.content)
        assert data['code'] == 'APP_AUTH_REQUIRED'
        assert 'error' in data


class TestApplicationAuthDisabled:
    """Test que TENXYTE_APPLICATION_AUTH_ENABLED=False désactive tout."""

    @override_settings(TENXYTE_APPLICATION_AUTH_ENABLED=False)
    def test_disabled_auth_passes_all_requests(self, get_response, request_factory):
        """Quand l'auth application est désactivée, toutes les requêtes passent."""
        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(get_response)

        paths = [f'{api_prefix}/users/', '/admin/', '/anything/', '/']
        for path in paths:
            request = request_factory.get(path)
            response = mw(request)
            assert response.status_code == 200, f"Path {path} should pass when auth disabled"

    @override_settings(TENXYTE_APPLICATION_AUTH_ENABLED=False)
    def test_disabled_auth_sets_application_none(self, get_response, request_factory):
        """Quand l'auth est désactivée, request.application est None."""
        captured = {}

        def capturing_response(request):
            captured['application'] = getattr(request, 'application', 'NOT_SET')
            return HttpResponse("OK")

        mw = __import__('tenxyte.middleware', fromlist=['ApplicationAuthMiddleware']).ApplicationAuthMiddleware(capturing_response)
        request = request_factory.get(f'{api_prefix}/users/')
        mw(request)

        assert captured['application'] is None


# ─── CORSMiddleware ───────────────────────────────────────────────────────────




class TestCORSMiddleware:
    """Tests de CORSMiddleware : preflight, origines autorisées/refusées, disabled."""

    @override_settings(
        TENXYTE_CORS_ENABLED=True,
        TENXYTE_CORS_ALLOW_ALL_ORIGINS=True
    )
    def test_preflight_returns_200_with_cors_headers(self):
        mw = __import__('tenxyte.middleware', fromlist=['CORSMiddleware']).CORSMiddleware(lambda r: HttpResponse("OK"))
        from django.test import RequestFactory
        req = RequestFactory().options(f"{api_prefix}/test/", HTTP_ORIGIN="https://example.com")
        response = mw(req)
        assert response.status_code == 200
        assert response.get("Access-Control-Allow-Origin") == "https://example.com"

    @override_settings(
        TENXYTE_CORS_ENABLED=True,
        TENXYTE_CORS_ALLOW_ALL_ORIGINS=False,
        TENXYTE_CORS_ALLOWED_ORIGINS=["https://allowed.com"]
    )
    def test_disallowed_origin_has_no_cors_headers(self):
        mw = __import__('tenxyte.middleware', fromlist=['CORSMiddleware']).CORSMiddleware(lambda r: HttpResponse("OK"))
        from django.test import RequestFactory
        req = RequestFactory().get(f"{api_prefix}/test/", HTTP_ORIGIN="https://evil.com")
        response = mw(req)
        assert response.get("Access-Control-Allow-Origin") is None

    @override_settings(TENXYTE_CORS_ENABLED=False)
    def test_disabled_cors_passes_through_without_headers(self):
        mw = __import__('tenxyte.middleware', fromlist=['CORSMiddleware']).CORSMiddleware(lambda r: HttpResponse("OK"))
        from django.test import RequestFactory
        req = RequestFactory().options(f"{api_prefix}/test/", HTTP_ORIGIN="https://example.com")
        response = mw(req)
        # Réponse de la vue (200), pas de headers CORS
        assert response.get("Access-Control-Allow-Origin") is None

    @override_settings(
        TENXYTE_CORS_ENABLED=True,
        TENXYTE_CORS_ALLOW_ALL_ORIGINS=True,
        TENXYTE_CORS_ALLOW_CREDENTIALS=True
    )
    def test_credentials_header_added(self):
        mw = __import__('tenxyte.middleware', fromlist=['CORSMiddleware']).CORSMiddleware(lambda r: HttpResponse("OK"))
        from django.test import RequestFactory
        req = RequestFactory().options(f"{api_prefix}/test/", HTTP_ORIGIN="https://example.com")
        response = mw(req)
        assert response.get("Access-Control-Allow-Credentials") == "true"

    @override_settings(
        TENXYTE_CORS_ENABLED=True,
        TENXYTE_CORS_ALLOW_ALL_ORIGINS=True
    )
    def test_normal_get_adds_cors_headers(self):
        mw = __import__('tenxyte.middleware', fromlist=['CORSMiddleware']).CORSMiddleware(lambda r: HttpResponse("OK"))
        from django.test import RequestFactory
        req = RequestFactory().get(f"{api_prefix}/test/", HTTP_ORIGIN="https://example.com")
        response = mw(req)
        assert response.get("Access-Control-Allow-Origin") == "https://example.com"

    @override_settings(
        TENXYTE_CORS_ENABLED=True,
        TENXYTE_CORS_ALLOW_ALL_ORIGINS=True
    )
    def test_no_origin_header_skips_cors(self):
        mw = __import__('tenxyte.middleware', fromlist=['CORSMiddleware']).CORSMiddleware(lambda r: HttpResponse("OK"))
        from django.test import RequestFactory
        req = RequestFactory().get(f"{api_prefix}/test/")  # Pas d'Origin
        response = mw(req)
        assert response.get("Access-Control-Allow-Origin") is None
