# Plan de Développement de la Librairie Vue.js : `@tenxyte/vue`

Ce document définit la stratégie complète, l'architecture et la roadmap pour la création du paquet npm `@tenxyte/vue`. Cette librairie est dédiée aux applications Vue.js 3 (Composition API) fonctionnant en tant que Single Page Applications (SPA), compilées avec Vite ou Vue CLI.

Tout comme `@tenxyte/react`, elle agit comme une surcouche réactive idiomatique au-dessus du moteur agnostique `@tenxyte/js-core`.

---

## 1. Objectif et Vision Globale

**Vision :** Intégrer la puissance de Tenxyte Backend dans l'écosystème Vue de manière naturelle, en tirant parti de la réactivité fine de Vue 3 (`ref`, `reactive`) et du standard de gestion d'état Pinia.

**Principes architecturaux :**
- **Vue 3 First (Composition API) :** Utilisation exclusive des *Composables* (`useAuth`, `useUser`). Plus de suppport pour l'Options API (Vue 2).
- **Dépendance forte au Core :** Le SDK ne fait aucun appel réseau direct. Il instancie et pilote `@tenxyte/js-core`.
- **Intégration Vue Router & Pinia :** La librairie doit s'interfacer facilement avec Vue Router pour la protection des routes (Navigation Guards) et peut (optionnellement) synchroniser son état avec Pinia.
- **Headless :** Pas UI fournie. Focus total sur la logique de session.

---

## 2. Structure du Dépôt

Nom du paquet NPM envisagé : `@tenxyte/vue`

```text
tenxyte-vue/
├── package.json
├── tsconfig.json          # Configuré pour Vue 3 et TypeScript
├── src/
│   ├── index.ts           # Exports publics
│   ├── plugin.ts          # Le Vue Plugin (app.use(createTenxyte({...})))
│   ├── composables/
│   │   ├── useTenxyte.ts      # Accès à l'instance JS-Core
│   │   ├── useAuth.ts         # { isAuthenticated, login, logout, isLoading }
│   │   ├── useUser.ts         # { user, refetch }
│   │   ├── usePermissions.ts  # RBAC: { hasRole, hasPermission }
│   │   └── useB2B.ts          # { organization, switchOrg }
│   ├── router/
│   │   └── guards.ts          # Navigation guards pour Vue Router (ex: requireAuth)
│   ├── state/
│   │   └── pinia.ts           # (Optionnel) Store Pinia préconfiguré
│   └── components/
│       └── RoleGate.vue       # Composant fonctionnel d'affichage conditionnel
├── tests/
│   └── composables.test.ts  # Tests avec @vue/test-utils
└── dist/                  # Build Vite Library Mode (ES, UMD, d.ts)
```

---

## 3. Fonctionnement Cœur : Le Vue Plugin

Au lieu d'un composant `<Provider>` comme en React, Vue.js privilégie les **Plugins** pour injecter des instances globales et des configurations à l'initialisation de l'application.

Ici, le plugin `createTenxyte` va initialiser le `@tenxyte/js-core` et le rendre disponible via l'injection de dépendances (`provide/inject`) pour tous les composables.

```typescript
// main.ts
import { createApp } from 'vue';
import App from './App.vue';
import { createTenxyte } from '@tenxyte/vue';

const app = createApp(App);

const tenxyte = createTenxyte({
  baseURL: 'https://api.mon-projet.com/api/v1',
  appKey: 'MON_APP_KEY',
  storage: 'localStorage' // Config transmise au js-core
});

// Le plugin tente automatiquement de restaurer la session (refresh_token)
app.use(tenxyte);
app.mount('#app');
```

---

## 4. L'API (Les Composables Vue 3)

Les développeurs utiliseront des *Composables* (l'équivalent des Hooks React). L'état interne de la librairie sera géré avec des `ref()` et `computed()` globaux ou partagés pour que l'UI se mette à jour dès que le statut d'authentification change.

### `useAuth()`
Expose l'état actuel et les méthodes de connexion de manière réactive.

```vue
<script setup>
import { useAuth } from '@tenxyte/vue';

const { isAuthenticated, isLoading, login, logout, error } = useAuth();

const handleLogin = async () => {
  await login('email@exemple.com', 'Pass123!');
};
</script>

<template>
  <button v-if="!isAuthenticated" @click="handleLogin" :disabled="isLoading">
    Connexion
  </button>
  <button v-else @click="logout">Déconnexion</button>
</template>
```

### `useUser()` & `usePermissions()`

```vue
<script setup>
import { useUser, usePermissions } from '@tenxyte/vue';

const { user } = useUser();
const { hasRole } = usePermissions();
</script>

<template>
  <div v-if="hasRole('admin')">
    Panel Administrateur pour {{ user.email }}
  </div>
</template>
```

---

## 5. Protection des Routes (Vue Router Guards)

C'est une des grandes forces de Vue : son routeur officiel. Plutôt que de créer des Wrappers JSX, `@tenxyte/vue` fournira des **Navigation Guards** tout prêts à être branchés sur le `vue-router`.

```typescript
// router/index.ts
import { createRouter, createWebHistory } from 'vue-router';
import { createTenxyteAuthGuard } from '@tenxyte/vue/router';

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/public', component: PublicPage },
    { 
      path: '/admin', 
      component: AdminDashboard,
      // On utilise les "meta" fields de Vue Router
      meta: { requiresAuth: true, roles: ['admin'] } 
    }
  ]
});

// Le Guard fourni par la lib va intercepter la navigation, 
// vérifier la session Tenxyte en mémoire (ou attendre la fin du isLoading du refresh),
// et rediriger si nécessaire.
router.beforeEach(createTenxyteAuthGuard({ loginRoute: '/login' }));
```

---

## 6. Intégration Optionnelle Pinia

Pour les applications Vue complexes, centraliser l'utilisateur dans le *State Management* officiel (Pinia) est souvent préféré.
Le plugin `createTenxyte` pourra, si Pinia est détecté (ou via un flag), alimenter automatiquement un Store Pinia interne :

```typescript
import { useTenxyteStore } from '@tenxyte/vue/state';
// useTenxyteStore() exposerait user, isAuthenticated, roles
```

Toutefois, utiliser les composables propres (`useAuth`) reste l'approche la plus légère et recommandée si le développeur ne souhaite pas installer Pinia.

---

## 7. Configuration de Build (Vite Library Mode)

La librairie sera compilée avec Vite en mode bibliothèque :
- Elle externalisera (`external`) `vue` et `vue-router` pour ne pas les inclure dans le bundle final (c'est le projet hôte qui les fournit).
- Elle générera les déclarations de type (`.d.ts`) pour que VSCode reconnaisse les types (autocomplétion sur `user.first_name`, etc.).

---

## 8. Roadmap du Développement (`@tenxyte/vue`)

*Prérequis : Le Paquet `@tenxyte/js-core` est publié et stable.*

### Phase 1 : Infrastructure & State Global (Semaine 1)
- Mise en place du dépôt Vue 3 + TypeScript. Config Vite.
- Développement du cœur réactif : création d'un "Store Global" minimal en pure Composition API (`reactive` ou `ref`) qui s'abonne aux événements de `@tenxyte/js-core`.
- Développement du Vue Plugin (`createTenxyte`).

### Phase 2 : Les Composables (Semaine 2)
- Implémentation de `useAuth()`, `useUser()`, `usePermissions()`.
- L'enjeu technique : S'assurer que si `useAuth` est appelé par 15 composants différents, c'est bien la *même* référence réactive (`ref`) qui est partagée, sans dupliquer l'état.

### Phase 3 : Routeur & Guards (Semaine 3)
- Développement de `createTenxyteAuthGuard` pour le `vue-router`.
- Gestion asynchrone pointue : Si un utilisateur charge `/dashboard` directement (F5), le composant ne doit pas se bloquer ni le renvoyer vers `/login` *avant* que le SDK n'ait fini sa tentative de "Silent Refresh" avec l'API.

### Phase 4 : Documentation & Tests (Semaine 4)
- Création d'un dossier `examples/vue3-ts` prouvant que tout fonctionne.
- Tests avec `@vue/test-utils`.
- Publication sur NPM.

---

### Conclusion

La librairie `@tenxyte/vue` offre la même philosophie "Headless" que la version React, mais traduite dans les idiomes propres à Vue 3 (Plugins, Composables, Navigation Guards). En couplant la puissance de la réactivité fine de Vue à la solidité du `@tenxyte/js-core`, les développeurs pourront protéger des routes et gérer des sessions complexes (Magic Links, Passkeys, Multi-tenant) avec un minimum de code (Boilerplate).
