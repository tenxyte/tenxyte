"""Tenxyte FastAPI Adapter."""
