import os
import re

TEST_DIR = 'tests'
SRC_DIR = 'src/tenxyte'

# Regex to find /api/auth/ or /api/...
# In tests typically it's _authed_request("get", "/api/auth/roles/", ...)
# So we look for "/api/auth/" and "/api/"
# The plan is to replace "/api/auth/" with "/api/v1/auth/" dynamically or just f"{API_PREFIX}/auth/"

def replace_in_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    new_content = content

    # If it's a test file, we want to inject API_PREFIX = getattr(settings, 'API_PREFIX', '/api/v1')
    # and replace occurrences.
    if filepath.endswith('.py'):
        # Just simple string replacement for tests:
        # Since it's a constant replacement to the actual API_PREFIX value per user request:
        # "valeur par defaut: /api/v1 ensuite nous allons remplacé toutes les partie où il y'a une url api en intégrant le bon prefix"
        # Since the user requested /api/v1, let's just update all string literals from "/api/auth/" to "/api/v1/auth/" for now directly,
        # OR use `API_PREFIX` variable. Using `API_PREFIX` variable is cleaner.

        if 'tests/' in filepath.replace('\\', '/'):
            # In tests, replace "/api/" with f"{API_PREFIX}/"
            # we need to ensure f-string is used if not already.
            pass
        
        # It's actually much simpler and safer to just replace the literal "/api/" with "/api/v1/"
        # since the user asked to replace "en intégrant le bon prefix" (which is /api/v1 default).
        # Let's see if we should just replace the strings directly:
        new_content = new_content.replace('"/api/', '"/api/v1/')
        new_content = new_content.replace('\'/api/', '\'/api/v1/')

        if new_content != content:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(new_content)
            return True
    return False

modified_count = 0
for d in [TEST_DIR, SRC_DIR]:
    for root, dirs, files in os.walk(d):
        for file in files:
            if file.endswith('.py') or file.endswith('.md'):
                filepath = os.path.join(root, file)
                if replace_in_file(filepath):
                    modified_count += 1
                    print(f"Updated {filepath}")

print(f"\nTotal files updated: {modified_count}")
