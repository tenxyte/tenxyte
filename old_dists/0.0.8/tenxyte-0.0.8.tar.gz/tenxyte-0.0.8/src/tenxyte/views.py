from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from drf_spectacular.utils import extend_schema, extend_schema_view, OpenApiParameter, OpenApiExample
from drf_spectacular.types import OpenApiTypes

from .serializers import (
    RegisterSerializer, LoginEmailSerializer, LoginPhoneSerializer,
    RefreshTokenSerializer, GoogleAuthSerializer, VerifyOTPSerializer,
    RequestOTPSerializer, PasswordResetRequestSerializer,
    PasswordResetConfirmSerializer, ChangePasswordSerializer, UserSerializer,
    PermissionSerializer, RoleSerializer, RoleListSerializer, AssignRoleSerializer,
    ApplicationSerializer, ApplicationCreateSerializer, ApplicationUpdateSerializer
)
from .services import AuthService, OTPService, GoogleAuthService
from .decorators import require_jwt, get_client_ip, require_permission
from .models import User, Role, Permission, Application
from .throttles import (
    LoginThrottle, LoginHourlyThrottle,
    RegisterThrottle, RegisterDailyThrottle,
    PasswordResetThrottle, PasswordResetDailyThrottle,
    OTPRequestThrottle, OTPVerifyThrottle,
    RefreshTokenThrottle, GoogleAuthThrottle,
    ProgressiveLoginThrottle
)


class RegisterView(APIView):
    """
    POST /api/auth/register/
    Inscription d'un nouvel utilisateur
    """
    permission_classes = [AllowAny]
    throttle_classes = [RegisterThrottle, RegisterDailyThrottle]

    @extend_schema(
        tags=['Auth'],
        summary="Inscription d'un nouvel utilisateur",
        description="Crée un nouveau compte utilisateur. Envoie automatiquement un code OTP de vérification.",
        request=RegisterSerializer,
        responses={
            201: OpenApiTypes.OBJECT,
            400: OpenApiTypes.OBJECT,
        }
    )
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        auth_service = AuthService()
        success, user, error = auth_service.register_user(**serializer.validated_data)

        if not success:
            return Response({
                'error': error,
                'code': 'REGISTRATION_FAILED'
            }, status=status.HTTP_400_BAD_REQUEST)

        # Générer et envoyer les OTP de vérification
        otp_service = OTPService()
        if user.email:
            otp = otp_service.generate_email_verification_otp(user)
            otp_service.send_email_otp(user, otp)

        if user.phone_number:
            otp = otp_service.generate_phone_verification_otp(user)
            otp_service.send_phone_otp(user, otp)

        return Response({
            'message': 'Registration successful',
            'user': UserSerializer(user).data,
            'verification_required': {
                'email': bool(user.email and not user.is_email_verified),
                'phone': bool(user.phone_number and not user.is_phone_verified)
            }
        }, status=status.HTTP_201_CREATED)


class LoginEmailView(APIView):
    """
    POST /api/auth/login/email/
    Connexion par email + password (+ 2FA si activé)
    """
    permission_classes = [AllowAny]
    throttle_classes = [LoginThrottle, LoginHourlyThrottle]

    @extend_schema(
        tags=['Auth'],
        summary="Connexion par email",
        description="Authentifie un utilisateur avec son email et mot de passe. "
                    "Si 2FA est activé, le champ totp_code est requis.",
        request=LoginEmailSerializer,
        responses={200: OpenApiTypes.OBJECT, 401: OpenApiTypes.OBJECT}
    )
    def post(self, request):
        serializer = LoginEmailSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        auth_service = AuthService()
        ip_address = get_client_ip(request)

        success, data, error = auth_service.authenticate_by_email(
            email=serializer.validated_data['email'],
            password=serializer.validated_data['password'],
            application=request.application,
            ip_address=ip_address
        )

        if not success:
            return Response({
                'error': error,
                'code': 'LOGIN_FAILED'
            }, status=status.HTTP_401_UNAUTHORIZED)

        # Vérifier 2FA si activé
        user = data.get('_user')  # L'AuthService doit retourner l'user
        if user and user.is_2fa_enabled:
            from .services import totp_service

            totp_code = serializer.validated_data.get('totp_code', '')
            if not totp_code:
                return Response({
                    'error': '2FA code required',
                    'code': '2FA_REQUIRED',
                    'requires_2fa': True
                }, status=status.HTTP_401_UNAUTHORIZED)

            is_valid, error_msg = totp_service.verify_2fa(user, totp_code)
            if not is_valid:
                return Response({
                    'error': error_msg,
                    'code': 'INVALID_2FA_CODE'
                }, status=status.HTTP_401_UNAUTHORIZED)

        # Retirer l'user de la réponse (on ne veut pas l'exposer)
        if '_user' in data:
            del data['_user']

        return Response(data)


class LoginPhoneView(APIView):
    """
    POST /api/auth/login/phone/
    Connexion par téléphone + password (+ 2FA si activé)
    """
    permission_classes = [AllowAny]
    throttle_classes = [LoginThrottle, LoginHourlyThrottle]

    @extend_schema(
        tags=['Auth'],
        summary="Connexion par téléphone",
        description="Authentifie un utilisateur avec son numéro de téléphone et mot de passe. "
                    "Si 2FA est activé, le champ totp_code est requis.",
        request=LoginPhoneSerializer,
        responses={200: OpenApiTypes.OBJECT, 401: OpenApiTypes.OBJECT}
    )
    def post(self, request):
        serializer = LoginPhoneSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        auth_service = AuthService()
        ip_address = get_client_ip(request)

        success, data, error = auth_service.authenticate_by_phone(
            country_code=serializer.validated_data['phone_country_code'],
            phone_number=serializer.validated_data['phone_number'],
            password=serializer.validated_data['password'],
            application=request.application,
            ip_address=ip_address
        )

        if not success:
            return Response({
                'error': error,
                'code': 'LOGIN_FAILED'
            }, status=status.HTTP_401_UNAUTHORIZED)

        # Vérifier 2FA si activé
        user = data.get('_user')
        if user and user.is_2fa_enabled:
            from .services import totp_service

            totp_code = serializer.validated_data.get('totp_code', '')
            if not totp_code:
                return Response({
                    'error': '2FA code required',
                    'code': '2FA_REQUIRED',
                    'requires_2fa': True
                }, status=status.HTTP_401_UNAUTHORIZED)

            is_valid, error_msg = totp_service.verify_2fa(user, totp_code)
            if not is_valid:
                return Response({
                    'error': error_msg,
                    'code': 'INVALID_2FA_CODE'
                }, status=status.HTTP_401_UNAUTHORIZED)

        # Retirer l'user de la réponse
        if '_user' in data:
            del data['_user']

        return Response(data)


class GoogleAuthView(APIView):
    """
    POST /api/auth/google/
    Authentification via Google OAuth
    """
    permission_classes = [AllowAny]
    throttle_classes = [GoogleAuthThrottle]

    @extend_schema(
        tags=['Auth'],
        summary="Authentification Google OAuth",
        description="Authentifie un utilisateur via Google OAuth. Accepte id_token, access_token ou code.",
        request=GoogleAuthSerializer,
        responses={200: OpenApiTypes.OBJECT, 401: OpenApiTypes.OBJECT}
    )
    def post(self, request):
        serializer = GoogleAuthSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        google_service = GoogleAuthService()
        ip_address = get_client_ip(request)
        google_data = None

        # Essayer de récupérer les données Google
        if serializer.validated_data.get('id_token'):
            google_data = google_service.verify_id_token(
                serializer.validated_data['id_token']
            )
        elif serializer.validated_data.get('access_token'):
            google_data = google_service.get_user_info(
                serializer.validated_data['access_token']
            )
        elif serializer.validated_data.get('code'):
            tokens = google_service.exchange_code_for_tokens(
                serializer.validated_data['code'],
                serializer.validated_data['redirect_uri']
            )
            if tokens and 'access_token' in tokens:
                google_data = google_service.get_user_info(tokens['access_token'])

        if not google_data:
            return Response({
                'error': 'Invalid Google credentials',
                'code': 'GOOGLE_AUTH_FAILED'
            }, status=status.HTTP_401_UNAUTHORIZED)

        success, data, error = google_service.authenticate_with_google(
            google_data=google_data,
            application=request.application,
            ip_address=ip_address
        )

        if not success:
            return Response({
                'error': error,
                'code': 'GOOGLE_AUTH_FAILED'
            }, status=status.HTTP_401_UNAUTHORIZED)

        return Response(data)


class RefreshTokenView(APIView):
    """
    POST /api/auth/refresh/
    Rafraîchir le access token
    """
    permission_classes = [AllowAny]
    throttle_classes = [RefreshTokenThrottle]

    @extend_schema(
        tags=['Auth'],
        summary="Rafraîchir le token d'accès",
        description="Génère un nouveau access token à partir d'un refresh token valide.",
        request=RefreshTokenSerializer,
        responses={200: OpenApiTypes.OBJECT, 401: OpenApiTypes.OBJECT}
    )
    def post(self, request):
        serializer = RefreshTokenSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        auth_service = AuthService()
        success, data, error = auth_service.refresh_access_token(
            refresh_token_str=serializer.validated_data['refresh_token'],
            application=request.application
        )

        if not success:
            return Response({
                'error': error,
                'code': 'REFRESH_FAILED'
            }, status=status.HTTP_401_UNAUTHORIZED)

        return Response(data)


class LogoutView(APIView):
    """
    POST /api/auth/logout/
    Déconnexion (révoque le refresh token)
    """
    permission_classes = [AllowAny]

    @extend_schema(
        tags=['Auth'],
        summary="Déconnexion",
        description="Révoque le refresh token fourni pour déconnecter l'utilisateur.",
        request=RefreshTokenSerializer,
        responses={200: OpenApiTypes.OBJECT}
    )
    def post(self, request):
        serializer = RefreshTokenSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        auth_service = AuthService()
        auth_service.logout(serializer.validated_data['refresh_token'])

        return Response({'message': 'Logged out successfully'})


class LogoutAllView(APIView):
    """
    POST /api/auth/logout/all/
    Déconnexion de tous les appareils
    """

    @extend_schema(
        tags=['Auth'],
        summary="Déconnexion de tous les appareils",
        description="Révoque tous les refresh tokens de l'utilisateur connecté.",
        request=None,
        responses={200: OpenApiTypes.OBJECT}
    )
    @require_jwt
    def post(self, request):
        auth_service = AuthService()
        count = auth_service.logout_all_devices(request.user)

        return Response({
            'message': f'Logged out from {count} devices'
        })


class RequestOTPView(APIView):
    """
    POST /api/auth/otp/request/
    Demander un code OTP
    """
    throttle_classes = [OTPRequestThrottle]

    @extend_schema(
        tags=['OTP'],
        summary="Demander un code OTP",
        description="Génère et envoie un code OTP par email ou SMS selon le type demandé.",
        request=RequestOTPSerializer,
        responses={200: OpenApiTypes.OBJECT, 400: OpenApiTypes.OBJECT}
    )
    @require_jwt
    def post(self, request):
        serializer = RequestOTPSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        otp_service = OTPService()
        otp_type = serializer.validated_data['otp_type']

        if otp_type == 'email':
            if not request.user.email:
                return Response({
                    'error': 'No email address on account',
                    'code': 'NO_EMAIL'
                }, status=status.HTTP_400_BAD_REQUEST)

            otp = otp_service.generate_email_verification_otp(request.user)
            otp_service.send_email_otp(request.user, otp)

        elif otp_type == 'phone':
            if not request.user.phone_number:
                return Response({
                    'error': 'No phone number on account',
                    'code': 'NO_PHONE'
                }, status=status.HTTP_400_BAD_REQUEST)

            otp = otp_service.generate_phone_verification_otp(request.user)
            otp_service.send_phone_otp(request.user, otp)

        return Response({'message': 'OTP sent successfully'})


class VerifyEmailOTPView(APIView):
    """
    POST /api/auth/otp/verify/email/
    Vérifier le code OTP email
    """
    throttle_classes = [OTPVerifyThrottle]

    @extend_schema(
        tags=['OTP'],
        summary="Vérifier le code OTP email",
        description="Vérifie le code OTP envoyé par email pour valider l'adresse email.",
        request=VerifyOTPSerializer,
        responses={200: OpenApiTypes.OBJECT, 400: OpenApiTypes.OBJECT}
    )
    @require_jwt
    def post(self, request):
        serializer = VerifyOTPSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        otp_service = OTPService()
        success, error = otp_service.verify_email_otp(
            request.user,
            serializer.validated_data['code']
        )

        if not success:
            return Response({
                'error': error,
                'code': 'OTP_VERIFICATION_FAILED'
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({'message': 'Email verified successfully'})


class VerifyPhoneOTPView(APIView):
    """
    POST /api/auth/otp/verify/phone/
    Vérifier le code OTP téléphone
    """
    throttle_classes = [OTPVerifyThrottle]

    @extend_schema(
        tags=['OTP'],
        summary="Vérifier le code OTP téléphone",
        description="Vérifie le code OTP envoyé par SMS pour valider le numéro de téléphone.",
        request=VerifyOTPSerializer,
        responses={200: OpenApiTypes.OBJECT, 400: OpenApiTypes.OBJECT}
    )
    @require_jwt
    def post(self, request):
        serializer = VerifyOTPSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        otp_service = OTPService()
        success, error = otp_service.verify_phone_otp(
            request.user,
            serializer.validated_data['code']
        )

        if not success:
            return Response({
                'error': error,
                'code': 'OTP_VERIFICATION_FAILED'
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({'message': 'Phone verified successfully'})


class PasswordResetRequestView(APIView):
    """
    POST /api/auth/password/reset/request/
    Demander une réinitialisation de mot de passe
    """
    permission_classes = [AllowAny]
    throttle_classes = [PasswordResetThrottle, PasswordResetDailyThrottle]

    @extend_schema(
        tags=['Password'],
        summary="Demander une réinitialisation de mot de passe",
        description="Envoie un code OTP pour réinitialiser le mot de passe. Ne révèle pas si le compte existe.",
        request=PasswordResetRequestSerializer,
        responses={200: OpenApiTypes.OBJECT}
    )
    def post(self, request):
        serializer = PasswordResetRequestSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        user = None
        if serializer.validated_data.get('email'):
            user = User.objects.filter(
                email__iexact=serializer.validated_data['email']
            ).first()
        elif serializer.validated_data.get('phone_number'):
            user = User.objects.filter(
                phone_country_code=serializer.validated_data['phone_country_code'],
                phone_number=serializer.validated_data['phone_number']
            ).first()

        # Ne pas révéler si l'utilisateur existe
        if user:
            otp_service = OTPService()
            otp = otp_service.generate_password_reset_otp(user)

            if user.email:
                otp_service.send_email_otp(user, otp)
            elif user.phone_number:
                otp_service.send_phone_otp(user, otp)

        return Response({
            'message': 'If the account exists, a reset code has been sent'
        })


class PasswordResetConfirmView(APIView):
    """
    POST /api/auth/password/reset/confirm/
    Confirmer la réinitialisation de mot de passe
    """
    permission_classes = [AllowAny]
    throttle_classes = [OTPVerifyThrottle]

    @extend_schema(
        tags=['Password'],
        summary="Confirmer la réinitialisation de mot de passe",
        description="Vérifie le code OTP et définit un nouveau mot de passe. Révoque tous les refresh tokens.",
        request=PasswordResetConfirmSerializer,
        responses={200: OpenApiTypes.OBJECT, 400: OpenApiTypes.OBJECT}
    )
    def post(self, request):
        serializer = PasswordResetConfirmSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        # On a besoin de l'identifiant de l'utilisateur
        email = request.data.get('email')
        phone_country_code = request.data.get('phone_country_code')
        phone_number = request.data.get('phone_number')

        user = None
        if email:
            user = User.objects.filter(email__iexact=email).first()
        elif phone_country_code and phone_number:
            user = User.objects.filter(
                phone_country_code=phone_country_code,
                phone_number=phone_number
            ).first()

        if not user:
            return Response({
                'error': 'Invalid reset request',
                'code': 'RESET_FAILED'
            }, status=status.HTTP_400_BAD_REQUEST)

        otp_service = OTPService()
        success, error = otp_service.verify_password_reset_otp(
            user,
            serializer.validated_data['code']
        )

        if not success:
            return Response({
                'error': error,
                'code': 'RESET_FAILED'
            }, status=status.HTTP_400_BAD_REQUEST)

        # Mettre à jour le mot de passe
        user.set_password(serializer.validated_data['new_password'])
        user.save()

        # Révoquer tous les refresh tokens
        AuthService().logout_all_devices(user)

        return Response({'message': 'Password reset successfully'})


class ChangePasswordView(APIView):
    """
    POST /api/auth/password/change/
    Changer le mot de passe (utilisateur connecté)
    """

    @extend_schema(
        tags=['Password'],
        summary="Changer le mot de passe",
        description="Change le mot de passe de l'utilisateur connecté. Requiert le mot de passe actuel.",
        request=ChangePasswordSerializer,
        responses={200: OpenApiTypes.OBJECT, 400: OpenApiTypes.OBJECT}
    )
    @require_jwt
    def post(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        if not request.user.check_password(serializer.validated_data['current_password']):
            return Response({
                'error': 'Current password is incorrect',
                'code': 'INVALID_PASSWORD'
            }, status=status.HTTP_400_BAD_REQUEST)

        request.user.set_password(serializer.validated_data['new_password'])
        request.user.save()

        return Response({'message': 'Password changed successfully'})


class PasswordStrengthView(APIView):
    """
    POST /api/auth/password/strength/
    Verifier la force d'un mot de passe (pour validation frontend)
    """
    permission_classes = [AllowAny]

    @extend_schema(
        tags=['Password'],
        summary="Verifier la force d'un mot de passe",
        description="Retourne le score et la force d'un mot de passe sans l'enregistrer.",
        request={"application/json": {"type": "object", "properties": {"password": {"type": "string"}}}},
        responses={200: OpenApiTypes.OBJECT}
    )
    def post(self, request):
        from .validators import password_validator

        password = request.data.get('password', '')
        email = request.data.get('email')

        result = password_validator.validate(password, email=email)

        return Response({
            'score': result.score,
            'strength': result.strength,
            'is_valid': result.is_valid,
            'errors': result.errors if not result.is_valid else [],
            'requirements': password_validator.get_requirements()
        })


class PasswordRequirementsView(APIView):
    """
    GET /api/auth/password/requirements/
    Recuperer les exigences de mot de passe
    """
    permission_classes = [AllowAny]

    @extend_schema(
        tags=['Password'],
        summary="Exigences de mot de passe",
        description="Retourne la liste des exigences pour un mot de passe valide.",
        responses={200: OpenApiTypes.OBJECT}
    )
    def get(self, request):
        from .validators import password_validator

        return Response({
            'requirements': password_validator.get_requirements(),
            'min_length': password_validator.min_length,
            'max_length': password_validator.max_length,
        })


class MeView(APIView):
    """
    GET /api/auth/me/
    Récupérer le profil de l'utilisateur connecté
    """

    @extend_schema(
        tags=['User'],
        summary="Récupérer mon profil",
        description="Retourne les informations de l'utilisateur connecté.",
        responses={200: UserSerializer}
    )
    def get(self, request):
        return Response(UserSerializer(request.user).data)

    @extend_schema(
        tags=['User'],
        summary="Modifier mon profil",
        description="Met à jour les informations de l'utilisateur connecté.",
        request=UserSerializer,
        responses={200: UserSerializer, 400: OpenApiTypes.OBJECT}
    )
    def patch(self, request):
        serializer = UserSerializer(request.user, data=request.data, partial=True)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        serializer.save()
        return Response(serializer.data)


# ============== RBAC Views ==============

@extend_schema_view(
    get=extend_schema(
        tags=['RBAC'],
        summary="Lister les permissions",
        description="Retourne la liste de toutes les permissions disponibles.",
        responses={200: PermissionSerializer(many=True)}
    ),
    post=extend_schema(
        tags=['RBAC'],
        summary="Créer une permission",
        description="Crée une nouvelle permission.",
        request=PermissionSerializer,
        responses={201: PermissionSerializer, 400: OpenApiTypes.OBJECT}
    )
)
class PermissionListView(APIView):
    """
    GET /api/auth/permissions/
    Liste toutes les permissions
    """

    @require_permission('permissions.view')
    def get(self, request):
        permissions = Permission.objects.all()
        serializer = PermissionSerializer(permissions, many=True)
        return Response(serializer.data)

    @require_permission('permissions.create')
    def post(self, request):
        serializer = PermissionSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)


@extend_schema_view(
    get=extend_schema(
        tags=['RBAC'],
        summary="Détails d'une permission",
        description="Récupère les informations d'une permission par son ID.",
        responses={200: PermissionSerializer, 404: OpenApiTypes.OBJECT}
    ),
    put=extend_schema(
        tags=['RBAC'],
        summary="Modifier une permission",
        description="Met à jour les informations d'une permission.",
        request=PermissionSerializer,
        responses={200: PermissionSerializer, 400: OpenApiTypes.OBJECT, 404: OpenApiTypes.OBJECT}
    ),
    delete=extend_schema(
        tags=['RBAC'],
        summary="Supprimer une permission",
        description="Supprime définitivement une permission.",
        responses={200: OpenApiTypes.OBJECT, 404: OpenApiTypes.OBJECT}
    )
)
class PermissionDetailView(APIView):
    """
    GET/PUT/DELETE /api/auth/permissions/<permission_id>/
    """

    @require_permission('permissions.view')
    def get(self, request, permission_id):
        try:
            permission = Permission.objects.get(id=permission_id)
            return Response(PermissionSerializer(permission).data)
        except Permission.DoesNotExist:
            return Response({
                'error': 'Permission not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)

    @require_permission('permissions.update')
    def put(self, request, permission_id):
        try:
            permission = Permission.objects.get(id=permission_id)
        except Permission.DoesNotExist:
            return Response({
                'error': 'Permission not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)

        serializer = PermissionSerializer(permission, data=request.data, partial=True)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        serializer.save()
        return Response(serializer.data)

    @require_permission('permissions.delete')
    def delete(self, request, permission_id):
        try:
            permission = Permission.objects.get(id=permission_id)
            permission.delete()
            return Response({'message': 'Permission deleted'}, status=status.HTTP_200_OK)
        except Permission.DoesNotExist:
            return Response({
                'error': 'Permission not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)


@extend_schema_view(
    get=extend_schema(
        tags=['RBAC'],
        summary="Lister les rôles",
        description="Retourne la liste de tous les rôles disponibles.",
        responses={200: RoleListSerializer(many=True)}
    ),
    post=extend_schema(
        tags=['RBAC'],
        summary="Créer un rôle",
        description="Crée un nouveau rôle avec les permissions spécifiées.",
        request=RoleSerializer,
        responses={201: RoleSerializer, 400: OpenApiTypes.OBJECT}
    )
)
class RoleListView(APIView):
    """
    GET /api/auth/roles/
    Liste tous les rôles
    """

    @require_permission('roles.view')
    def get(self, request):
        roles = Role.objects.all()
        serializer = RoleListSerializer(roles, many=True)
        return Response(serializer.data)

    @require_permission('roles.create')
    def post(self, request):
        serializer = RoleSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)


@extend_schema_view(
    get=extend_schema(
        tags=['RBAC'],
        summary="Détails d'un rôle",
        description="Récupère les informations d'un rôle par son ID.",
        responses={200: RoleSerializer, 404: OpenApiTypes.OBJECT}
    ),
    put=extend_schema(
        tags=['RBAC'],
        summary="Modifier un rôle",
        description="Met à jour les informations d'un rôle.",
        request=RoleSerializer,
        responses={200: RoleSerializer, 400: OpenApiTypes.OBJECT, 404: OpenApiTypes.OBJECT}
    ),
    delete=extend_schema(
        tags=['RBAC'],
        summary="Supprimer un rôle",
        description="Supprime définitivement un rôle.",
        responses={200: OpenApiTypes.OBJECT, 404: OpenApiTypes.OBJECT}
    )
)
class RoleDetailView(APIView):
    """
    GET/PUT/DELETE /api/auth/roles/<role_id>/
    """

    @require_permission('roles.view')
    def get(self, request, role_id):
        try:
            role = Role.objects.get(id=role_id)
            return Response(RoleSerializer(role).data)
        except Role.DoesNotExist:
            return Response({
                'error': 'Role not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)

    @require_permission('roles.update')
    def put(self, request, role_id):
        try:
            role = Role.objects.get(id=role_id)
        except Role.DoesNotExist:
            return Response({
                'error': 'Role not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)

        serializer = RoleSerializer(role, data=request.data, partial=True)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        serializer.save()
        return Response(serializer.data)

    @require_permission('roles.delete')
    def delete(self, request, role_id):
        try:
            role = Role.objects.get(id=role_id)
            role.delete()
            return Response({'message': 'Role deleted'}, status=status.HTTP_200_OK)
        except Role.DoesNotExist:
            return Response({
                'error': 'Role not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)


@extend_schema_view(
    get=extend_schema(
        tags=['RBAC'],
        summary="Lister les rôles d'un utilisateur",
        description="Récupère tous les rôles assignés à un utilisateur.",
        responses={200: OpenApiTypes.OBJECT, 404: OpenApiTypes.OBJECT}
    ),
    post=extend_schema(
        tags=['RBAC'],
        summary="Assigner un rôle",
        description="Ajoute un rôle à un utilisateur.",
        request=AssignRoleSerializer,
        responses={200: OpenApiTypes.OBJECT, 404: OpenApiTypes.OBJECT}
    ),
    delete=extend_schema(
        tags=['RBAC'],
        summary="Retirer un rôle",
        description="Retire un rôle d'un utilisateur. Le role_code doit être passé en query parameter.",
        parameters=[
            OpenApiParameter(
                name='role_code',
                type=str,
                location=OpenApiParameter.QUERY,
                description='Le code du rôle à retirer',
                required=True
            )
        ],
        responses={200: OpenApiTypes.OBJECT, 400: OpenApiTypes.OBJECT, 404: OpenApiTypes.OBJECT}
    )
)
class UserRolesView(APIView):
    """
    GET /api/auth/users/<user_id>/roles/
    Gère les rôles d'un utilisateur
    """

    @require_permission('users.roles.view')
    def get(self, request, user_id):
        try:
            user = User.objects.get(id=user_id)
            roles = user.roles.all()
            return Response({
                'user_id': str(user.id),
                'roles': RoleListSerializer(roles, many=True).data
            })
        except User.DoesNotExist:
            return Response({
                'error': 'User not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)

    @require_permission('users.roles.assign')
    def post(self, request, user_id):
        """Ajoute un rôle à l'utilisateur"""
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({
                'error': 'User not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)

        serializer = AssignRoleSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        if user.assign_role(serializer.validated_data['role_code']):
            return Response({
                'message': 'Role assigned',
                'roles': user.get_all_roles()
            })
        else:
            return Response({
                'error': 'Role not found',
                'code': 'ROLE_NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)

    @require_permission('users.roles.remove')
    def delete(self, request, user_id):
        """Retire un rôle à l'utilisateur"""
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({
                'error': 'User not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)

        role_code = request.query_params.get('role_code')
        if not role_code:
            return Response({
                'error': 'role_code query parameter required',
                'code': 'MISSING_PARAM'
            }, status=status.HTTP_400_BAD_REQUEST)

        if user.remove_role(role_code):
            return Response({
                'message': 'Role removed',
                'roles': user.get_all_roles()
            })
        else:
            return Response({
                'error': 'Role not found',
                'code': 'ROLE_NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)


class MyRolesView(APIView):
    """
    GET /api/auth/me/roles/
    Récupère les rôles et permissions de l'utilisateur connecté
    """

    @extend_schema(
        tags=['User'],
        summary="Récupérer mes rôles et permissions",
        description="Retourne la liste des rôles et permissions de l'utilisateur connecté.",
        responses={200: OpenApiTypes.OBJECT}
    )
    @require_jwt
    def get(self, request):
        return Response({
            'roles': request.user.get_all_roles(),
            'permissions': request.user.get_all_permissions()
        })


# ============== 2FA Views ==============

class TwoFactorStatusView(APIView):
    """
    GET /api/auth/2fa/status/
    Récupère le statut 2FA de l'utilisateur
    """

    @extend_schema(
        tags=['2FA'],
        summary="Statut 2FA",
        description="Retourne si le 2FA est activé et le nombre de codes de secours restants.",
        responses={200: OpenApiTypes.OBJECT}
    )
    @require_jwt
    def get(self, request):
        return Response({
            'is_enabled': request.user.is_2fa_enabled,
            'backup_codes_remaining': len(request.user.backup_codes) if request.user.backup_codes else 0
        })


class TwoFactorSetupView(APIView):
    """
    POST /api/auth/2fa/setup/
    Initialise la configuration 2FA
    """

    @extend_schema(
        tags=['2FA'],
        summary="Initialiser 2FA",
        description="Génère un nouveau secret TOTP et retourne le QR code et les codes de secours. "
                    "L'utilisateur doit ensuite confirmer avec un code TOTP valide.",
        responses={200: OpenApiTypes.OBJECT}
    )
    @require_jwt
    def post(self, request):
        from .services import totp_service

        if request.user.is_2fa_enabled:
            return Response({
                'error': '2FA is already enabled',
                'code': '2FA_ALREADY_ENABLED'
            }, status=status.HTTP_400_BAD_REQUEST)

        setup_data = totp_service.setup_2fa(request.user)

        return Response({
            'message': 'Scan the QR code with your authenticator app, then confirm with a code.',
            'secret': setup_data['secret'],
            'qr_code': setup_data['qr_code'],
            'provisioning_uri': setup_data['provisioning_uri'],
            'backup_codes': setup_data['backup_codes'],
            'warning': 'Save the backup codes securely. They will not be shown again.'
        })


class TwoFactorConfirmView(APIView):
    """
    POST /api/auth/2fa/confirm/
    Confirme l'activation du 2FA avec un code TOTP
    """

    @extend_schema(
        tags=['2FA'],
        summary="Confirmer activation 2FA",
        description="Vérifie le premier code TOTP pour activer le 2FA.",
        request={"application/json": {"type": "object", "properties": {"code": {"type": "string"}}}},
        responses={200: OpenApiTypes.OBJECT, 400: OpenApiTypes.OBJECT}
    )
    @require_jwt
    def post(self, request):
        from .services import totp_service

        code = request.data.get('code', '')
        if not code:
            return Response({
                'error': 'Code is required',
                'code': 'CODE_REQUIRED'
            }, status=status.HTTP_400_BAD_REQUEST)

        success, error = totp_service.confirm_2fa(request.user, code)

        if not success:
            return Response({
                'error': error,
                'code': 'INVALID_CODE'
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'message': '2FA enabled successfully',
            'is_enabled': True
        })


class TwoFactorDisableView(APIView):
    """
    POST /api/auth/2fa/disable/
    Désactive le 2FA
    """

    @extend_schema(
        tags=['2FA'],
        summary="Désactiver 2FA",
        description="Désactive le 2FA après vérification du code TOTP ou d'un code de secours.",
        request={"application/json": {"type": "object", "properties": {"code": {"type": "string"}}}},
        responses={200: OpenApiTypes.OBJECT, 400: OpenApiTypes.OBJECT}
    )
    @require_jwt
    def post(self, request):
        from .services import totp_service

        code = request.data.get('code', '')
        if not code:
            return Response({
                'error': 'Code is required',
                'code': 'CODE_REQUIRED'
            }, status=status.HTTP_400_BAD_REQUEST)

        success, error = totp_service.disable_2fa(request.user, code)

        if not success:
            return Response({
                'error': error,
                'code': 'INVALID_CODE'
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'message': '2FA disabled successfully',
            'is_enabled': False
        })


class TwoFactorBackupCodesView(APIView):
    """
    POST /api/auth/2fa/backup-codes/
    Régénère les codes de secours
    """

    @extend_schema(
        tags=['2FA'],
        summary="Régénérer codes de secours",
        description="Génère de nouveaux codes de secours (les anciens sont invalidés). "
                    "Requiert un code TOTP valide.",
        request={"application/json": {"type": "object", "properties": {"code": {"type": "string"}}}},
        responses={200: OpenApiTypes.OBJECT, 400: OpenApiTypes.OBJECT}
    )
    @require_jwt
    def post(self, request):
        from .services import totp_service

        code = request.data.get('code', '')
        if not code:
            return Response({
                'error': 'TOTP code is required',
                'code': 'CODE_REQUIRED'
            }, status=status.HTTP_400_BAD_REQUEST)

        success, new_codes, error = totp_service.regenerate_backup_codes(request.user, code)

        if not success:
            return Response({
                'error': error,
                'code': 'INVALID_CODE'
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'message': 'Backup codes regenerated',
            'backup_codes': new_codes,
            'warning': 'Save these codes securely. They will not be shown again.'
        })


# ============== Application Views ==============

@extend_schema_view(
    get=extend_schema(
        tags=['Applications'],
        summary="Lister les applications",
        description="Retourne la liste de toutes les applications enregistrées.",
        responses={200: ApplicationSerializer(many=True)}
    ),
    post=extend_schema(
        tags=['Applications'],
        summary="Créer une application",
        description="Crée une nouvelle application et retourne les credentials. **Attention:** le secret n'est affiché qu'une seule fois.",
        request=ApplicationCreateSerializer,
        responses={201: OpenApiTypes.OBJECT}
    )
)
class ApplicationListView(APIView):
    """
    GET /api/v1/auth/applications/
    Liste toutes les applications

    POST /api/v1/auth/applications/
    Crée une nouvelle application
    """

    @require_permission('applications.view')
    def get(self, request):
        applications = Application.objects.all()
        serializer = ApplicationSerializer(applications, many=True)
        return Response(serializer.data)

    @require_permission('applications.create')
    def post(self, request):
        serializer = ApplicationCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        app, raw_secret = Application.create_application(
            name=serializer.validated_data['name'],
            description=serializer.validated_data.get('description', '')
        )

        return Response({
            'message': 'Application created successfully',
            'application': ApplicationSerializer(app).data,
            'credentials': {
                'access_key': app.access_key,
                'access_secret': raw_secret
            },
            'warning': 'Save the access_secret now! It will never be shown again.'
        }, status=status.HTTP_201_CREATED)


@extend_schema_view(
    get=extend_schema(
        tags=['Applications'],
        summary="Détails d'une application",
        description="Récupère les informations d'une application par son ID.",
        responses={200: ApplicationSerializer, 404: OpenApiTypes.OBJECT}
    ),
    put=extend_schema(
        tags=['Applications'],
        summary="Modifier une application",
        description="Met à jour les informations d'une application.",
        request=ApplicationUpdateSerializer,
        responses={200: ApplicationSerializer, 404: OpenApiTypes.OBJECT}
    ),
    delete=extend_schema(
        tags=['Applications'],
        summary="Supprimer une application",
        description="Supprime définitivement une application.",
        responses={200: OpenApiTypes.OBJECT, 404: OpenApiTypes.OBJECT}
    )
)
class ApplicationDetailView(APIView):
    """
    GET /api/v1/auth/applications/<app_id>/
    Récupère les détails d'une application

    PUT /api/v1/auth/applications/<app_id>/
    Met à jour une application

    DELETE /api/v1/auth/applications/<app_id>/
    Supprime une application
    """

    @require_permission('applications.view')
    def get(self, request, app_id):
        try:
            app = Application.objects.get(id=app_id)
            return Response(ApplicationSerializer(app).data)
        except Application.DoesNotExist:
            return Response({
                'error': 'Application not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)

    @require_permission('applications.update')
    def put(self, request, app_id):
        try:
            app = Application.objects.get(id=app_id)
        except Application.DoesNotExist:
            return Response({
                'error': 'Application not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)

        serializer = ApplicationUpdateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                'error': 'Validation error',
                'details': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        # Mise à jour des champs
        for field, value in serializer.validated_data.items():
            setattr(app, field, value)
        app.save()

        return Response(ApplicationSerializer(app).data)

    @require_permission('applications.delete')
    def delete(self, request, app_id):
        try:
            app = Application.objects.get(id=app_id)
            app_name = app.name
            app.delete()
            return Response({
                'message': f'Application "{app_name}" deleted successfully'
            })
        except Application.DoesNotExist:
            return Response({
                'error': 'Application not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)


class ApplicationRegenerateView(APIView):
    """
    POST /api/v1/auth/applications/<app_id>/regenerate/
    Régénère les credentials d'une application
    """

    @extend_schema(
        tags=['Applications'],
        summary="Régénérer les credentials",
        description="Régénère l'access_key et l'access_secret d'une application. **Attention:** les anciens credentials seront invalidés.",
        request=None,
        responses={200: OpenApiTypes.OBJECT, 404: OpenApiTypes.OBJECT}
    )
    @require_permission('applications.regenerate')
    def post(self, request, app_id):
        try:
            app = Application.objects.get(id=app_id)
        except Application.DoesNotExist:
            return Response({
                'error': 'Application not found',
                'code': 'NOT_FOUND'
            }, status=status.HTTP_404_NOT_FOUND)

        credentials = app.regenerate_credentials()

        return Response({
            'message': 'Credentials regenerated successfully',
            'application': ApplicationSerializer(app).data,
            'credentials': credentials,
            'warning': 'Save the access_secret now! It will never be shown again.'
        })
