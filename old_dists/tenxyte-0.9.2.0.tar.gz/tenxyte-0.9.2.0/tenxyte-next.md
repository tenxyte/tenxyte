# Plan de Développement de la Librairie Next.js : `@tenxyte/nextjs`

Ce document définit la stratégie complète, l'architecture et la roadmap pour la création du paquet npm `@tenxyte/nextjs`. Contrairement à `@tenxyte/react` (qui fonctionne exclusivement dans le navigateur), ce SDK est conçu pour l'écosystème "Full-Stack" de Next.js (Server Components, Route Handlers, et Server Actions).

---

## 1. Objectif et Vision Globale

**Vision :** Permettre aux développeurs Next.js d'intégrer l'authentification Tenxyte en conservant les avantages absolus du Server-Side Rendering (SSR) et du SEO. Les pages doivent se charger instantanément, déjà protégées, sans aucun "scintillement" (Flash of Unauthenticated State).

**Principes architecturaux :**
- **Cookies-First :** Abandon du `localStorage`. Le SDK impose l'utilisation de cookies sécurisés (`HttpOnly`, `SameSite=Lax`) gérés automatiquement entre le serveur Node.js de Next.js et l'API Python Tenxyte.
- **Backend-For-Frontend (BFF) Optionnel :** Si l'API Tenxyte n'est pas sur le même sous-domaine que Next.js, le SDK fournit des "Route Handlers" (proxy) locaux pour distribuer les cookies sans heurts liés aux CORS.
- **Support App Router :** Conception native pour le nouveau paradigme de Next.js (app directory, `next/headers`).
- **Interopérabilité :** Le SDK exporte les mêmes Hooks de confort Client-Side que `@tenxyte/react`, mais injectés avec des données pré-récupérées sur le serveur.

---

## 2. Structure du Dépôt

Nom du paquet NPM envisagé : `@tenxyte/nextjs`

```text
tenxyte-next/
├── package.json
├── tsconfig.json          # Configuré pour les directives "use client" / "use server"
├── src/
│   ├── server/            # Code exécuté STRICTEMENT sur le serveur (RSC, Actions, Middlewares)
│   │   ├── session.ts     # getSession(), getUserServer()
│   │   ├── actions.ts     # Next Server Actions pour login/logout
│   │   ├── middleware.ts  # Export d'un middleware protecteur (authMiddleware)
│   │   └── routeHandler.ts# (Optionnel) BFF Proxy pour set les cookies
│   ├── client/            # Code exécuté dans le navigateur ("use client")
│   │   ├── TenxyteProvider.tsx
│   │   └── hooks.ts       # useAuth, useUser (ré-export ou surcharge du JS-Core)
│   ├── shared/            # Types et configuration globale
│   └── index.ts
├── tests/
└── dist/                  # Dual Export (Server & Client envs)
```

---

## 3. Le Paradis de la Sécurité : Les Cookies HttpOnly

Contrairement à Firebase ou Supabase Client (qui mettent les JWT en RAM), la norme en SSR, c'est le cookie. 
Le SDK `@tenxyte/nextjs` s'attend à ce que **l'API Django Tenxyte soit configurée pour renvoyer des cookies**.

*Si l'API Django ne le fait pas, `@tenxyte/nextjs` implémente un Route Handler local (Next.js `/api/auth/callback`) qui reçoit le JSON backend, et fixe le Cookie depuis Next.js avant de rediriger l'utilisateur.*

---

## 4. Fonctionnalités Clés & API Développeur

La force de cette librairie réside dans les utilitaires Serveurs.

### A. Le Middleware (Protection des Routes en amont)
Le développeur exporte le middleware fourni par le SDK dans son `middleware.ts`. Next.js interceptera les requêtes *avant* de rendre la page, vérifiera le token dans les cookies, et redirigera instantanément vers `/login` si expiré.

```typescript
// middleware.ts (à la racine du projet Next.js)
import { createAuthMiddleware } from '@tenxyte/nextjs/server';

export const middleware = createAuthMiddleware({
  publicRoutes: ['/', '/login', '/about'], // Accessibles sans auth
  loginUrl: '/login', // Redirection en cas d'échec
  // Le middleware gère automatiquement la rotation du refresh_token ici !
});

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
};
```

### B. Lecture de Session Côté Serveur (Server Components)
Dans l'App Router (`app/dashboard/page.tsx`), le développeur peut récupérer l'utilisateur de manière synchrone via l'accès direct aux cookies de la requête.

```tsx
// app/dashboard/page.tsx (Server Component)
import { getSession } from '@tenxyte/nextjs/server';

export default async function Dashboard() {
  const { user, isAuthenticated } = await getSession();

  if (!isAuthenticated) return <LoginFallback />; // Alternative au middleware

  return (
    <div>
      <h1>Tableau de bord de {user.email} </h1>
      {/* Pas de <Loading> JSX nécessaires, page rendue côté serveur */}
    </div>
  );
}
```

### C. Le TenxyteProvider (Hybridation)
Même dans Next.js, on a besoin d'interactivité Client (ex: `<button onClick={login}>`).
Le SDK va hydrater le Provider avec la session Serveur initiale pour que les Hooks (`useUser`) aient la data *immédiatement*.

```tsx
// app/layout.tsx
import { TenxyteProvider } from '@tenxyte/nextjs/client';
import { getSession } from '@tenxyte/nextjs/server';

export default async function RootLayout({ children }) {
  const initialSession = await getSession();

  return (
    <html>
      <TenxyteProvider initialSession={initialSession}>
        <body>{children}</body>
      </TenxyteProvider>
    </html>
  );
}
```

---

## 5. Gestion Complexe : Le Refresh Token Intercepté

Le problème n°1 avec les frontends SSR (Next/Nuxt) est de "garder la session en vie".
Si un utilisateur visite `/dashboard` et que son `access_token` (cookie) a expiré depuis 2 minutes, mais que son `refresh_token` (cookie) est valide :

1. Le SDK intercepté dans le **Next.js Middleware** détecte l'expiration (ou reçoit une erreur 401 de Django).
2. Le Middleware effectue silencieusement une requête `POST /api/v1/auth/refresh/` vers l'API Tenxyte en passant le refresh_token.
3. Django répond avec un nouveau JWT.
4. **Le point critique :** Le SDK Next.js modifie la réponse sortante (Response Headers) pour assigner le nouveau Token dans les cookies du client (`Set-Cookie`) et laisse passer la requête vers la page `/dashboard`.
5. Bilan : L'utilisateur n'a rien vu, sa page se charge instantanément, sa session est prolongée de 1 heure.

---

## 6. Roadmap du Développement (`@tenxyte/nextjs`)

*Prérequis : Le Paquet `@tenxyte/js-core` est opérationnel.*

### Phase 1 : Architecture SSR & Cookies (Semaine 1)
- Initialisation du paquet (TS, configurations distinctes pour les entrypoints `server` et `client`).
- Implémentation du constructeur `getSession()` qui lit `next/headers` (cookies).
- Implémentation du `<TenxyteProvider>` hydraté côté client.

### Phase 2 : Middleware & Rafraîchissement (Semaine 2-3)
- Création du `createAuthMiddleware()` (complexe car Next.js Edge Runtime ne supporte pas toutes les APIs NodeJS, il faudra faire des appels API en Edge ou décoder le JWT manuellement).
- Finalisation de la logique de rotation de token silencieuse dans le Middleware.
- Développement des Server Actions de Login/Logout (permettent des formulaires interactifs sans JS côté client grâce à Next 14+).

### Phase 3 : Route Handlers Optionnels (Semaine 4)
- (Optionnel) Si l'API Django Tenxyte de l'utilisateur ne retourne pas de `Set-Cookie`, développement des Route Handlers (ex: `/api/tenxyte/login`) qui font passe-plat entre le navigateur (fixation du cookie par Next.js) et l'API native Tenxyte.

### Phase 4 : Documentation & Tests E2E (Semaine 5)
- La documentation devra expliquer clairement les différences "Quoi faire en Server Component" vs "Quoi faire en Client Component".
- Tests E2E stricts avec Cypress ou Playwright pour valider le cycle complet de rafraîchissement au travers du navigateur.

---

### Conclusion

La librairie `@tenxyte/nextjs` est infiniment plus puissante que son homologue React grâce aux fonctionnalités SSR. Elle devient une extension du serveur de l'API Tenxyte en agissant comme une véritable porte de sécurité intermédiaire. En couplant l'app-router Next.js aux solides fondations d'authentification de Tenxyte Backend, les développeurs Full-Stack auront une stack résiliente, SEO friendly et bulletproof.
