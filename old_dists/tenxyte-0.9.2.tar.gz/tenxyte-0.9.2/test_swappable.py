import os
import django
from django.conf import settings
from django.core.management import call_command

settings.configure(
    INSTALLED_APPS=[
        'django.contrib.auth',
        'django.contrib.contenttypes',
        'tenxyte',
    ],
    DATABASES={'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': ':memory:'}},
    USE_TZ=True,
)

django.setup()
print("Setup successful!")
call_command('tenxyte_quickstart')
