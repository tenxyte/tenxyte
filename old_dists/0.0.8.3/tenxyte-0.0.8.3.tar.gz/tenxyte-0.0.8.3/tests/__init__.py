"""
Tests pour Tenxyte.
"""
