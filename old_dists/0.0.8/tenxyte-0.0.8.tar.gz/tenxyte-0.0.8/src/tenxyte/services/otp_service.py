import logging
from typing import Optional, Tuple
from django.conf import settings
from ..models import User, OTPCode

logger = logging.getLogger(__name__)


class OTPService:
    """
    Service de gestion des codes OTP
    """

    def generate_email_verification_otp(self, user: User) -> OTPCode:
        """
        Génère un code OTP pour vérification email
        """
        # Invalider les anciens codes
        OTPCode.objects.filter(
            user=user,
            otp_type='email_verification',
            is_used=False
        ).update(is_used=True)

        return OTPCode.generate(user, 'email_verification', validity_minutes=15)

    def generate_phone_verification_otp(self, user: User) -> OTPCode:
        """
        Génère un code OTP pour vérification téléphone
        """
        # Invalider les anciens codes
        OTPCode.objects.filter(
            user=user,
            otp_type='phone_verification',
            is_used=False
        ).update(is_used=True)

        return OTPCode.generate(user, 'phone_verification', validity_minutes=10)

    def generate_password_reset_otp(self, user: User) -> OTPCode:
        """
        Génère un code OTP pour réinitialisation mot de passe
        """
        # Invalider les anciens codes
        OTPCode.objects.filter(
            user=user,
            otp_type='password_reset',
            is_used=False
        ).update(is_used=True)

        return OTPCode.generate(user, 'password_reset', validity_minutes=15)

    def verify_email_otp(self, user: User, code: str) -> Tuple[bool, str]:
        """
        Vérifie un code OTP pour email
        """
        try:
            otp = OTPCode.objects.filter(
                user=user,
                otp_type='email_verification',
                is_used=False
            ).latest('created_at')
        except OTPCode.DoesNotExist:
            return False, 'No verification code found'

        if otp.verify(code):
            user.is_email_verified = True
            user.save(update_fields=['is_email_verified'])
            return True, ''

        if otp.attempts >= otp.max_attempts:
            return False, 'Too many attempts. Please request a new code.'

        return False, 'Invalid code'

    def verify_phone_otp(self, user: User, code: str) -> Tuple[bool, str]:
        """
        Vérifie un code OTP pour téléphone
        """
        try:
            otp = OTPCode.objects.filter(
                user=user,
                otp_type='phone_verification',
                is_used=False
            ).latest('created_at')
        except OTPCode.DoesNotExist:
            return False, 'No verification code found'

        if otp.verify(code):
            user.is_phone_verified = True
            user.save(update_fields=['is_phone_verified'])
            return True, ''

        if otp.attempts >= otp.max_attempts:
            return False, 'Too many attempts. Please request a new code.'

        return False, 'Invalid code'

    def verify_password_reset_otp(self, user: User, code: str) -> Tuple[bool, str]:
        """
        Vérifie un code OTP pour réinitialisation mot de passe
        """
        try:
            otp = OTPCode.objects.filter(
                user=user,
                otp_type='password_reset',
                is_used=False
            ).latest('created_at')
        except OTPCode.DoesNotExist:
            return False, 'No reset code found'

        if otp.verify(code):
            return True, ''

        if otp.attempts >= otp.max_attempts:
            return False, 'Too many attempts. Please request a new code.'

        return False, 'Invalid code'

    def send_email_otp(self, user: User, otp: OTPCode, app_name: str = 'Tenxyte') -> bool:
        """
        Envoie le code OTP par email via le service email.

        Args:
            user: L'utilisateur
            otp: Le code OTP généré
            app_name: Nom de l'application (pour personnaliser l'email)

        Returns:
            True si l'envoi a réussi
        """
        if not user.email:
            logger.error(f"[OTP] User {user.id} has no email")
            return False

        from .email_service import EmailService

        try:
            email_service = EmailService()
            return email_service.send_otp_email(
                to_email=user.email,
                code=otp.code,
                otp_type=otp.otp_type,
                validity_minutes=15,
                app_name=app_name
            )
        except Exception as e:
            logger.error(f"[OTP] Email service error: {e}")
            return False

    def send_phone_otp(self, user: User, otp: OTPCode) -> bool:
        """
        Envoie le code OTP par SMS via le backend configuré.
        """
        phone_number = user.full_phone
        if not phone_number:
            logger.error(f"[OTP] User {user.id} has no phone number")
            return False

        from ..backends.sms import get_sms_backend

        message = f"Votre code de vérification: {otp.code}. Valide pendant 10 minutes."

        try:
            backend = get_sms_backend()
            return backend.send_sms(phone_number, message)
        except Exception as e:
            logger.error(f"[OTP] SMS backend error: {e}")
            return False
