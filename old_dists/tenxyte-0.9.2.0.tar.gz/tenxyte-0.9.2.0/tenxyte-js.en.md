# Core SDK Development Plan: `@tenxyte/js-core`

## Table of Contents
- [1. Goal and Global Vision](#1-goal-and-global-vision)
- [2. Repository Structure](#2-repository-structure)
- [3. Key Features and Responsibilities](#3-key-features-and-responsibilities)
  - [A. The Main Client (TenxyteClient)](#a-the-main-client-tenxyteclient)
  - [B. Interceptors and Lifecycle Management (The Heart of the SDK)](#b-interceptors-and-lifecycle-management-the-heart-of-the-sdk)
  - [C. Business Abstractions (Exposed Methods)](#c-business-abstractions-exposed-methods)
- [4. State and Storage Management (Storage Strategies)](#4-state-and-storage-management-storage-strategies)
  - [Available Strategies](#available-strategies)
  - [Important Notes](#important-notes)
  - [Storing Raw AgentToken](#storing-raw-agenttoken)
- [5. Error Management, Rate Limiting and Lockout](#5-error-management-rate-limiting-and-lockout)
- [6. Full Module Reference](#6-full-module-reference)
  - [6.A — auth.ts Module](#6a--authts-module)
  - [6.B — security.ts Module](#6b--securityts-module)
  - [6.C — rbac.ts Module](#6c--rbacts-module)
  - [6.D — user.ts Module](#6d--userts-module)
  - [6.E — b2b.ts Module (Organizations)](#6e--b2bts-module-organizations)
  - [6.F — ai.ts Module (AIRS — AI Responsibility & Security)](#6f--aits-module-airs--ai-responsibility--security)
- [7. Event System](#7-event-system)
  - [Event Table](#event-table)
- [8. DeviceInfo Helper](#8-deviceinfo-helper)
- [9. TypeScript Interfaces (types/)](#9-typescript-interfaces-types)
- [10. Repository Roadmap](#10-repository-roadmap)
  - [Phase 1: Architectural Foundation & HTTP Engine (Weeks 1-2)](#phase-1-architectural-foundation--http-engine-weeks-1-2)
  - [Phase 2: Core Authentication Modules & RBAC (Weeks 2-3)](#phase-2-core-authentication-modules--rbac-weeks-2-3)
  - [Phase 3: Advanced Security, B2B, and AIRS (Weeks 4-5)](#phase-3-advanced-security-b2b-and-airs-weeks-4-5)
  - [Phase 4: Documentation & Tests (Week 6)](#phase-4-documentation--tests-week-6)
- [Conclusion](#conclusion)

---

This document defines the complete strategy, architecture, and roadmap for creating the `tenxyte-js` repository (published as `@tenxyte/js-core`). This business SDK is the core upon which all Tenxyte front-end implementations (HTML Components, React, Vue, Vanilla JS) will be built.

---

## 1. Goal and Global Vision

**Vision:** Provide an agnostic, robust, and typed JavaScript/TypeScript client to interact with Tenxyte's REST API. The SDK must abstract all complexity related to security (JWT management, automatic token rotation, multi-application) so that the front-end developer only needs to handle simple methods (e.g., `tx.auth.login()`).

**Architectural Principles:**
- **TypeScript First:** Strict typing of all requests and responses (ideally based on Tenxyte's OpenAPI Schema).
- **Zero Heavy Dependencies (or Minimal):** Native use of the browser's `fetch` API, or a very lightweight wrapper.
- **Modular (Tree-shakable):** Architecture allowing for only necessary modules to be imported (e.g., WebAuthn code is only included if used).
- **Security by Default:** Automatic interceptors for Headers (`X-Access-Key`, `Authorization`) and completely transparent `refresh_token` flow management.

---

## 2. Repository Structure

Proposed NPM package name: `@tenxyte/js-core`

```text
tenxyte-js/
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts                # Main entry point (exports TenxyteClient)
│   ├── client.ts               # Fetch configuration and global interceptors
│   ├── config.ts               # Options management (App Key, Base URL)
│   ├── storage/                # Token storage strategies
│   │   ├── memory.ts
│   │   ├── localStorage.ts
│   │   ├── cookie.ts           # (Useful for a Backend-For-Frontend approach)
│   │   └── index.ts
│   ├── modules/                # Sub-modules corresponding to Django routers
│   │   ├── auth.ts             # Login, register, logout, OTP, Magic Links
│   │   ├── security.ts         # 2FA, Passkeys (WebAuthn), Password Reset
│   │   ├── user.ts             # Personal profile (/me)
│   │   ├── rbac.ts             # Roles and Permissions
│   │   ├── b2b.ts              # Organizations, Switcher
│   │   └── ai.ts               # AIRS — AgentToken, Circuit Breaker, HITL, Budget
│   ├── utils/                  # Helpers (partial JWT decoding, HTTP error parsing)
│   │   └── device_info.ts      # Device fingerprinting logic
│   └── types/                  # Generated interfaces (TenxyteUser, Tokens, etc.)
├── tests/                      # Unit tests (Vitest or Jest)
└── dist/                       # Compiled files (ESM, CJS, d.ts)
```

---

## 3. Key Features and Responsibilities

### A. The Main Client (`TenxyteClient`)
The single entry point. It is initialized at application launch (React, Vue, or pure HTML) with application credentials.

```typescript
import { TenxyteClient } from '@tenxyte/js-core';

const tx = new TenxyteClient({
  baseURL: 'https://api.my-backend.com/api/v1',
  appKey: 'my_app_key',
  // ⚠️ Include appSecret ONLY in a server-side context (Next.js, BFF).
  // In a public SPA (React, Vue, Vanilla JS), never expose appSecret.
  // appSecret: 'my_app_secret',
  storage: 'localStorage' // or 'memory', 'cookie'
});
```

### B. Interceptors and Lifecycle Management (The Heart of the SDK)
The SDK intercepts all network requests to the Tenxyte API and automatically manages:

1. **Header Injection:**
   - `X-Access-Key` (and `X-Access-Secret` if provided server-side): added to every request.
   - `Authorization: Bearer <token>`: added if a valid user session is present in storage.
   - `Authorization: AgentBearer <token>`: injected instead of the classic Bearer when `tx.ai.setAgentToken()` is active (AIRS agent mode).
   - `X-Org-Slug: <slug>`: automatically injected after calling `tx.b2b.switchOrganization()`.
   - `X-Prompt-Trace-ID: <traceId>`: injected if `tx.ai.setTraceId()` is active (AIRS forensic traceability).

2. **Transparent Token Rotation (Refresh Flow):**
   - If the API returns a `401` error indicating the `access_token` has expired, the SDK pauses request X.
   - It calls the `/api/v1/auth/refresh/` endpoint with the `refresh_token`.
   - If successful: the SDK updates the Storage, then replays request X invisibly to the UI user.
   - If failed: it emits the `tx.on('session:expired', ...)` event to allow the front-end to redirect to the login page.

   > **Critical Case:** if multiple requests are sent simultaneously during token expiration, the SDK makes only **one** refresh call and releases all pending requests with the new common token (queue pattern).

### C. Business Abstractions (Exposed Methods)
The developer uses semantic promises instead of manipulating the API directly:

- `tx.auth.loginWithEmail(email, password)` — classic authentication
- `tx.auth.loginWithSocial(provider, payload)` — OAuth2 (Google, GitHub…)
- `tx.auth.requestMagicLink(email, validationUrl)` — passwordless magic link
- `tx.security.setup2FA()` — initialize TOTP 2FA
- `tx.security.registerWebAuthn()` — register a Passkey
- `tx.security.authenticateWebAuthn()` — authenticate via Passkey
- `tx.user.getProfile()` — connected user profile
- `tx.rbac.hasRole('admin')` — synchronous check from the JWT (no network call)
- `tx.b2b.switchOrganization('acme-corp')` — activate an organization context (injects `X-Org-Slug`)
- `tx.ai.createAgentToken(data)` — create a delegated token for an AI agent (AIRS)
- `tx.ai.reportUsage(tokenId, usage)` — report LLM consumption for budget tracking

---

## 4. State and Storage Management (Storage Strategies)

The implementation relies on a common `IStorageMechanism` interface to adapt to various environments:

### Available Strategies

| Strategy | `storage` value | XSS-safe | Persistence | SSR-compatible | Recommended Usage |
|---|---|---|---|---|---|
| **In-Memory** | `'memory'` | ✅ Yes | ❌ Lost on reload | ✅ Yes (Node.js) | Recommended default — high security |
| **LocalStorage** | `'localStorage'` | ⚠️ No | ✅ Yes | ❌ No (`window` absent) | Classic SPA with desired persistence |
| **JS Cookie** | `'cookie'` | ⚠️ No | ✅ Yes (configurable) | ⚠️ Partial | BFF context, CSRF token managed by SDK |

> **⚠️ Never expose `appSecret` in a public SPA.** `appSecret` is reserved for server-side contexts (Next.js Route Handlers, BFF). In a pure SPA (React, Vue, Vanilla JS), only use `appKey`. To entirely disable application-based authentication on the backend: `TENXYTE_APPLICATION_AUTH_ENABLED = False`.

### Important Notes

**In-Memory:** tokens live in RAM. Immune to XSS theft, but the user is logged out on every page reload unless a valid `refresh_token` is kept in a secure cookie (mixed strategy recommended in production).

**LocalStorage:** tokens persist between reloads. Ideal for a SPA without extreme security requirements, but exposed to XSS.

**JS Cookie:** the SDK stores and reads tokens from cookies accessible in JS (non-`HttpOnly`). The SDK manages automatic CSRF token sending on mutations. **Do not confuse with `HttpOnly` cookies** (which are invisible to JS and thus outside SDK control — they are sent automatically by the browser without SDK intervention).

**SSR (Next.js, Nuxt.js):** in a server context, `window` and `localStorage` are unavailable. Use the `'memory'` strategy or implement a custom adapter (`IStorageMechanism`). The `@tenxyte/nextjs` and `@tenxyte/nuxt` SDKs provide their own pre-integrated SSR adapters.

### Storing Raw `AgentToken`

After `tx.ai.createAgentToken()`, the raw token is returned **only once** (never restorable from the API — only the SHA-256 hash is persisted backend-side). It is the integrator's responsibility to store it securely (environment variable, secret manager, etc.) before the creation session ends.

```typescript
const { token } = await tx.ai.createAgentToken({ agent_id: 'my-bot', permissions: [] });
// ⚠️ Store `token` immediately — it will no longer be retrievable via the API.
// Example: await secretManager.set('agent-token-id-42', token);
tx.ai.setAgentToken(token); // Activates AgentBearer mode for subsequent requests
```

---

## 5. Error Management, Rate Limiting and Lockout

The SDK standardizes Django REST Framework (DRF) error returns into rich JavaScript exception instances. Each error exposes `error` (human message), `code` (machine identifier), and optionally `details` (per-field validation errors) fields.

| Error Class | HTTP Code | Typical backend `code` | Additional Fields |
|---|---|---|---|
| `TenxyteAuthError` | 401 | `LOGIN_FAILED`, `INVALID_CREDENTIALS`, `2FA_REQUIRED`, `INVALID_2FA_CODE`, `ACCOUNT_LOCKED`, `REFRESH_FAILED`, `REFRESH_EXPIRED`, `REFRESH_BLACKLISTED` | `retry_after` (if lockout) |
| `TenxytePermissionError` | 403 | `PERMISSION_DENIED`, `ADMIN_2FA_SETUP_REQUIRED`, `APP_AUTH_REQUIRED`, `AIRS_DISABLED`, `AGENT_TOKEN_SUSPENDED` | — |
| `TenxyteValidationError` | 400 | `VALIDATION_ERROR`, `PASSWORD_BREACHED`, `REGISTRATION_FAILED` | `details`: `{field: [messages]}` |
| `TenxyteSessionError` | 409 | `SESSION_LIMIT_EXCEEDED`, `DEVICE_LIMIT_EXCEEDED` | — |
| `TenxyteRateLimitError` | 429 | `RATE_LIMITED` | `retry_after` (seconds, in body AND `Retry-After` header) |
| `TenxyteNotFoundError` | 404 | `ORG_NOT_FOUND`, `AGENT_NOT_FOUND` | — |
| `TenxyteAIRSError` | 403 | `BUDGET_EXCEEDED`, `RATE_LIMIT_EXCEEDED`, `HEARTBEAT_MISSING` | `reason` (suspension reason) |

> **Note on `ACCOUNT_LOCKED`**: returned via HTTP **401** (not 423), with a `retry_after` field in seconds in the body indicating how long before retrying is possible.

> **Note on `2FA_REQUIRED`**: returned via HTTP **401** (not 403), with a `requires_2fa: true` field to differentiate from a simple `LOGIN_FAILED`.

```typescript
try {
  await tx.auth.loginWithEmail(email, password);
} catch (e) {
  if (e instanceof TenxyteAuthError) {
    if (e.code === 'ACCOUNT_LOCKED') {
      // e.retryAfter → seconds before retrying (backend side: LOCKOUT_DURATION_MINUTES × 60)
      showMessage(`Account locked. Try again in ${e.retryAfter}s.`);
    } else if (e.code === '2FA_REQUIRED') {
      // Ask for TOTP code, then restart with totpCode
      const code = await promptUserForTOTP();
      await tx.auth.loginWithEmail(email, password, { totpCode: code });
    } else if (e.code === 'INVALID_2FA_CODE') {
      showMessage('Invalid 2FA code. Check your authenticator app.');
    }
  } else if (e instanceof TenxyteValidationError) {
    // e.details → { email: ['This email is invalid.'] }
    renderFormErrors(e.details);
  } else if (e instanceof TenxyteRateLimitError) {
    // e.retryAfter → seconds (also in the HTTP Retry-After header)
    showMessage(`Too many attempts. Try again in ${e.retryAfter}s.`);
  } else if (e instanceof TenxyteAIRSError) {
    // e.code → 'BUDGET_EXCEEDED' | 'RATE_LIMIT_EXCEEDED' | 'HEARTBEAT_MISSING'
    // e.reason → agent token suspension reason
    handleAgentSuspension(e);
  }
}
```

---

## 6. Full Module Reference

### 6.A — `auth.ts` Module

Covers main authentication, session, and passwordless flows. All methods return a `Promise`.

```typescript
// Classic Authentication
tx.auth.loginWithEmail(email: string, password: string, opts?: {
  totpCode?: string;        // Mandatory if 2FA is enabled
  deviceInfo?: string;      // Fingerprinting string (see §8)
}): Promise<{ user: TenxyteUser; tokens: TokenPair }>

tx.auth.loginWithPhone(
  phoneCountryCode: string, // e.g., "+33"
  phoneNumber: string,      // e.g., "612345678" (without prefix)
  password: string,
  opts?: { totpCode?: string; deviceInfo?: string }
): Promise<{ user: TenxyteUser; tokens: TokenPair }>

// Registration
tx.auth.register(data: {
  email?: string;
  phone_country_code?: string;
  phone_number?: string;
  password: string;
  first_name?: string;
  last_name?: string;
  login?: boolean;           // If true, also returns TokenPair
  device_info?: string;
}): Promise<{ user: TenxyteUser; verification_required: { email: boolean; phone: boolean }; tokens?: TokenPair }>

// Session
tx.auth.logout(refreshToken: string): Promise<{
  message: string;
  access_token_blacklisted: boolean;
  refresh_token_revoked: boolean;
}>
tx.auth.logoutAll(): Promise<{
  message: string;
  devices_logged_out: number;    // Number of logged-out devices
  access_token_blacklisted: boolean;
}>
tx.auth.refresh(refreshToken: string): Promise<TokenPair>  // Called automatically by interceptor

// Passwordless — Magic Link
// requestMagicLink sends an email with a one-time use link (never confirms account existence)
tx.auth.requestMagicLink(email: string, validationUrl: string): Promise<{
  message: string;             // Always "If this email is registered, a magic link has been sent."
  expires_in_minutes: number;  // Validity duration (configurable via TENXYTE_MAGIC_LINK_EXPIRY_MINUTES)
  sent_to: string;             // Masked email (anti-enumeration security)
}>

// verifyMagicLink: GET call to /auth/magic-link/verify/?token=<token> endpoint
// The token is passed as a query param, one-time use, invalid after use
tx.auth.verifyMagicLink(token: string): Promise<{
  user: TenxyteUser;
  tokens: TokenPair;
  message: string;
}>

// Social / OAuth2
// Direct Flow: POST /auth/social/<provider>/ with access_token, code+redirect_uri, or id_token (Google only)
tx.auth.loginWithSocial(
  provider: 'google' | 'github' | 'microsoft' | 'facebook',
  payload: { access_token?: string; id_token?: string; code?: string; redirect_uri?: string },
  opts?: { deviceInfo?: string }
): Promise<{ user: TenxyteUser; tokens: TokenPair; is_new_user: boolean; provider: string }>

// Callback Flow: GET /auth/social/<provider>/callback/?code=<code>&redirect_uri=<uri>
// Used when the provider redirects the browser to your app after authorization
tx.auth.handleSocialCallback(
  provider: 'google' | 'github' | 'microsoft' | 'facebook',
  code: string,
  redirectUri: string,
  opts?: { state?: string }
): Promise<{ access: string; refresh: string; provider: string; is_new_user: boolean }>
```

#### Interactive Login with 2FA Case

When login returns `code: '2FA_REQUIRED'`, the SDK throws a `TenxyteAuthError` (HTTP 401) which the front-end intercepts to display the TOTP form:

```typescript
try {
  await tx.auth.loginWithEmail(email, password);
} catch (e) {
  if (e instanceof TenxyteAuthError && e.code === '2FA_REQUIRED') {
    // Ask the user for the TOTP code, then restart:
    await tx.auth.loginWithEmail(email, password, { totpCode: userInputCode });
  }
}
```

---

### 6.B — `security.ts` Module

Covers 2FA (TOTP), verification OTP, password management, and Passkeys (WebAuthn/FIDO2).

#### 2FA Sub-module (TOTP)

```typescript
// Get status
tx.security.get2FAStatus(): Promise<{ is_enabled: boolean; backup_codes_remaining: number }>

// Setup flow (3 steps)
// 1. Initiate: returns QR code + backup codes to be displayed ONLY ONCE
tx.security.setup2FA(): Promise<{
  message: string;           // Instructions for the user
  secret: string;            // base32 TOTP secret (for manual entry)
  manual_entry_key: string;  // Secret alias, more readable format
  qr_code: string;           // data:image/png;base64,...
  provisioning_uri: string;  // otpauth://totp/...
  backup_codes: string[];    // 10 alphanumeric one-time use codes
  warning: string;           // "Save the backup codes securely. They will not be shown again."
}>

// 2. Confirm with the first TOTP code from the authenticator app
tx.security.confirm2FA(totpCode: string): Promise<{
  message: string;       // "2FA enabled successfully"
  is_enabled: boolean;   // true
  enabled_at: string;    // ISO 8601 datetime
}>

// 3. (Later) Disable — requires TOTP code OR backup code + password
tx.security.disable2FA(totpCode: string, password: string): Promise<{
  message: string;
  is_enabled: boolean;            // false
  disabled_at: string;            // ISO 8601 datetime
  backup_codes_invalidated: boolean;
}>

// Regenerate backup codes (invalidates old ones — requires TOTP code)
tx.security.regenerateBackupCodes(totpCode: string): Promise<{
  message: string;
  backup_codes: string[];   // 10 new [A-Z0-9]{8} codes
  codes_count: number;      // 10
  generated_at?: string;    // ISO 8601 datetime (if sent)
  warning: string;          // "Save these codes securely. They will not be shown again."
}>
```

#### Verification OTP Sub-module (Email / Phone)

```typescript
// Request code sending — returns generated OTP metadata
tx.security.requestOtp(type: 'email' | 'phone'): Promise<{
  message: string;          // "OTP sent successfully"
  otp_id: number;           // OTPCode DB ID (useful for debugging / tracking)
  expires_at: string;       // ISO 8601 — expiration (configurable: email 15min, phone 10min)
  channel: 'email' | 'phone';
  masked_recipient: string; // e.g., "u***@example.com" or "***5678"
}>

// Email verification — validates the code, updates is_email_verified on User
tx.security.verifyOtpEmail(code: string): Promise<{
  message: string;       // "Email verified successfully"
  email_verified: boolean; // true
  verified_at: string;   // ISO 8601
}>

// Phone verification
tx.security.verifyOtpPhone(code: string): Promise<{
  message: string;       // "Phone verified successfully"
  phone_verified: boolean; // true
  verified_at: string;   // ISO 8601
  phone_number: string;  // International format e.g., "+33612345678"
}>
```

#### Password Sub-module

```typescript
// Reset (without being logged in)
// Never reveals account existence (anti-enumeration)
tx.security.resetPasswordRequest(target: { email: string } | { phone_country_code: string; phone_number: string }): Promise<{
  message: string;  // "If the account exists, a reset code has been sent"
}>

// Confirm reset — automatically revokes all user tokens
tx.security.resetPasswordConfirm(data: {
  email?: string;
  phone_country_code?: string;
  phone_number?: string;
  otp_code: string;
  new_password: string;
  confirm_password: string;   // Must match new_password
}): Promise<{ message: string }>  // "Password reset successfully"

// Change (logged in) — invalidates other sessions, keeps current session
tx.security.changePassword(currentPassword: string, newPassword: string): Promise<{
  message: string;  // "Password changed successfully"
}>

// Utilities — strength check (without being logged in, useful for real-time feedback)
tx.security.checkPasswordStrength(password: string, email?: string): Promise<{
  score: number;         // 0-4 (zxcvbn)
  strength: string;      // 'Weak' | 'Fair' | 'Strong' | 'Very Strong'
  is_valid: boolean;
  errors: string[];
  requirements: {        // Current backend configuration
    min_length: number;
    require_lowercase: boolean;
    require_uppercase: boolean;
    require_numbers: boolean;
    require_special: boolean;
  };
}>
tx.security.getPasswordRequirements(): Promise<{
  requirements: Record<string, boolean | number>;
  min_length: number;
  max_length: number;
}>
```

#### WebAuthn / Passkeys (FIDO2) Sub-module

The SDK encapsulates the complexity of the browser's `navigator.credentials` API and the `begin/complete` back-and-forth with the backend:

```typescript
// Register a new Passkey (requires Bearer — logged-in user)
tx.security.registerWebAuthn(deviceName?: string): Promise<{
  message: string;          // "Passkey registered successfully"
  credential: {
    id: number;             // DB ID (integer, not the FIDO2 credential_id)
    device_name: string;
    created_at: string;     // ISO 8601
  }
}>
// Internally (4 steps):
// 1. POST /webauthn/register/begin/ → challenge + options
// 2. navigator.credentials.create(options)
// 3. POST /webauthn/register/complete/ { challenge_id, credential, device_name? } → 201

// Authenticate with a Passkey (without Bearer — no prior session)
// email optional: if absent, uses resident keys (username-less)
tx.security.authenticateWebAuthn(email?: string): Promise<{
  access: string;
  refresh: string;
  user: TenxyteUser;
  message: string;
  credential_used: string;
}>
// Internally (4 steps):
// 1. POST /webauthn/authenticate/begin/ { email? } → challenge
// 2. navigator.credentials.get(options)
// 3. POST /webauthn/authenticate/complete/ { challenge_id, credential } → JWT

// List connected user's passkeys
tx.security.listWebAuthnCredentials(): Promise<{
  credentials: Array<{
    id: number;                    // DB ID (integer)
    device_name: string;
    created_at: string;
    last_used_at: string | null;
    authenticator_type: string;    // 'platform' | 'cross-platform'
    is_resident_key: boolean;
  }>;
  count: number;
}>

// Delete a Passkey — returns HTTP 204 No Content (no body)
tx.security.deleteWebAuthnCredential(credentialId: number): Promise<void>
```

---

### 6.C — `rbac.ts` Module

The RBAC module distinguishes two modes: **synchronous** (local reading from JWT payload, no network call) and **asynchronous** (API call for fresh data or administration).

```typescript
// ─── Synchronous checks (from JWT in memory, no network call) ───
tx.rbac.hasRole(roleCode: string): boolean
tx.rbac.hasAnyRole(roleCodes: string[]): boolean
tx.rbac.hasAllRoles(roleCodes: string[]): boolean
tx.rbac.hasPermission(permCode: string): boolean
tx.rbac.hasAnyPermission(permCodes: string[]): boolean
tx.rbac.hasAllPermissions(permCodes: string[]): boolean
tx.rbac.getRolesFromToken(): string[]       // Role codes from current JWT
tx.rbac.getPermissionsFromToken(): string[] // Permissions from current JWT

// ─── Current user's RBAC profile ───
// GET /auth/users/<user_id>/roles/  (requires permission: users.roles.view)
tx.rbac.getMyRoles(): Promise<{ user_id: string; roles: Role[] }>

// ─── Roles CRUD (requires roles.* permissions) ───
// GET /auth/roles/      → roles.view    POST /auth/roles/ → roles.create
tx.rbac.listRoles(params?: { search?: string; is_default?: boolean; page?: number }): Promise<PaginatedResponse<Role>>
tx.rbac.createRole(data: { code: string; name: string; description?: string; permission_codes?: string[]; is_default?: boolean }): Promise<Role>

// GET /auth/roles/<id>/  → roles.view   PUT → roles.update   DELETE → roles.delete
tx.rbac.getRole(roleId: string): Promise<Role>
tx.rbac.updateRole(roleId: string, data: Partial<{ name: string; description: string; permission_codes: string[]; is_default: boolean }>): Promise<Role>
tx.rbac.deleteRole(roleId: string): Promise<{ message: string }>  // HTTP 200

// ─── Role Permissions (requires: roles.manage_permissions) ───
// GET /auth/roles/<id>/permissions/
tx.rbac.getRolePermissions(roleId: string): Promise<{ role_id: string; role_code: string; permissions: Permission[] }>
// POST /auth/roles/<id>/permissions/ — accepts MULTIPLE codes at once
tx.rbac.addPermissionsToRole(roleId: string, permCodes: string[]): Promise<{
  message: string; added: string[]; already_assigned?: string[]; role_code: string; permissions: Permission[];
}>
// DELETE /auth/roles/<id>/permissions/
tx.rbac.removePermissionsFromRole(roleId: string, permCodes: string[]): Promise<{
  message: string; removed: string[]; not_removed?: string[]; role_code: string; permissions: Permission[];
}>

// ─── Permissions CRUD (requires permissions.* permissions) ───
tx.rbac.listPermissions(params?: { search?: string; parent?: string; page?: number }): Promise<PaginatedResponse<Permission>>
tx.rbac.createPermission(data: { code: string; name: string; description?: string; parent_code?: string }): Promise<Permission>
tx.rbac.getPermission(permId: string): Promise<Permission>
tx.rbac.updatePermission(permId: string, data: Partial<{ name: string; description: string }>): Promise<Permission>
tx.rbac.deletePermission(permId: string): Promise<{ message: string }>  // HTTP 200

// ─── User Roles (requires: users.roles.*) ───
// POST → users.roles.assign   DELETE ?role_code=… → users.roles.remove
tx.rbac.assignRoleToUser(userId: string, roleCode: string): Promise<{
  message: string;   // "Role assigned"
  roles: string[];   // Updated list of user's role codes
}>
tx.rbac.removeRoleFromUser(userId: string, roleCode: string): Promise<{
  message: string;   // "Role removed"
  roles: string[];   // Updated list of user's role codes
}>

// ─── Direct User Permissions (requires: users.permissions.*) ───
// POST → users.permissions.assign   DELETE → users.permissions.remove
// ⚠️ Takes an ARRAY of codes, not a single one
tx.rbac.assignPermissionsToUser(userId: string, permCodes: string[]): Promise<{
  message: string; added: string[]; already_assigned?: string[];
  user_id: string; direct_permissions: Permission[];
}>
tx.rbac.removePermissionsFromUser(userId: string, permCodes: string[]): Promise<{
  message: string; removed: string[]; not_removed?: string[];
  user_id: string; direct_permissions: Permission[];
}>
// GET /auth/users/<id>/permissions/ → users.permissions.view
tx.rbac.getUserDirectPermissions(userId: string): Promise<{
  user_id: string; email: string;
  direct_permissions: Permission[];
  all_permissions: string[];   // direct + inherited from roles
}>
```

**Usage example in a Vanilla JS component:**
```typescript
// Client-side conditional check (sync, instant)
if (tx.rbac.hasRole('admin')) {
  document.getElementById('admin-panel').style.display = 'block';
}

// Assign a role via API (requires users.roles.assign)
const result = await tx.rbac.assignRoleToUser('uuid-user', 'editor');
console.log(result.roles); // ['editor', 'default_user']

// Add multiple direct permissions at once
await tx.rbac.assignPermissionsToUser('uuid-user', ['reports.view', 'logs.view']);
```
---
### 6.D — `user.ts` Module

#### Profile Sub-module (Connected User)

```typescript
// GET /auth/me/ — Complete profile of the current user
tx.user.getProfile(): Promise<TenxyteUser>

// PATCH /auth/me/ — Partial update (provided fields only)
// ⚠️ PATCH, not POST. Phone is passed in a single "phone" field in international format.
tx.user.updateProfile(data: Partial<{
  first_name: string;          // max 30 characters
  last_name: string;           // max 30 characters
  username: string;            // max 20 characters, alphanumeric + underscores
  phone: string;               // International format e.g., "+33612345678"
  bio: string;                 // max 500 characters
  timezone: string;            // e.g., "Europe/Paris"
  language: string;            // e.g., "en"
  custom_fields: Record<string, unknown>;
}>): Promise<{
  message: string;                   // "Profile updated successfully"
  updated_fields: string[];          // List of modified fields
  user: TenxyteUser;
  verification_required: {
    email_changed: boolean;          // If true → email must be re-verified
    phone_changed: boolean;          // If true → phone must be re-verified
  };
}>

// GET /auth/me/roles/ — Roles and permissions of the current account (org-aware via X-Org-Slug)
tx.user.getMyRoles(): Promise<{
  roles: string[];        // Role codes (e.g., ["admin", "editor"])
  permissions: string[];  // Permission codes (e.g., ["users.view", "reports.export"])
}>

// POST /auth/me/avatar/ — Multipart upload (JPEG, PNG, WebP — max 5MB)
// Image is automatically resized to 400x400px
tx.user.uploadAvatar(file: File): Promise<{
  message: string;       // "Avatar uploaded successfully"
  avatar_url: string;
  file_size: number;     // Bytes
  dimensions: { width: 400; height: 400 };
}>

// DELETE /auth/me/ — Permanent account deletion (GDPR)
// Blocked if the user is the sole owner of an organization
tx.user.deleteAccount(data: {
  confirmation: 'DELETE MY ACCOUNT';  // Mandatory exact text
  password: string;                    // Current password
  reason?: string;
}): Promise<{
  message: string;
  account_deleted: boolean;
  deleted_at: string;         // ISO 8601
  data_removed: boolean;
  organizations_affected: string[];  // Slugs of organizations where user was owner
  recovery_possible: false;
  final_notification_sent: boolean;
}>
```

#### Administration Sub-module (Admin Users)

> All these endpoints require the corresponding `users.*` permissions. Restricted to administrators.

```typescript
// GET /auth/admin/users/ — Paginated list with filters (requires: users.view)
tx.user.listUsers(params?: {
  search?: string;         // Searching in email, first_name, last_name
  is_active?: boolean;
  is_locked?: boolean;
  is_banned?: boolean;
  is_deleted?: boolean;
  is_email_verified?: boolean;
  is_2fa_enabled?: boolean;
  role?: string;           // Filter by role code
  date_from?: string;      // YYYY-MM-DD
  date_to?: string;
  ordering?: string;       // email | created_at | last_login | first_name (prefix - for DESC)
  page?: number;
  page_size?: number;      // max 100
}): Promise<PaginatedResponse<AdminUser>>

// GET /auth/admin/users/<id>/ (requires: users.view)
tx.user.getUser(userId: string): Promise<AdminUser>

// PATCH /auth/admin/users/<id>/ (requires: users.update)
// Allows modifying is_active, is_staff, max_sessions, max_devices, etc.
tx.user.adminUpdateUser(userId: string, data: Partial<{
  first_name: string; last_name: string; is_active: boolean;
  is_staff: boolean; max_sessions: number; max_devices: number;
}>): Promise<AdminUser>

// DELETE /auth/admin/users/<id>/ — soft delete / GDPR anonymization (requires: users.delete)
tx.user.adminDeleteUser(userId: string): Promise<{
  message: string;   // "User soft-deleted successfully"
  user_id: string;
}>

// POST /auth/admin/users/<id>/ban/ (requires: users.ban)
tx.user.banUser(userId: string, data?: { reason?: string }): Promise<{
  message: string;   // "User banned successfully"
  user: AdminUser;
}>
// POST /auth/admin/users/<id>/unban/ (requires: users.ban)
tx.user.unbanUser(userId: string): Promise<{
  message: string;   // "User unbanned successfully"
  user: AdminUser;
}>

// POST /auth/admin/users/<id>/lock/ (requires: users.lock)
tx.user.lockUser(userId: string, data?: {
  duration_minutes?: number;  // Default: 30, max: 43200 (30 days)
  reason?: string;
}): Promise<{
  message: string;   // "User locked for X minutes"
  user: AdminUser;
}>
// POST /auth/admin/users/<id>/unlock/ (requires: users.lock)
tx.user.unlockUser(userId: string): Promise<{
  message: string;   // "User unlocked successfully"
  user: AdminUser;
}>
```

---

### 6.E — `b2b.ts` Module (Organizations)

Opt-in feature. Enabled backend-side with `TENXYTE_ORGANIZATIONS_ENABLED = True`. The SDK automatically includes the `X-Org-Slug` header on all requests when an organization is active via `switchOrganization`.

```typescript
// ─── Selecting the active org context (injects X-Org-Slug on all subsequent requests) ───
tx.b2b.switchOrganization(slug: string): void
tx.b2b.clearOrganization(): void
tx.b2b.getCurrentOrganizationSlug(): string | null

// ─── Organizations CRUD ───

// POST /auth/organizations/ — slug is OPTIONAL (auto-generated if absent)
tx.b2b.createOrganization(data: {
  name: string;
  slug?: string;          // Optional, auto-generated if absent
  description?: string;
  parent_id?: number;     // Parent org ID (max 5 hierarchy levels)
  metadata?: Record<string, unknown>;
  max_members?: number;   // 0 = unlimited (default)
}): Promise<Organization>  // HTTP 201

// GET /auth/organizations/ — Returns a PAGINATED RESPONSE (not a direct array)
tx.b2b.listMyOrganizations(params?: {
  search?: string;   // Search in name and slug
  is_active?: boolean;
  parent?: string;   // parent slug (null = roots)
  ordering?: string; // name | slug | created_at (prefix - for DESC)
  page?: number;
  page_size?: number;
}): Promise<PaginatedResponse<Organization>>

// GET /auth/organizations/<slug>/ — via X-Org-Slug header (members only)
// also returns user_role, user_permissions, metadata, children
tx.b2b.getOrganization(slug: string): Promise<Organization>

// PATCH /auth/organizations/<slug>/ — requires admin rights in the org
tx.b2b.updateOrganization(slug: string, data: Partial<{
  name: string;
  slug: string;          // Slug rename (changes the URL)
  description: string;
  parent_id: number | null;
  metadata: Record<string, unknown>;
  max_members: number;
  is_active: boolean;
}>): Promise<Organization>

// DELETE /auth/organizations/<slug>/ — soft delete, requires owner
// Blocked if the org has children
tx.b2b.deleteOrganization(slug: string): Promise<{
  message: string;  // "Organization deleted successfully"
}>

// GET /auth/organizations/<slug>/tree/ — Complete hierarchical tree
tx.b2b.getOrganizationTree(slug: string): Promise<OrgTreeNode>

// ─── Member management ───

// GET /auth/organizations/<slug>/members/ (org members only)
tx.b2b.listMembers(slug: string, params?: {
  search?: string;  // email, first name, last name
  role?: 'owner' | 'admin' | 'member';
  status?: 'active' | 'inactive' | 'pending';
  ordering?: string; // joined_at | -joined_at | user__email | -user__email
  page?: number;
  page_size?: number;
}): Promise<PaginatedResponse<OrgMembership>>

// POST — body: { user_id, role_code } — requires permission: org.members.invite
// ⚠️ owner not allowed as role_code for add_member
tx.b2b.addMember(slug: string, data: {
  user_id: number;
  role_code: string;   // 'admin' | 'member' (owner forbidden here)
}): Promise<OrgMembership>  // HTTP 201

// PATCH — requires permission: org.members.manage
tx.b2b.updateMemberRole(slug: string, userId: number, roleCode: string): Promise<OrgMembership>

// DELETE — returns { message } HTTP 200, requires permission: org.members.remove
// A member can also remove themselves (self-removal)
tx.b2b.removeMember(slug: string, userId: number): Promise<{
  message: string;  // "Member removed successfully"
}>

// ─── Invitations ───

// POST — requires permission: org.members.invite — returns created invitation (HTTP 201)
tx.b2b.inviteMember(slug: string, data: {
  email: string;
  role_code: string;
  expires_in_days?: number;  // 1-30, default: 7
}): Promise<{
  id: number;
  email: string;
  role: string;
  token: string;          // Acceptance token (in the email link)
  expires_at: string;     // ISO 8601
  invited_by: { id: number; email: string };
  organization: { id: number; name: string; slug: string };
}>

// ─── Organization Roles ───

// GET /auth/organizations/roles/ — System roles (owner, admin, member) + custom ones
tx.b2b.listOrgRoles(): Promise<Array<{
  code: string;
  name: string;
  description: string;
  weight: number;    // Hierarchical weight (owner=100, admin=50, member=10)
  permissions: Array<{ code: string; name: string; description: string }>;
  is_system_role: boolean;
  created_at: string;
}>>
```

**Multi-tenant context example:**
```typescript
// User selects "Acme Corp" in an organization switcher
tx.b2b.switchOrganization('acme-corp');

// All subsequent requests will automatically include:
// X-Org-Slug: acme-corp
const profile = await tx.user.getProfile();
// → profile.organization_context.current_org.slug === 'acme-corp'

// Invite a new collaborator with 14-day expiry
const invitation = await tx.b2b.inviteMember('acme-corp', {
  email: 'newdev@example.com',
  role_code: 'member',
  expires_in_days: 14,
});
// → invitation.token (included in the email link)
```
---
### 6.F — `ai.ts` Module (AIRS — AI Responsibility & Security)

Tenxyte AIRS is a security suite dedicated to **AI agents** interacting with the API. It is enabled by default backend-side (`TENXYTE_AIRS_ENABLED = True`). The SDK's `ai.ts` module exposes the necessary primitives for operating an agent securely and with full traceability.

> See [`docs/airs.md`](./docs/airs.md) for full backend documentation of AIRS mechanisms.

#### Concept: `AgentToken`

The `AgentToken` is a secure delegated token distinct from the user JWT. The agent borrows a user's permissions **without ever handling their credentials**. The SDK automatically injects it as an `Authorization: AgentBearer <token>` header (**`AgentBearer` scheme**, distinct from standard JWT `Bearer`) when active.

```typescript
// ─── AgentToken Lifecycle ───

// POST /ai/tokens/ — creates a delegated agent token (from an authenticated user)
tx.ai.createAgentToken(data: {
  agent_id: string;             // Descriptive identifier (e.g., "finance-agent-v2")
  permissions?: string[];       // ⚠️ OPTIONAL — subset of user permissions (default: [])
  expires_in?: number;          // Duration in seconds (default: TENXYTE_AIRS_DEFAULT_EXPIRY = 3600)
  organization?: string;        // Organization slug (alternative to X-Org-Slug header)
  budget_limit_usd?: number;    // Max LLM budget in USD (e.g., 5.00). Absent = unlimited
  circuit_breaker?: {
    max_requests?: number;       // Max requests in window (e.g., 100)
    window_seconds?: number;     // Window duration in seconds (e.g., 60)
  };
  dead_mans_switch?: {
    heartbeat_required_every?: number; // Heartbeat interval in seconds
  };
}): Promise<{
  id: number;
  token: string;       // Raw "AgentBearer xxx…" token — store now, shown only once
  agent_id: string;
  status: string;      // 'active'
  expires_at: string;  // ISO 8601
}>  // HTTP 201

// Activate agent mode on the client (all subsequent requests use AgentBearer)
tx.ai.setAgentToken(token: string): void
tx.ai.clearAgentToken(): void
tx.ai.isAgentMode(): boolean

// GET /ai/tokens/ — list current user's tokens (filterable via X-Org-Slug)
tx.ai.listAgentTokens(): Promise<AgentTokenSummary[]>

// GET /ai/tokens/{id}/ — details of a specific token
tx.ai.getAgentToken(tokenId: number): Promise<AgentTokenSummary>

// POST /ai/tokens/{id}/revoke/ — permanent revocation
tx.ai.revokeAgentToken(tokenId: number): Promise<{ status: 'revoked' }>

// POST /ai/tokens/{id}/suspend/ — temporary manual suspension (reason: MANUAL)
tx.ai.suspendAgentToken(tokenId: number): Promise<{ status: 'suspended' }>

// POST /ai/tokens/revoke-all/ — emergency kill-switch (revokes ALL active tokens)
tx.ai.revokeAllAgentTokens(): Promise<{ status: 'revoked'; count: number }>
```

#### Circuit Breaker

An autonomous firewall against uncontrolled behaviors (infinite loops, exfiltration). If a threshold is exceeded, the token automatically flips to `SUSPENDED` and all subsequent requests with this token return `403`.

```typescript
// POST /ai/tokens/{id}/heartbeat/ — uses Authorization: AgentBearer <token>
// Without heartbeat within the allotted interval, the backend automatically suspends the agent.
tx.ai.sendHeartbeat(tokenId: number): Promise<{ status: 'ok' }>

// If API returns {suspended_reason: 'RATE_LIMIT'} or {suspended_reason: 'ANOMALY'},
// the SDK emits the 'agent:circuit_open' event.
```

#### Human in the Loop (HITL)

Certain actions (configured via `TENXYTE_AIRS_CONFIRMATION_REQUIRED`) return `202 Accepted` instead of `200` and pause execution pending human validation.

```typescript
// SDK automatically detects 202 responses and emits the 'agent:awaiting_approval' event
tx.on('agent:awaiting_approval', (approval: {
  action_id: string;           // AgentPendingAction ID
  confirmation_token: string;  // Token to transmit to human
  permission: string;          // e.g., "users.delete"
  endpoint: string;            // Endpoint that triggered HITL
  payload: unknown;            // Data submitted for validation
  expires_at: string;          // Validity duration (default: 10 min)
}) => {
  notifyHuman(approval); // Slack, email, validation UI...
});

// GET /ai/pending-actions/ — list actions awaiting validation
tx.ai.listPendingActions(): Promise<AgentPendingAction[]>

// POST /ai/pending-actions/confirm/ — body: { token: confirmationToken }
// ⚠️ Token is passed in the BODY ("token" field), not the URL
tx.ai.confirmPendingAction(confirmationToken: string): Promise<{ status: 'confirmed' }>

// POST /ai/pending-actions/deny/ — body: { token: confirmationToken }
tx.ai.denyPendingAction(confirmationToken: string): Promise<{ status: 'denied' }>
```

#### Forensic Traceability — `X-Prompt-Trace-ID`

Links every backend action to a specific LLM prompt in `AuditLog`. The SDK injects this header automatically if a `traceId` is active.

```typescript
// Set current trace ID (linked to the prompt that initiated the sequence of actions)
tx.ai.setTraceId(traceId: string): void   // Injects X-Prompt-Trace-ID on all requests
tx.ai.clearTraceId(): void

// Usage example in an agent
tx.ai.setTraceId(crypto.randomUUID());
await tx.user.getProfile();    // AuditLog will link this action to the traceId
await tx.rbac.listRoles();     // and this one too
tx.ai.clearTraceId();
```

#### Budget Tracking

> ⚠️ **Tenxyte does not calculate LLM costs.** It is model-agnostic. **Your code** must convert tokens to USD based on the provider's pricing (Anthropic, Google, OpenAI…), then report this amount to Tenxyte. Tenxyte only handles accumulation and automatic suspension on overage.

```typescript
// Pricing table to maintain integrator-side (example)
const MODEL_PRICING: Record<string, { input: number; output: number }> = {
  'claude-sonnet-4-5': { input: 3.00,  output: 15.00 }, // $ / million tokens
  'gemini-1.5-pro':    { input: 3.50,  output: 10.50 },
  'gpt-4o':            { input: 5.00,  output: 15.00 },
};

function calculateCostUsd(model: string, promptTokens: number, completionTokens: number): number {
  const p = MODEL_PRICING[model] ?? { input: 0, output: 0 };
  return (promptTokens / 1_000_000) * p.input + (completionTokens / 1_000_000) * p.output;
}

// POST /ai/tokens/{id}/report-usage/ — Authorization: AgentBearer <token>
// If budget exceeded → HTTP 403 { error: "Budget exceeded", status: "suspended" }
// Token is automatically suspended backend-side.
const cost = calculateCostUsd('claude-sonnet-4-5', 1200, 450); // ~$0.010

tx.ai.reportUsage(tokenId: number, usage: {
  cost_usd: number;           // Calculated amount from your code
  prompt_tokens: number;      // For audit/log only
  completion_tokens: number;  // For audit/log only
}): Promise<
  | { status: 'ok' }
  | { error: 'Budget exceeded'; status: 'suspended' }  // HTTP 403 if budget exceeded
>

// On overage, Tenxyte automatically suspends the token:
// → token.status            = 'SUSPENDED'
// → token.suspended_reason  = 'BUDGET_EXCEEDED'
// → all subsequent requests with this token → 403
```

#### AIRS Type Summary

```typescript
interface AgentTokenSummary {
  id: number;
  agent_id: string;
  status: 'ACTIVE' | 'SUSPENDED' | 'REVOKED' | 'EXPIRED';
  expires_at: string;
  created_at: string;
  organization: string | null;   // Org slug, or null
  current_request_count: number;
}

interface AgentPendingAction {
  id: number;
  agent_id: string;
  permission: string;            // e.g., "users.delete"
  endpoint: string;
  payload: unknown;
  confirmation_token: string;
  expires_at: string;
  created_at: string;
}
```
---
## 7. Event System

`TenxyteClient` extends a lightweight `EventEmitter`. Events allow higher layers (React Provider, Vue Plugin, Vanilla JS) to react to session changes without coupling their logic to the SDK.

```typescript
// Subscription — tx.on() returns an unsubscription function
const unsub = tx.on('session:created', (user: TenxyteUser) => {
  // Called after any successful login (email, phone, social, magic link, WebAuthn)
  renderApp(user);
});
unsub(); // Unsubscribe

tx.on('session:expired', () => {
  // Refresh failed (401 on /auth/refresh/) — session unrecoverable
  window.location.href = '/login';
});

tx.on('session:logged_out', () => {
  // logout() or logoutAll() called explicitly — distinct from session:expired
  window.location.href = '/login';
});

tx.on('token:refreshed', (tokens: { access: string; refresh: string }) => {
  // Interceptor successfully refreshed JWT (transparent to user)
  externalStore.setTokens(tokens);
});

tx.on('session:restored', (user: TenxyteUser) => {
  // Called on startup if a valid refresh_token was found in storage
  console.log(`Session restored for ${user.email}`);
});

tx.on('auth:error', (error: TenxyteAuthError) => {
  // Unrecoverable authentication error (blacklisted token, suspended account)
  errorReporter.capture(error);
});

tx.on('org:switched', (slug: string) => {
  // tx.b2b.switchOrganization() called — X-Org-Slug injected on all requests
  router.replace({ query: { org: slug } });
});

tx.on('org:cleared', () => {
  // tx.b2b.clearOrganization() called — X-Org-Slug removed
  router.replace({ query: {} });
});

tx.on('agent:awaiting_approval', (approval: {
  action_id: string;           // AgentPendingAction ID
  confirmation_token: string;  // Token to transmit to human
  permission: string;          // e.g., "users.delete"
  endpoint: string;            // Endpoint that triggered HITL
  payload: unknown;
  expires_at: string;
}) => {
  // 202 response received — action pending human validation (HITL)
  notifyHuman(approval);
});

tx.on('agent:circuit_open', (info: {
  agent_id: string;
  suspended_reason: 'RATE_LIMIT' | 'ANOMALY' | 'BUDGET_EXCEEDED' | 'MANUAL';
}) => {
  // Backend suspended the agent (→ 403 on subsequent requests with this token)
  // ⚠️ NOT a 503 — token flips to SUSPENDED status, requests return 403
  logger.warn(`Agent ${info.agent_id} suspended: ${info.suspended_reason}`);
});

tx.on('agent:budget_exceeded', (info: {
  agent_id: string;
  token_id: number;
  cost_usd_used: number;
  budget_limit_usd: number;
}) => {
  // reportUsage() received a 403 — LLM budget exceeded, token automatically suspended
});

tx.on('agent:token_revoked', (tokenId: number) => {
  // revokeAgentToken() or revokeAllAgentTokens() called
  // Useful for cleaning up React/Vue stores
});

// Single subscription (automatically unsubscribes after first trigger)
tx.once('session:restored', (user) => renderApp(user));

// Manual unsubscription
const handler = (user: TenxyteUser) => { /* ... */ };
tx.on('session:restored', handler);
tx.off('session:restored', handler);
```

### Event Table

| Event | Payload | Trigger |
|---|---|---|
| `session:created` | `TenxyteUser` | Successful login (any method) |
| `session:expired` | — | Failed refresh (401 on `/auth/refresh/`) |
| `session:logged_out` | — | Explicit `logout()` or `logoutAll()` |
| `token:refreshed` | `{ access, refresh }` | Interceptor successfully refreshed JWT |
| `session:restored` | `TenxyteUser` | Session loaded from storage at startup |
| `auth:error` | `TenxyteAuthError` | Unrecoverable auth error |
| `org:switched` | `string` (slug) | `tx.b2b.switchOrganization()` |
| `org:cleared` | — | `tx.b2b.clearOrganization()` |
| `agent:awaiting_approval` | `ApprovalRequest` | `202` response received — action pending HITL |
| `agent:circuit_open` | `{ agent_id, suspended_reason }` | Token suspended → `403` (not `503`) |
| `agent:budget_exceeded` | `{ agent_id, token_id, cost_usd_used, budget_limit_usd }` | `reportUsage()` returns 403 |
| `agent:token_revoked` | `number` (tokenId) | `revokeAgentToken()` or `revokeAllAgentTokens()` |

---

## 8. `DeviceInfo` Helper

The `device_info` field is used by the Tenxyte backend for session management and per-device limits (see `docs/security.md#session--device-limits`). The SDK provides a utility to build this string automatically from the browser.

> **Automatic Fallback:** If `device_info` is not provided, the backend reconstructs it from the HTTP `User-Agent` header via `build_device_info_from_user_agent()`. It is therefore **not mandatory** in standard browser calls — but providing it manually ensures precise identification.

```typescript
import { buildDeviceInfo } from '@tenxyte/js-core/utils';

// Automatically generated from navigator.userAgent + screen info
const deviceInfo = buildDeviceInfo();
// → "v=1|os=windows;osv=11|device=desktop|arch=x64|app=tenxyte;appv=1.0.0|runtime=chrome;rtv=122|tz=Europe/Paris"

// Custom (useful in Node.js / SSR)
const deviceInfo = buildDeviceInfo({
  os: 'linux',
  osVersion: 'ubuntu22.04',   // → osv=ubuntu22.04
  device: 'server',
  arch: 'x64',
  app: 'my-app',
  appVersion: '2.1.0',        // → appv=2.1.0
  runtime: 'node',
  runtimeVersion: process.version,   // → rtv=v20.11.0
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
});

// Pass to login
await tx.auth.loginWithEmail(email, password, { deviceInfo });
```

**String Format (v1):**

> Separators: `|` between categories, `;` between sub-keys of the same category, `=` between key and value.
> Full example: `v=1|os=windows;osv=11|device=desktop|arch=x64|app=tenxyte;appv=1.0.0|runtime=chrome;rtv=122|tz=Europe/Paris`

| Key | Sub-keys | Description | Valid Values |
|---|---|---|---|
| `v` | — | Format version (mandatory) | `1` |
| `os` | `osv` | Operating System + version | `windows`, `android`, `ios`, `macos`, `linux`, `chromeos` |
| `device` | — | Device type | `desktop`, `mobile`, `tablet`, `server`, `api-client`, `bot` |
| `arch` | — | CPU Architecture | `x64`, `arm64`, `arm`, `x86` |
| `app` | `appv` | Client application name + version | e.g., `app=tenxyte;appv=1.0.0` |
| `runtime` | `rtv` | Browser or runtime + version | `chrome`, `firefox`, `safari`, `edge`, `opera`, `node`, `postman`, `curl`, `insomnia`, `httpie` |
| `tz` | — | IANA Timezone | e.g., `Europe/Paris` |

> **Comparison Rule (new devices):** The backend compares `os`, `device`, `arch`, `app`, `runtime` to decide if it's a new device (email alert). Versions (`osv`, `appv`, `rtv`) and `tz` are **ignored** during this comparison.

---

## 9. TypeScript Interfaces (`types/`)

Types are generated from the OpenAPI schema via `openapi-typescript`, then manually enriched. Here are the core interfaces to know:

```typescript
// --- TenxyteUser (docs/schemas.md#User) ---
interface TenxyteUser {
  id: string;                    // UUID
  email: string | null;
  phone_country_code: string | null;
  phone_number: string | null;
  first_name: string;
  last_name: string;
  is_email_verified: boolean;
  is_phone_verified: boolean;
  is_2fa_enabled: boolean;
  roles: string[];               // Role codes e.g., ['admin', 'viewer']
  permissions: string[];         // Permission codes (direct + inherited)
  created_at: string;            // ISO 8601
  last_login: string | null;
}

// --- TokenPair (docs/schemas.md#TokenPair) ---
interface TokenPair {
  access_token: string;          // JWT Bearer
  refresh_token: string;
  token_type: 'Bearer';
  expires_in: number;            // Current access_token lifetime in seconds
  device_summary: string | null; // e.g., "desktop — windows 11 — chrome 122" (null if device_info absent)
}

// --- TenxyteError (docs/schemas.md#ErrorResponse) ---
interface TenxyteError {
  error: string;                 // Human message
  code: TenxyteErrorCode;        // Machine identifier
  details?: Record<string, string[]> | string; // Per-field errors or free message
  retry_after?: number;          // Present on 429 and 423
}

// Known machine error codes (non-exhaustive)
type TenxyteErrorCode =
  // Auth
  | 'LOGIN_FAILED' | 'INVALID_CREDENTIALS'
  | 'ACCOUNT_LOCKED' | 'ACCOUNT_BANNED'
  | '2FA_REQUIRED' | 'ADMIN_2FA_SETUP_REQUIRED'
  | 'TOKEN_EXPIRED' | 'TOKEN_BLACKLISTED' | 'REFRESH_FAILED'
  | 'PERMISSION_DENIED'
  | 'SESSION_LIMIT_EXCEEDED' | 'DEVICE_LIMIT_EXCEEDED'
  | 'RATE_LIMITED'
  | 'INVALID_OTP' | 'OTP_EXPIRED'
  | 'INVALID_PROVIDER' | 'SOCIAL_AUTH_FAILED'
  | 'VALIDATION_URL_REQUIRED' | 'INVALID_TOKEN'
  // User / Account
  | 'CONFIRMATION_REQUIRED' | 'PASSWORD_REQUIRED' | 'INVALID_PASSWORD'
  | 'INVALID_DEVICE_INFO'
  // B2B / Organizations
  | 'ORG_NOT_FOUND' | 'NOT_ORG_MEMBER' | 'NOT_OWNER'
  | 'ALREADY_MEMBER' | 'MEMBER_LIMIT_EXCEEDED'
  | 'HAS_CHILDREN' | 'CIRCULAR_HIERARCHY' | 'LAST_OWNER_REQUIRED'
  | 'INVITATION_EXISTS' | 'INVALID_ROLE'
  // AIRS — Agent errors
  | 'AGENT_NOT_FOUND' | 'AGENT_SUSPENDED' | 'AGENT_REVOKED' | 'AGENT_EXPIRED'
  | 'BUDGET_EXCEEDED' | 'RATE_LIMIT_EXCEEDED' | 'HEARTBEAT_MISSING' | 'AIRS_DISABLED';

// --- Organization (docs/schemas.md#Organization) ---
interface Organization {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  metadata: Record<string, unknown> | null;
  is_active: boolean;
  max_members: number;           // 0 = unlimited
  member_count: number;
  created_at: string;
  updated_at: string;
  // ⚠️ parent is an object, not a simple integer
  parent: { id: number; name: string; slug: string } | null;
  children: Array<{ id: number; name: string; slug: string }>;
  user_role: string | null;         // Current user's role in this org
  user_permissions: string[];       // Effective permissions in this org
}

// --- PaginatedResponse ---
interface PaginatedResponse<T> {
  count: number;
  page: number;
  page_size: number;
  total_pages: number;
  next: string | null;
  previous: string | null;
  results: T[];
}
```

---

## 10. Repository Roadmap

### Phase 1: Architectural Foundation & HTTP Engine (Weeks 1-2)
- Project initialization (TypeScript, Tsup for ESM/CommonJS build, Vitest for testing).
- TS interface generation (User, TokenPair) from existing OpenAPI schema via **`openapi-typescript`**.
- HTTP client architecture (native Fetch wrapper with interceptor system for JWT rotation handling).
- **Contextual Interceptors:** Implementation of the system injecting `X-Org-Slug` and `X-Prompt-Trace-ID` on outgoing requests.
- Development of the three storage strategies (`storage/`).
- `buildDeviceInfo()` helper implementation.

### Phase 2: Core Authentication Modules & RBAC (Weeks 2-3)
- Full development of the `auth.ts` module (Email/phone login, Register, Logout, Refresh, Magic Link, Social).
- **Critical complexity handling:** Concurrent request Queue. If 4 network calls go out simultaneously while the token is expired, the SDK must block the last 3 calls, perform *exactly one* refresh, then release all 4 calls with the new common token.
- Event system implementation (`EventEmitter`).
- `user.ts` (profile) and **`user.admin` (back-office endpoints: ban, lock, paginated list)** modules.
- `rbac.ts` module for role management.

### Phase 3: Advanced Security, B2B, and AIRS (Weeks 4-5)
- Full `security.ts` module: 2FA/TOTP, OTP, Password management.
- WebAuthn integration: wrapping `navigator.credentials.create` / `get` to simplify Passkeys.
- `b2b.ts` module (Organizations, invitations, member management).
- `ai.ts` module (AIRS): `AgentToken`, Circuit Breaker + heartbeat, HITL (`202` → event), Budget tracking.

### Phase 4: Documentation & Tests (Week 6)
- Exhaustive `README.md` writing with code examples.
- TSDoc on all public methods for IntelliSense autocompletion in VSCode.
- GitHub Actions setup (Lint, Tests, Publish on npm.js).
- `examples/vanilla-ts/` folder demonstrating usage without a framework.

---

### Conclusion

The `@tenxyte/js-core` SDK is the true "backbone" of the Tenxyte front-end ecosystem. By moving the cognitive load — secure JWT management, cyclic refresh token flow, error parsing, header injection, DeviceInfo, session events, synchronous RBAC — into this robust library, future components (like `@tenxyte/html-components`) only need to focus on the UI. Respecting this plan ensures an optimal Developer Experience (DX) aligned with production standards for the backend API.
