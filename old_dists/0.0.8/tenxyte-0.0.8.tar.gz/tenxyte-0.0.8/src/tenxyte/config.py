"""
Tenxyte - Configuration module with sensible defaults.

All settings can be overridden in your Django settings.py file.
"""
from django.conf import settings


def get_setting(name: str, default):
    """Get a Tenxyte setting with a default value."""
    return getattr(settings, name, default)


# =============================================================================
# SECURITY LAYERS - Can be disabled for development/testing
# =============================================================================

def is_application_auth_enabled() -> bool:
    """
    Enable/disable Application authentication (X-Access-Key, X-Access-Secret).
    Default: True (enabled)

    Set in settings.py:
        TENXYTE_APPLICATION_AUTH_ENABLED = False
    """
    return get_setting('TENXYTE_APPLICATION_AUTH_ENABLED', True)


def is_rate_limiting_enabled() -> bool:
    """
    Enable/disable rate limiting for login attempts and API calls.
    Default: True (enabled)

    Set in settings.py:
        TENXYTE_RATE_LIMITING_ENABLED = False
    """
    return get_setting('TENXYTE_RATE_LIMITING_ENABLED', True)


def is_jwt_auth_enabled() -> bool:
    """
    Enable/disable JWT authentication requirement.
    Default: True (enabled)

    Set in settings.py:
        TENXYTE_JWT_AUTH_ENABLED = False

    WARNING: Disabling this is dangerous and should only be used for testing.
    """
    return get_setting('TENXYTE_JWT_AUTH_ENABLED', True)


def is_account_lockout_enabled() -> bool:
    """
    Enable/disable account lockout after failed attempts.
    Default: True (enabled)

    Set in settings.py:
        TENXYTE_ACCOUNT_LOCKOUT_ENABLED = False
    """
    return get_setting('TENXYTE_ACCOUNT_LOCKOUT_ENABLED', True)


# =============================================================================
# RATE LIMITING SETTINGS
# =============================================================================

def get_max_login_attempts() -> int:
    """
    Maximum login attempts before lockout.
    Default: 5

    Set in settings.py:
        TENXYTE_MAX_LOGIN_ATTEMPTS = 10
    """
    return get_setting('TENXYTE_MAX_LOGIN_ATTEMPTS', 5)


def get_lockout_duration_minutes() -> int:
    """
    Account lockout duration in minutes.
    Default: 30

    Set in settings.py:
        TENXYTE_LOCKOUT_DURATION_MINUTES = 60
    """
    return get_setting('TENXYTE_LOCKOUT_DURATION_MINUTES', 30)


def get_rate_limit_window_minutes() -> int:
    """
    Time window for counting login attempts (in minutes).
    Default: 15

    Set in settings.py:
        TENXYTE_RATE_LIMIT_WINDOW_MINUTES = 30
    """
    return get_setting('TENXYTE_RATE_LIMIT_WINDOW_MINUTES', 15)


# =============================================================================
# JWT SETTINGS
# =============================================================================

def get_jwt_access_token_lifetime() -> int:
    """
    JWT access token lifetime in seconds.
    Default: 3600 (1 hour)

    Set in settings.py:
        TENXYTE_JWT_ACCESS_TOKEN_LIFETIME = 7200
    """
    return get_setting('TENXYTE_JWT_ACCESS_TOKEN_LIFETIME', 3600)


def get_jwt_refresh_token_lifetime() -> int:
    """
    JWT refresh token lifetime in seconds.
    Default: 604800 (7 days)

    Set in settings.py:
        TENXYTE_JWT_REFRESH_TOKEN_LIFETIME = 86400 * 30
    """
    return get_setting('TENXYTE_JWT_REFRESH_TOKEN_LIFETIME', 86400 * 7)


def get_jwt_secret_key() -> str:
    """
    Secret key for JWT signing.
    Default: Django's SECRET_KEY

    Set in settings.py:
        TENXYTE_JWT_SECRET_KEY = 'your-secret-key'
    """
    return get_setting('TENXYTE_JWT_SECRET_KEY', settings.SECRET_KEY)


def get_jwt_algorithm() -> str:
    """
    Algorithm for JWT signing.
    Default: HS256

    Set in settings.py:
        TENXYTE_JWT_ALGORITHM = 'HS512'
    """
    return get_setting('TENXYTE_JWT_ALGORITHM', 'HS256')


# =============================================================================
# 2FA / TOTP SETTINGS
# =============================================================================

def get_totp_issuer() -> str:
    """
    TOTP issuer name (shown in authenticator apps).
    Default: 'Tenxyte'

    Set in settings.py:
        TENXYTE_TOTP_ISSUER = 'MyApp'
    """
    return get_setting('TENXYTE_TOTP_ISSUER', 'Tenxyte')


# =============================================================================
# APPLICATION AUTH SETTINGS
# =============================================================================

def get_exempt_paths() -> list:
    """
    Paths exempt from application authentication.
    Default: ['/admin/', '/api/v1/health/', '/api/v1/docs/']

    Set in settings.py:
        TENXYTE_EXEMPT_PATHS = ['/admin/', '/api/v1/public/']
    """
    default_paths = [
        '/admin/',
        '/api/v1/health/',
        '/api/v1/docs/',
    ]
    return get_setting('TENXYTE_EXEMPT_PATHS', default_paths)


def get_exact_exempt_paths() -> list:
    """
    Exact paths exempt from application authentication.
    Default: ['/api/v1/']

    Set in settings.py:
        TENXYTE_EXACT_EXEMPT_PATHS = ['/api/v1/', '/']
    """
    default_paths = ['/api/v1/']
    return get_setting('TENXYTE_EXACT_EXEMPT_PATHS', default_paths)


# =============================================================================
# ADVANCED SECURITY SETTINGS
# =============================================================================

def is_token_blacklist_enabled() -> bool:
    """
    Enable/disable JWT access token blacklisting.
    Default: True (enabled)

    Set in settings.py:
        TENXYTE_TOKEN_BLACKLIST_ENABLED = False
    """
    return get_setting('TENXYTE_TOKEN_BLACKLIST_ENABLED', True)


def is_refresh_token_rotation_enabled() -> bool:
    """
    Enable/disable refresh token rotation.
    When enabled, old refresh token is invalidated when a new one is issued.
    Default: True (enabled)

    Set in settings.py:
        TENXYTE_REFRESH_TOKEN_ROTATION = False
    """
    return get_setting('TENXYTE_REFRESH_TOKEN_ROTATION', True)


def is_audit_logging_enabled() -> bool:
    """
    Enable/disable audit logging.
    Default: True (enabled)

    Set in settings.py:
        TENXYTE_AUDIT_LOGGING_ENABLED = False
    """
    return get_setting('TENXYTE_AUDIT_LOGGING_ENABLED', True)


def is_password_history_enabled() -> bool:
    """
    Enable/disable password history check.
    Default: True (enabled)

    Set in settings.py:
        TENXYTE_PASSWORD_HISTORY_ENABLED = False
    """
    return get_setting('TENXYTE_PASSWORD_HISTORY_ENABLED', True)


def get_password_history_count() -> int:
    """
    Number of previous passwords to check.
    Default: 5

    Set in settings.py:
        TENXYTE_PASSWORD_HISTORY_COUNT = 10
    """
    return get_setting('TENXYTE_PASSWORD_HISTORY_COUNT', 5)


def is_session_limit_enabled() -> bool:
    """
    Enable/disable session limit enforcement.
    Default: True (enabled)

    Set in settings.py:
        TENXYTE_SESSION_LIMIT_ENABLED = False
    """
    return get_setting('TENXYTE_SESSION_LIMIT_ENABLED', True)


def get_default_max_sessions() -> int:
    """
    Default maximum concurrent sessions per user.
    Can be overridden per user with user.max_sessions field.
    Default: 1

    Set in settings.py:
        TENXYTE_DEFAULT_MAX_SESSIONS = 3
    """
    return get_setting('TENXYTE_DEFAULT_MAX_SESSIONS', 1)


def get_session_limit_action() -> str:
    """
    Action when session limit is exceeded.
    Options: 'deny' (deny new login) or 'revoke_oldest' (revoke oldest session)
    Default: 'revoke_oldest'

    Set in settings.py:
        TENXYTE_SESSION_LIMIT_ACTION = 'deny'
    """
    return get_setting('TENXYTE_SESSION_LIMIT_ACTION', 'revoke_oldest')


# =============================================================================
# DEVICE LIMIT SETTINGS
# =============================================================================

def is_device_limit_enabled() -> bool:
    """
    Enable/disable device limit enforcement.
    Default: True (enabled)

    Set in settings.py:
        TENXYTE_DEVICE_LIMIT_ENABLED = False
    """
    return get_setting('TENXYTE_DEVICE_LIMIT_ENABLED', True)


def get_default_max_devices() -> int:
    """
    Default maximum unique devices per user.
    Can be overridden per user with user.max_devices field.
    Default: 1

    Set in settings.py:
        TENXYTE_DEFAULT_MAX_DEVICES = 3
    """
    return get_setting('TENXYTE_DEFAULT_MAX_DEVICES', 1)


def get_device_limit_action() -> str:
    """
    Action when device limit is exceeded.
    Options: 'deny' (deny new login) or 'revoke_oldest' (revoke oldest device sessions)
    Default: 'deny'

    Set in settings.py:
        TENXYTE_DEVICE_LIMIT_ACTION = 'revoke_oldest'
    """
    return get_setting('TENXYTE_DEVICE_LIMIT_ACTION', 'deny')
