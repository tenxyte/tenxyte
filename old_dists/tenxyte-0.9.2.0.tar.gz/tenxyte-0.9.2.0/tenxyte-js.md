# Plan de Développement du Core SDK : `@tenxyte/js-core`

Ce document définit la stratégie complète, l'architecture et la roadmap pour la création du dépôt `tenxyte-js` (publié sous le nom `@tenxyte/js-core`). Ce SDK métier est le cœur sur lequel reposeront toutes les implémentations front-end de Tenxyte (Composants HTML, React, Vue, Vanilla JS).

---

## 1. Objectif et Vision Globale

**Vision :** Fournir un client JavaScript/TypeScript agnostique, robuste et typé pour interagir avec l'API REST de Tenxyte. Le SDK doit abstraire toute la complexité liée à la sécurité (gestion des JWT, rotation automatique des tokens, multi-application) pour que le développeur front-end n'ait à manipuler que des méthodes simples (ex: `tx.auth.login()`).

**Principes architecturaux :**
- **TypeScript First :** Typage strict de toutes les requêtes et réponses (idéalement basé sur l'OpenAPI Schema de Tenxyte).
- **Zéro Dépendance Lourde (ou Minimale) :** Utilisation native de l'API `fetch` de navigateur, ou d'un wrapper très léger.
- **Modulaire (Tree-shakable) :** Architecture permettant de n'importer que les modules nécessaires (ex: on n'embarque le code WebAuthn que si on l'utilise).
- **Sécurité par Défaut :** Intercepteurs automatiques pour les Headers (`X-Access-Key`, `Authorization`) et gestion du flux de `refresh_token` de manière totalement transparente.

---

## 2. Structure du Dépôt

Nom du paquet NPM envisagé : `@tenxyte/js-core`

```text
tenxyte-js/
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts                # Point d'entrée principal (export TenxyteClient)
│   ├── client.ts               # Configuration Fetch et Intercepteurs globaux
│   ├── config.ts               # Gestion des options (App Key, Base URL)
│   ├── storage/                # Stratégies de stockage des tokens
│   │   ├── memory.ts
│   │   ├── localStorage.ts
│   │   ├── cookie.ts           # (Utile pour une approche Backend-For-Frontend)
│   │   └── index.ts
│   ├── modules/                # Sous-modules correspondants aux routeurs Django
│   │   ├── auth.ts             # Login, register, logout, OTP, Magic Links
│   │   ├── security.ts         # 2FA, Passkeys (WebAuthn), Password Reset
│   │   ├── user.ts             # Profil personnel (/me)
│   │   ├── rbac.ts             # Rôles et Permissions
│   │   ├── b2b.ts              # Organisations, Switcher
│   │   └── ai.ts               # AIRS — AgentToken, Circuit Breaker, HITL, Budget
│   ├── utils/                  # Helpers (décodage partiel JWT, parsing erreurs HTTP)
│   └── types/                  # Interfaces générées (TenxyteUser, Tokens, etc.)
├── tests/                      # Tests unitaires (Vitest ou Jest)
└── dist/                       # Fichiers compilés (ESM, CJS, d.ts)
```

---

## 3. Fonctionnalités Clés et Responsabilités

### A. Le Client Principal (`TenxyteClient`)
Le point d'entrée unique. Il est initialisé au lancement de l'application (React, Vue, ou HTML pur) avec les identifiants d'application.

```typescript
import { TenxyteClient } from '@tenxyte/js-core';

const tx = new TenxyteClient({
  baseURL: 'https://api.mon-backend.com/api/v1',
  appKey: 'mon_app_key',
  // ⚠️ N'inclure appSecret QUE dans un contexte serveur (Next.js, BFF).
  // Dans un SPA public (React, Vue, Vanilla JS), ne jamais exposer appSecret.
  // appSecret: 'mon_app_secret',
  storage: 'localStorage' // ou 'memory', 'cookie'
});
```

### B. Intercepteurs et Gestion du Cycle de Vie (Le Coeur du SDK)
Le SDK intercepte toutes les requêtes réseau vers l'API Tenxyte et gère automatiquement :

1. **Injection des Headers :**
   - `X-Access-Key` (et `X-Access-Secret` si fourni côté serveur) : ajoutés à chaque requête.
   - `Authorization: Bearer <token>` : ajouté si une session utilisateur valide est présente dans le storage.
   - `Authorization: AgentBearer <token>` : injecté à la place du Bearer classique quand `tx.ai.setAgentToken()` est actif (mode agent AIRS).
   - `X-Org-Slug: <slug>` : injecté automatiquement après appel de `tx.b2b.switchOrganization()`.
   - `X-Prompt-Trace-ID: <traceId>` : injecté si `tx.ai.setTraceId()` est actif (traçabilité forensique AIRS).

2. **Rotation Transparente du Token (Refresh Flow) :**
   - Si l'API retourne une erreur `401` indiquant que l'`access_token` est expiré, le SDK met la requête X en pause.
   - Il appelle l'endpoint `/api/v1/auth/refresh/` avec le `refresh_token`.
   - Si succès : le SDK met à jour le Storage, puis rejoue la requête X de manière invisible pour l'utilisateur UI.
   - Si échec : il émet l'événement `tx.on('session:expired', ...)` pour permettre au front-end de rediriger vers la page de login.

   > **Cas critique :** si plusieurs requêtes partent simultanément pendant l'expiration du token, le SDK ne fait qu'**un seul** appel refresh et libère toutes les requêtes en attente avec le nouveau token commun (queue pattern).

### C. Abstractions Métier (Les Méthodes exposées)
Le développeur utilise des promesses sémantiques au lieu de manipuler l'API directement :

- `tx.auth.loginWithEmail(email, password)` — authentification classique
- `tx.auth.loginWithSocial(provider, payload)` — OAuth2 (Google, GitHub…)
- `tx.auth.requestMagicLink(email, validationUrl)` — lien magique passwordless
- `tx.security.setup2FA()` — initialiser la 2FA TOTP
- `tx.security.registerWebAuthn()` — enregistrer un Passkey
- `tx.security.authenticateWebAuthn()` — s'authentifier via Passkey
- `tx.user.getProfile()` — profil de l'utilisateur connecté
- `tx.rbac.hasRole('admin')` — vérification synchrone depuis le JWT (sans appel réseau)
- `tx.b2b.switchOrganization('acme-corp')` — activer un contexte organisation (injecte `X-Org-Slug`)
- `tx.ai.createAgentToken(data)` — créer un token délégué pour un agent IA (AIRS)
- `tx.ai.reportUsage(tokenId, usage)` — reporter la consommation LLM pour le budget tracking

---

## 4. Gestion de l'État et du Stockage (Storage Strategies)

L'implémentation repose sur une interface commune `IStorageMechanism` pour s'adapter à divers environnements :

### Stratégies disponibles

| Stratégie | `storage` value | XSS-safe | Persistance | SSR-compatible | Usage recommandé |
|---|---|---|---|---|---|
| **In-Memory** | `'memory'` | ✅ Oui | ❌ Perdu au reload | ✅ Oui (Node.js) | Défaut recommandé — haute sécurité |
| **LocalStorage** | `'localStorage'` | ⚠️ Non | ✅ Oui | ❌ Non (`window` absent) | SPA classique avec persistance souhaitée |
| **Cookie JS** | `'cookie'` | ⚠️ Non | ✅ Oui (configurable) | ⚠️ Partiel | Contexte BFF, token CSRF géré par le SDK |

> **⚠️ Ne jamais exposer `appSecret` dans un SPA public.** L'`appSecret` est réservé aux contextes serveur (Next.js Route Handlers, BFF). Dans un SPA pur (React, Vue, Vanilla JS), n'utiliser que `appKey`. Pour désactiver entièrement l'authentification par application côté backend : `TENXYTE_APPLICATION_AUTH_ENABLED = False`.

### Notes importantes

**In-Memory :** les tokens vivent en RAM. Insensibles au vol XSS, mais l'utilisateur est déconnecté à chaque rechargement de page, sauf si un `refresh_token` valide est conservé dans un cookie sécurisé (stratégie mixte recommandée en production).

**LocalStorage :** les tokens persistent entre les rechargements. Idéal pour une SPA sans exigences de sécurité extrêmes, mais exposé au XSS.

**Cookie JS :** le SDK stocke et lit les tokens depuis des cookies accessibles en JS (non-`HttpOnly`). Le SDK gère l'envoi automatique du token CSRF sur les mutations. **Ne pas confondre avec les cookies `HttpOnly`** (qui sont invisibles au JS et donc hors du contrôle du SDK — ils sont envoyés automatiquement par le navigateur sans intervention du SDK).

**SSR (Next.js, Nuxt.js) :** en contexte serveur, `window` et `localStorage` sont indisponibles. Utiliser la stratégie `'memory'` ou implémenter un adapteur custom (`IStorageMechanism`). Les SDK `@tenxyte/nextjs` et `@tenxyte/nuxt` fournissent leurs propres adapteurs SSR préintégrés.

### Stockage de l'`AgentToken` brut

Après `tx.ai.createAgentToken()`, le token brut est retourné **une seule fois** (jamais restockable depuis l'API — seul le hash SHA-256 est persisté côté backend). Il est de la responsabilité de l'intégrateur de le stocker de manière sécurisée (variable d'environnement, secret manager, etc.) avant la fin de la session de création.

```typescript
const { token } = await tx.ai.createAgentToken({ agent_id: 'my-bot', permissions: [] });
// ⚠️ Stocker `token` immédiatement — il ne sera plus récupérable via l'API.
// Exemple : await secretManager.set('agent-token-id-42', token);
tx.ai.setAgentToken(token); // Active le mode AgentBearer pour les requêtes suivantes
```



---

## 5. Gestion des Erreurs, Rate Limiting et Lockout

Le SDK standardise les retours d'erreurs Django REST Framework (DRF) en instances d'exceptions riches JavaScript. Chaque erreur expose les champs `error` (message humain), `code` (identifiant machine) et optionnellement `details` (erreurs de validation par champ).

| Classe d'erreur | Code HTTP | `code` backend typique | Champs additionnels |
|---|---|---|---|
| `TenxyteAuthError` | 401 | `LOGIN_FAILED`, `INVALID_CREDENTIALS`, `2FA_REQUIRED`, `INVALID_2FA_CODE`, `ACCOUNT_LOCKED`, `REFRESH_FAILED`, `REFRESH_EXPIRED`, `REFRESH_BLACKLISTED` | `retry_after` (si lockout) |
| `TenxytePermissionError` | 403 | `PERMISSION_DENIED`, `ADMIN_2FA_SETUP_REQUIRED`, `APP_AUTH_REQUIRED`, `AIRS_DISABLED`, `AGENT_TOKEN_SUSPENDED` | — |
| `TenxyteValidationError` | 400 | `VALIDATION_ERROR`, `PASSWORD_BREACHED`, `REGISTRATION_FAILED` | `details`: `{field: [messages]}` |
| `TenxyteSessionError` | 409 | `SESSION_LIMIT_EXCEEDED`, `DEVICE_LIMIT_EXCEEDED` | — |
| `TenxyteRateLimitError` | 429 | `RATE_LIMITED` | `retry_after` (secondes, dans le body ET le header `Retry-After`) |
| `TenxyteNotFoundError` | 404 | `ORG_NOT_FOUND`, `AGENT_NOT_FOUND` | — |
| `TenxyteAIRSError` | 403 | `BUDGET_EXCEEDED`, `RATE_LIMIT_EXCEEDED`, `HEARTBEAT_MISSING` | `reason` (raison de suspension) |

> **Note sur `ACCOUNT_LOCKED`** : retourné via HTTP **401** (pas 423), avec un champ `retry_after` en secondes dans le body indiquant combien de temps avant de pouvoir réessayer.

> **Note sur `2FA_REQUIRED`** : retourné via HTTP **401** (pas 403), avec un champ `requires_2fa: true` pour différencier d'un simple `LOGIN_FAILED`.

```typescript
try {
  await tx.auth.loginWithEmail(email, password);
} catch (e) {
  if (e instanceof TenxyteAuthError) {
    if (e.code === 'ACCOUNT_LOCKED') {
      // e.retryAfter → secondes avant de réessayer (côté backend : LOCKOUT_DURATION_MINUTES × 60)
      showMessage(`Compte bloqué. Réessayez dans ${e.retryAfter}s.`);
    } else if (e.code === '2FA_REQUIRED') {
      // Demander le code TOTP, puis relancer avec totpCode
      const code = await promptUserForTOTP();
      await tx.auth.loginWithEmail(email, password, { totpCode: code });
    } else if (e.code === 'INVALID_2FA_CODE') {
      showMessage('Code 2FA invalide. Vérifiez votre application authenticator.');
    }
  } else if (e instanceof TenxyteValidationError) {
    // e.details → { email: ['Cet email est invalide.'] }
    renderFormErrors(e.details);
  } else if (e instanceof TenxyteRateLimitError) {
    // e.retryAfter → secondes (également dans le header HTTP Retry-After)
    showMessage(`Trop de tentatives. Réessayez dans ${e.retryAfter}s.`);
  } else if (e instanceof TenxyteAIRSError) {
    // e.code → 'BUDGET_EXCEEDED' | 'RATE_LIMIT_EXCEEDED' | 'HEARTBEAT_MISSING'
    // e.reason → raison de suspension du token agent
    handleAgentSuspension(e);
  }
}
```



---

## 6. Référence Complète des Modules

### 6.A — Module `auth.ts`

Couvre l'authentification principale, la session et les flux passwordless. Toutes les méthodes retournent une `Promise`.

```typescript
// Authentification classique
tx.auth.loginWithEmail(email: string, password: string, opts?: {
  totpCode?: string;        // Obligatoire si 2FA activé
  deviceInfo?: string;      // Chaîne de fingerprinting (voir §8)
}): Promise<{ user: TenxyteUser; tokens: TokenPair }>

tx.auth.loginWithPhone(
  phoneCountryCode: string, // Ex: "+33"
  phoneNumber: string,      // Ex: "612345678" (sans indicatif)
  password: string,
  opts?: { totpCode?: string; deviceInfo?: string }
): Promise<{ user: TenxyteUser; tokens: TokenPair }>

// Inscription
tx.auth.register(data: {
  email?: string;
  phone_country_code?: string;
  phone_number?: string;
  password: string;
  first_name?: string;
  last_name?: string;
  login?: boolean;           // Si true, retourne aussi des TokenPair
  device_info?: string;
}): Promise<{ user: TenxyteUser; verification_required: { email: boolean; phone: boolean }; tokens?: TokenPair }>

// Session
tx.auth.logout(refreshToken: string): Promise<{
  message: string;
  access_token_blacklisted: boolean;
  refresh_token_revoked: boolean;
}>
tx.auth.logoutAll(): Promise<{
  message: string;
  devices_logged_out: number;    // Nombre d'appareils déconnectés
  access_token_blacklisted: boolean;
}>
tx.auth.refresh(refreshToken: string): Promise<TokenPair>  // Appelé automatiquement par l'intercepteur

// Passwordless — Magic Link
// requestMagicLink envoie un email avec un lien à usage unique (jamais de confirmation d'existence du compte)
tx.auth.requestMagicLink(email: string, validationUrl: string): Promise<{
  message: string;             // Toujours "If this email is registered, a magic link has been sent."
  expires_in_minutes: number;  // Durée de validité (configurable via TENXYTE_MAGIC_LINK_EXPIRY_MINUTES)
  sent_to: string;             // Email masqué (sécurité anti-énumération)
}>

// verifyMagicLink : appel GET vers l'endpoint /auth/magic-link/verify/?token=<token>
// Le token est passé en query param, usage unique, invalide après utilisation
tx.auth.verifyMagicLink(token: string): Promise<{
  user: TenxyteUser;
  tokens: TokenPair;
  message: string;
}>

// Social / OAuth2
// Flow direct : POST /auth/social/<provider>/ avec access_token, code+redirect_uri, ou id_token (Google only)
tx.auth.loginWithSocial(
  provider: 'google' | 'github' | 'microsoft' | 'facebook',
  payload: { access_token?: string; id_token?: string; code?: string; redirect_uri?: string },
  opts?: { deviceInfo?: string }
): Promise<{ user: TenxyteUser; tokens: TokenPair; is_new_user: boolean; provider: string }>

// Flow callback : GET /auth/social/<provider>/callback/?code=<code>&redirect_uri=<uri>
// Utilisé quand le provider redirige le navigateur vers votre app après autorisation
tx.auth.handleSocialCallback(
  provider: 'google' | 'github' | 'microsoft' | 'facebook',
  code: string,
  redirectUri: string,
  opts?: { state?: string }
): Promise<{ access: string; refresh: string; provider: string; is_new_user: boolean }>
```

#### Cas de login interactif avec 2FA

Lorsque le login retourne `code: '2FA_REQUIRED'`, le SDK lève une `TenxyteAuthError` (HTTP 401) que le front-end intercepte pour afficher le formulaire TOTP :

```typescript
try {
  await tx.auth.loginWithEmail(email, password);
} catch (e) {
  if (e instanceof TenxyteAuthError && e.code === '2FA_REQUIRED') {
    // Demander le code TOTP à l'utilisateur, puis relancer :
    await tx.auth.loginWithEmail(email, password, { totpCode: userInputCode });
  }
}
```


---

### 6.B — Module `security.ts`

Couvre la 2FA (TOTP), l'OTP de vérification, la gestion des mots de passe et les Passkeys (WebAuthn/FIDO2).

#### Sous-module 2FA (TOTP)

```typescript
// Récupérer le statut
tx.security.get2FAStatus(): Promise<{ is_enabled: boolean; backup_codes_remaining: number }>

// Flux de setup (3 étapes)
// 1. Initier : retourne QR code + backup codes à afficher UNE SEULE FOIS
tx.security.setup2FA(): Promise<{
  message: string;           // Instructions pour l'utilisateur
  secret: string;            // Secret TOTP base32 (pour saisie manuelle)
  manual_entry_key: string;  // Alias du secret, format plus lisible
  qr_code: string;           // data:image/png;base64,...
  provisioning_uri: string;  // otpauth://totp/...
  backup_codes: string[];    // 10 codes alphanumériques à usage unique
  warning: string;           // "Save the backup codes securely. They will not be shown again."
}>

// 2. Confirmer avec le premier code TOTP de l'appli authenticator
tx.security.confirm2FA(totpCode: string): Promise<{
  message: string;       // "2FA enabled successfully"
  is_enabled: boolean;   // true
  enabled_at: string;    // ISO 8601 datetime
}>

// 3. (Plus tard) Désactiver — nécessite code TOTP OU code de secours + mot de passe
tx.security.disable2FA(totpCode: string, password: string): Promise<{
  message: string;
  is_enabled: boolean;            // false
  disabled_at: string;            // ISO 8601 datetime
  backup_codes_invalidated: boolean;
}>

// Régénérer les codes de secours (invalide les anciens — nécessite code TOTP)
tx.security.regenerateBackupCodes(totpCode: string): Promise<{
  message: string;
  backup_codes: string[];   // 10 nouveaux codes [A-Z0-9]{8}
  codes_count: number;      // 10
  generated_at?: string;    // ISO 8601 datetime (si renvoyé)
  warning: string;          // "Save these codes securely. They will not be shown again."
}>
```

#### Sous-module Vérification OTP (Email / Phone)

```typescript
// Demande d'envoi du code — retourne les métadonnées de l'OTP généré
tx.security.requestOtp(type: 'email' | 'phone'): Promise<{
  message: string;          // "OTP sent successfully"
  otp_id: number;           // ID DB de l'OTPCode (utile pour débogage / suivi)
  expires_at: string;       // ISO 8601 — expiration (configurable: email 15min, phone 10min)
  channel: 'email' | 'phone';
  masked_recipient: string; // Ex: "u***@example.com" ou "***5678"
}>

// Vérification email — valide le code, met à jour is_email_verified sur le User
tx.security.verifyOtpEmail(code: string): Promise<{
  message: string;       // "Email verified successfully"
  email_verified: boolean; // true
  verified_at: string;   // ISO 8601
}>

// Vérification téléphone
tx.security.verifyOtpPhone(code: string): Promise<{
  message: string;       // "Phone verified successfully"
  phone_verified: boolean; // true
  verified_at: string;   // ISO 8601
  phone_number: string;  // Format international ex: "+33612345678"
}>
```


#### Sous-module Mot de passe

```typescript
// Réinitialisation (sans être connecté)
// Ne révèle jamais si le compte existe (anti-énumération)
tx.security.resetPasswordRequest(target: { email: string } | { phone_country_code: string; phone_number: string }): Promise<{
  message: string;  // "If the account exists, a reset code has been sent"
}>

// Confirmer la réinitialisation — révoque automatiquement tous les tokens de l'utilisateur
tx.security.resetPasswordConfirm(data: {
  email?: string;
  phone_country_code?: string;
  phone_number?: string;
  otp_code: string;
  new_password: string;
  confirm_password: string;   // Doit correspondre à new_password
}): Promise<{ message: string }>  // "Password reset successfully"

// Changement (connecté) — invalide les autres sessions, conserve la session courante
tx.security.changePassword(currentPassword: string, newPassword: string): Promise<{
  message: string;  // "Password changed successfully"
}>

// Utilitaires — vérification de force (sans être connecté, utile pour feedback temps réel)
tx.security.checkPasswordStrength(password: string, email?: string): Promise<{
  score: number;         // 0-4 (zxcvbn)
  strength: string;      // 'Weak' | 'Fair' | 'Strong' | 'Very Strong'
  is_valid: boolean;
  errors: string[];
  requirements: {        // Configuration backend actuelle
    min_length: number;
    require_lowercase: boolean;
    require_uppercase: boolean;
    require_numbers: boolean;
    require_special: boolean;
  };
}>
tx.security.getPasswordRequirements(): Promise<{
  requirements: Record<string, boolean | number>;
  min_length: number;
  max_length: number;
}>
```

#### Sous-module WebAuthn / Passkeys (FIDO2)

Le SDK encapsule la complexité de l'API `navigator.credentials` du navigateur et les allers-retours `begin/complete` avec le backend :

```typescript
// Enregistrer un nouveau Passkey (requiert Bearer — utilisateur connecté)
tx.security.registerWebAuthn(deviceName?: string): Promise<{
  message: string;          // "Passkey registered successfully"
  credential: {
    id: number;             // ID DB (integer, pas le credential_id FIDO2)
    device_name: string;
    created_at: string;     // ISO 8601
  }
}>
// En interne (4 étapes) :
// 1. POST /webauthn/register/begin/ → challenge + options
// 2. navigator.credentials.create(options)
// 3. POST /webauthn/register/complete/ { challenge_id, credential, device_name? } → 201

// S'authentifier avec un Passkey (sans Bearer — pas de session préalable)
// email optionnel : si absent, utilise les resident keys (username-less)
tx.security.authenticateWebAuthn(email?: string): Promise<{
  access: string;
  refresh: string;
  user: TenxyteUser;
  message: string;
  credential_used: string;
}>
// En interne (4 étapes) :
// 1. POST /webauthn/authenticate/begin/ { email? } → challenge
// 2. navigator.credentials.get(options)
// 3. POST /webauthn/authenticate/complete/ { challenge_id, credential } → JWT

// Lister les passkeys de l'utilisateur connecté
tx.security.listWebAuthnCredentials(): Promise<{
  credentials: Array<{
    id: number;                    // ID DB (integer)
    device_name: string;
    created_at: string;
    last_used_at: string | null;
    authenticator_type: string;    // 'platform' | 'cross-platform'
    is_resident_key: boolean;
  }>;
  count: number;
}>

// Supprimer un Passkey — retourne HTTP 204 No Content (pas de body)
tx.security.deleteWebAuthnCredential(credentialId: number): Promise<void>
```


---

### 6.C — Module `rbac.ts`

Le module RBAC distingue deux modes : **synchrone** (lecture locale depuis le payload JWT, sans appel réseau) et **asynchrone** (appel API pour les données fraîches ou l'administration).

```typescript
// ─── Vérifications synchrones (depuis le JWT en mémoire, aucun appel réseau) ───
tx.rbac.hasRole(roleCode: string): boolean
tx.rbac.hasAnyRole(roleCodes: string[]): boolean
tx.rbac.hasAllRoles(roleCodes: string[]): boolean
tx.rbac.hasPermission(permCode: string): boolean
tx.rbac.hasAnyPermission(permCodes: string[]): boolean
tx.rbac.hasAllPermissions(permCodes: string[]): boolean
tx.rbac.getRolesFromToken(): string[]       // Codes rôles du JWT actuel
tx.rbac.getPermissionsFromToken(): string[] // Permissions du JWT actuel

// ─── Profil RBAC de l'utilisateur courant ───
// GET /auth/users/<user_id>/roles/  (requiert permission: users.roles.view)
tx.rbac.getMyRoles(): Promise<{ user_id: string; roles: Role[] }>

// ─── CRUD Rôles (requiert permissions roles.*) ───
// GET /auth/roles/      → roles.view    POST /auth/roles/ → roles.create
tx.rbac.listRoles(params?: { search?: string; is_default?: boolean; page?: number }): Promise<PaginatedResponse<Role>>
tx.rbac.createRole(data: { code: string; name: string; description?: string; permission_codes?: string[]; is_default?: boolean }): Promise<Role>

// GET /auth/roles/<id>/  → roles.view   PUT → roles.update   DELETE → roles.delete
tx.rbac.getRole(roleId: string): Promise<Role>
tx.rbac.updateRole(roleId: string, data: Partial<{ name: string; description: string; permission_codes: string[]; is_default: boolean }>): Promise<Role>
tx.rbac.deleteRole(roleId: string): Promise<{ message: string }>  // HTTP 200

// ─── Permissions d'un rôle (requiert: roles.manage_permissions) ───
// GET /auth/roles/<id>/permissions/
tx.rbac.getRolePermissions(roleId: string): Promise<{ role_id: string; role_code: string; permissions: Permission[] }>
// POST /auth/roles/<id>/permissions/ — accepte PLUSIEURS codes à la fois
tx.rbac.addPermissionsToRole(roleId: string, permCodes: string[]): Promise<{
  message: string; added: string[]; already_assigned?: string[]; role_code: string; permissions: Permission[];
}>
// DELETE /auth/roles/<id>/permissions/
tx.rbac.removePermissionsFromRole(roleId: string, permCodes: string[]): Promise<{
  message: string; removed: string[]; not_removed?: string[]; role_code: string; permissions: Permission[];
}>

// ─── CRUD Permissions (requiert permissions permissions.*) ───
tx.rbac.listPermissions(params?: { search?: string; parent?: string; page?: number }): Promise<PaginatedResponse<Permission>>
tx.rbac.createPermission(data: { code: string; name: string; description?: string; parent_code?: string }): Promise<Permission>
tx.rbac.getPermission(permId: string): Promise<Permission>
tx.rbac.updatePermission(permId: string, data: Partial<{ name: string; description: string }>): Promise<Permission>
tx.rbac.deletePermission(permId: string): Promise<{ message: string }>  // HTTP 200

// ─── Rôles d'un utilisateur (requiert: users.roles.*) ───
// POST → users.roles.assign   DELETE ?role_code=… → users.roles.remove
tx.rbac.assignRoleToUser(userId: string, roleCode: string): Promise<{
  message: string;   // "Role assigned"
  roles: string[];   // Liste mise à jour des codes rôles de l'utilisateur
}>
tx.rbac.removeRoleFromUser(userId: string, roleCode: string): Promise<{
  message: string;   // "Role removed"
  roles: string[];   // Liste mise à jour des codes rôles de l'utilisateur
}>

// ─── Permissions directes d'un utilisateur (requiert: users.permissions.*) ───
// POST → users.permissions.assign   DELETE → users.permissions.remove
// ⚠️ Prend un TABLEAU de codes, pas un seul code
tx.rbac.assignPermissionsToUser(userId: string, permCodes: string[]): Promise<{
  message: string; added: string[]; already_assigned?: string[];
  user_id: string; direct_permissions: Permission[];
}>
tx.rbac.removePermissionsFromUser(userId: string, permCodes: string[]): Promise<{
  message: string; removed: string[]; not_removed?: string[];
  user_id: string; direct_permissions: Permission[];
}>
// GET /auth/users/<id>/permissions/ → users.permissions.view
tx.rbac.getUserDirectPermissions(userId: string): Promise<{
  user_id: string; email: string;
  direct_permissions: Permission[];
  all_permissions: string[];   // direct + hérités des rôles
}>
```

**Exemple d'utilisation dans un composant Vanilla JS :**
```typescript
// Vérification conditionnelle côté client (sync, instantané)
if (tx.rbac.hasRole('admin')) {
  document.getElementById('admin-panel').style.display = 'block';
}

// Assigner un rôle via l'API (requiert users.roles.assign)
const result = await tx.rbac.assignRoleToUser('uuid-user', 'editor');
console.log(result.roles); // ['editor', 'default_user']

// Ajouter plusieurs permissions directes d'un coup
await tx.rbac.assignPermissionsToUser('uuid-user', ['reports.view', 'logs.view']);
```


---

### 6.D — Module `user.ts`

#### Sous-module Profil (utilisateur connecté)

```typescript
// GET /auth/me/ — profil complet de l'utilisateur courant
tx.user.getProfile(): Promise<TenxyteUser>

// PATCH /auth/me/ — mise à jour partielle (les champs non fournis sont inchangés)
// ⚠️ PATCH, pas POST. Le téléphone se passe en un seul champ "phone" au format international.
tx.user.updateProfile(data: Partial<{
  first_name: string;          // max 30 caractères
  last_name: string;           // max 30 caractères
  username: string;            // max 20 caractères, alphanumérique + underscores
  phone: string;               // Format international ex: "+33612345678"
  bio: string;                 // max 500 caractères
  timezone: string;            // Ex: "Europe/Paris"
  language: string;            // Ex: "fr"
  custom_fields: Record<string, unknown>;
}>): Promise<{
  message: string;                   // "Profile updated successfully"
  updated_fields: string[];          // Liste des champs modifiés
  user: TenxyteUser;
  verification_required: {
    email_changed: boolean;          // Si true → email doit être re-vérifié
    phone_changed: boolean;          // Si true → téléphone doit être re-vérifié
  };
}>

// GET /auth/me/roles/ — rôles et permissions du compte courant (org-aware via X-Org-Slug)
tx.user.getMyRoles(): Promise<{
  roles: string[];        // Codes de rôles (ex: ["admin", "editor"])
  permissions: string[];  // Codes de permissions (ex: ["users.view", "reports.export"])
}>

// POST /auth/me/avatar/ — upload multipart (JPEG, PNG, WebP — max 5MB)
// L'image est automatiquement redimensionnée à 400x400px
tx.user.uploadAvatar(file: File): Promise<{
  message: string;       // "Avatar uploaded successfully"
  avatar_url: string;
  file_size: number;     // Octets
  dimensions: { width: 400; height: 400 };
}>

// DELETE /auth/me/ — suppression définitive du compte (RGPD)
// Bloqué si l'utilisateur est seul propriétaire d'une organisation
tx.user.deleteAccount(data: {
  confirmation: 'DELETE MY ACCOUNT';  // Texte exact obligatoire
  password: string;                    // Mot de passe courant
  reason?: string;
}): Promise<{
  message: string;
  account_deleted: boolean;
  deleted_at: string;         // ISO 8601
  data_removed: boolean;
  organizations_affected: string[];  // Slugs des orgs dont l'utilisateur était propriétaire
  recovery_possible: false;
  final_notification_sent: boolean;
}>
```

#### Sous-module Administration (Admin Users)

> Tous ces endpoints requièrent les permissions `users.*` correspondantes. Accès réservé aux administrateurs.

```typescript
// GET /auth/admin/users/ — liste paginée avec filtres (requiert: users.view)
tx.user.listUsers(params?: {
  search?: string;         // Recherche dans email, first_name, last_name
  is_active?: boolean;
  is_locked?: boolean;
  is_banned?: boolean;
  is_deleted?: boolean;
  is_email_verified?: boolean;
  is_2fa_enabled?: boolean;
  role?: string;           // Filtrer par code de rôle
  date_from?: string;      // YYYY-MM-DD
  date_to?: string;
  ordering?: string;       // email | created_at | last_login | first_name (prefix - pour DESC)
  page?: number;
  page_size?: number;      // max 100
}): Promise<PaginatedResponse<AdminUser>>

// GET /auth/admin/users/<id>/ (requiert: users.view)
tx.user.getUser(userId: string): Promise<AdminUser>

// PATCH /auth/admin/users/<id>/ (requiert: users.update)
// Permet de modifier is_active, is_staff, max_sessions, max_devices, etc.
tx.user.adminUpdateUser(userId: string, data: Partial<{
  first_name: string; last_name: string; is_active: boolean;
  is_staff: boolean; max_sessions: number; max_devices: number;
}>): Promise<AdminUser>

// DELETE /auth/admin/users/<id>/ — soft delete / anonymisation RGPD (requiert: users.delete)
tx.user.adminDeleteUser(userId: string): Promise<{
  message: string;   // "User soft-deleted successfully"
  user_id: string;
}>

// POST /auth/admin/users/<id>/ban/ (requiert: users.ban)
tx.user.banUser(userId: string, data?: { reason?: string }): Promise<{
  message: string;   // "User banned successfully"
  user: AdminUser;
}>
// POST /auth/admin/users/<id>/unban/ (requiert: users.ban)
tx.user.unbanUser(userId: string): Promise<{
  message: string;   // "User unbanned successfully"
  user: AdminUser;
}>

// POST /auth/admin/users/<id>/lock/ (requiert: users.lock)
tx.user.lockUser(userId: string, data?: {
  duration_minutes?: number;  // Défaut: 30, max: 43200 (30 jours)
  reason?: string;
}): Promise<{
  message: string;   // "User locked for X minutes"
  user: AdminUser;
}>
// POST /auth/admin/users/<id>/unlock/ (requiert: users.lock)
tx.user.unlockUser(userId: string): Promise<{
  message: string;   // "User unlocked successfully"
  user: AdminUser;
}>
```


---

### 6.E — Module `b2b.ts` (Organisations)

Fonctionnalité opt-in. Activée côté backend avec `TENXYTE_ORGANIZATIONS_ENABLED = True`. Le SDK inclut automatiquement le header `X-Org-Slug` sur toutes les requêtes lorsqu'une organisation est active via `switchOrganization`.

```typescript
// ─── Sélection du contexte org actif (injecte X-Org-Slug sur toutes les requêtes suivantes) ───
tx.b2b.switchOrganization(slug: string): void
tx.b2b.clearOrganization(): void
tx.b2b.getCurrentOrganizationSlug(): string | null

// ─── CRUD Organisations ───

// POST /auth/organizations/ — le slug est OPTIONNEL (généré automatiquement si absent)
tx.b2b.createOrganization(data: {
  name: string;
  slug?: string;          // Optionnel, généré auto si absent
  description?: string;
  parent_id?: number;     // ID de l'org parente (hiérarchie max 5 niveaux)
  metadata?: Record<string, unknown>;
  max_members?: number;   // 0 = illimité (défaut)
}): Promise<Organization>  // HTTP 201

// GET /auth/organizations/ — retourne une RÉPONSE PAGINÉE (pas un tableau direct)
tx.b2b.listMyOrganizations(params?: {
  search?: string;   // Recherche dans name et slug
  is_active?: boolean;
  parent?: string;   // slug parent (null = racines)
  ordering?: string; // name | slug | created_at (prefix - pour DESC)
  page?: number;
  page_size?: number;
}): Promise<PaginatedResponse<Organization>>

// GET /auth/organizations/<slug>/ — via X-Org-Slug header (membres seulement)
// Retourne aussi user_role, user_permissions, metadata, children
tx.b2b.getOrganization(slug: string): Promise<Organization>

// PATCH /auth/organizations/<slug>/ — requiert droits admin dans l'org
tx.b2b.updateOrganization(slug: string, data: Partial<{
  name: string;
  slug: string;          // Rename du slug (change l'URL)
  description: string;
  parent_id: number | null;
  metadata: Record<string, unknown>;
  max_members: number;
  is_active: boolean;
}>): Promise<Organization>

// DELETE /auth/organizations/<slug>/ — soft delete, requiert propriétaire
// Bloqué si l'org a des enfants
tx.b2b.deleteOrganization(slug: string): Promise<{
  message: string;  // "Organization deleted successfully"
}>

// GET /auth/organizations/<slug>/tree/ — arbre hiérarchique complet
tx.b2b.getOrganizationTree(slug: string): Promise<OrgTreeNode>

// ─── Gestion des membres ───

// GET /auth/organizations/<slug>/members/ (membres de l'org seulement)
tx.b2b.listMembers(slug: string, params?: {
  search?: string;  // email, prénom, nom
  role?: 'owner' | 'admin' | 'member';
  status?: 'active' | 'inactive' | 'pending';
  ordering?: string; // joined_at | -joined_at | user__email | -user__email
  page?: number;
  page_size?: number;
}): Promise<PaginatedResponse<OrgMembership>>

// POST — body: { user_id, role_code } — requiert permission: org.members.invite
// ⚠️ owner non autorisé comme role_code pour add_member
tx.b2b.addMember(slug: string, data: {
  user_id: number;
  role_code: string;   // 'admin' | 'member' (owner interdit ici)
}): Promise<OrgMembership>  // HTTP 201

// PATCH — requiert permission: org.members.manage
tx.b2b.updateMemberRole(slug: string, userId: number, roleCode: string): Promise<OrgMembership>

// DELETE — retourne { message } HTTP 200, requiert permission: org.members.remove
// Un membre peut aussi se retirer lui-même (auto-suppression)
tx.b2b.removeMember(slug: string, userId: number): Promise<{
  message: string;  // "Member removed successfully"
}>

// ─── Invitations ───

// POST — requiert permission: org.members.invite — retourne l'invitation créée (HTTP 201)
tx.b2b.inviteMember(slug: string, data: {
  email: string;
  role_code: string;
  expires_in_days?: number;  // 1-30, défaut: 7
}): Promise<{
  id: number;
  email: string;
  role: string;
  token: string;          // Token d'acceptation (dans le lien email)
  expires_at: string;     // ISO 8601
  invited_by: { id: number; email: string };
  organization: { id: number; name: string; slug: string };
}>

// ─── Rôles d'organisation ───

// GET /auth/organizations/roles/ — rôles système (owner, admin, member) + personnalisés
tx.b2b.listOrgRoles(): Promise<Array<{
  code: string;
  name: string;
  description: string;
  weight: number;    // Poids hiérarchique (owner=100, admin=50, member=10)
  permissions: Array<{ code: string; name: string; description: string }>;
  is_system_role: boolean;
  created_at: string;
}>>
```

**Exemple de contexte multi-tenant :**
```typescript
// L'utilisateur sélectionne "Acme Corp" dans un switcher d'organisation
tx.b2b.switchOrganization('acme-corp');

// Toutes les requêtes suivantes incluront automatiquement :
// X-Org-Slug: acme-corp
const profile = await tx.user.getProfile();
// → profile.organization_context.current_org.slug === 'acme-corp'

// Inviter un nouveau collaborateur avec expiration à 14 jours
const invitation = await tx.b2b.inviteMember('acme-corp', {
  email: 'newdev@example.com',
  role_code: 'member',
  expires_in_days: 14,
});
// → invitation.token (inclus dans le lien email)
```


---

### 6.F — Module `ai.ts` (AIRS — AI Responsibility & Security)

Tenxyte AIRS est une suite de sécurité dédiée aux **agents IA** qui interagissent avec l'API. Elle est activée par défaut côté backend (`TENXYTE_AIRS_ENABLED = True`). Le module `ai.ts` du SDK expose les primitives nécessaires pour piloter un agent de manière sécurisée et traçable.

> Voir [`docs/airs.md`](./docs/airs.md) pour la documentation backend complète des mécanismes AIRS.

#### Concept : `AgentToken`

L'`AgentToken` est un token de délégation sécurisé distinct du JWT utilisateur. L'agent emprunte les permissions d'un utilisateur **sans jamais manipuler ses credentials**. Le SDK l'injecte automatiquement comme header `Authorization: AgentBearer <token>` (**scheme `AgentBearer`**, distinct du `Bearer` JWT standard) lorsqu'il est actif.

```typescript
// ─── Cycle de vie de l'AgentToken ───

// POST /ai/tokens/ — crée un token d'agent délégué (depuis un utilisateur authentifié)
tx.ai.createAgentToken(data: {
  agent_id: string;             // Identifiant descriptif (ex: "finance-agent-v2")
  permissions?: string[];       // ⚠️ OPTIONNEL — sous-ensemble des permissions de l'utilisateur (défaut: [])
  expires_in?: number;          // Durée en secondes (défaut: TENXYTE_AIRS_DEFAULT_EXPIRY = 3600)
  organization?: string;        // Slug organisation (alternatif à header X-Org-Slug)
  budget_limit_usd?: number;    // Budget LLM max en USD (ex: 5.00). Absent = illimité
  circuit_breaker?: {
    max_requests?: number;       // Nb max requêtes dans la fenêtre (ex: 100)
    window_seconds?: number;     // Durée de la fenêtre en secondes (ex: 60)
  };
  dead_mans_switch?: {
    heartbeat_required_every?: number; // Intervalle heartbeat en secondes
  };
}): Promise<{
  id: number;
  token: string;       // Token brut "AgentBearer xxx…" — à stocker, affiché une seule fois
  agent_id: string;
  status: string;      // 'active'
  expires_at: string;  // ISO 8601
}>  // HTTP 201

// Activer le mode agent sur le client (toutes les requêtes suivantes utilisent AgentBearer)
tx.ai.setAgentToken(token: string): void
tx.ai.clearAgentToken(): void
tx.ai.isAgentMode(): boolean

// GET /ai/tokens/ — lister les tokens de l'utilisateur courant (filtrables via X-Org-Slug)
tx.ai.listAgentTokens(): Promise<AgentTokenSummary[]>

// GET /ai/tokens/{id}/ — détails d'un token spécifique
tx.ai.getAgentToken(tokenId: number): Promise<AgentTokenSummary>

// POST /ai/tokens/{id}/revoke/ — révocation permanente
tx.ai.revokeAgentToken(tokenId: number): Promise<{ status: 'revoked' }>

// POST /ai/tokens/{id}/suspend/ — suspension manuelle temporaire (raison: MANUAL)
tx.ai.suspendAgentToken(tokenId: number): Promise<{ status: 'suspended' }>

// POST /ai/tokens/revoke-all/ — coupe-circuit d'urgence (révoque TOUS les tokens actifs)
tx.ai.revokeAllAgentTokens(): Promise<{ status: 'revoked'; count: number }>
```

#### Circuit Breaker

Firewall autonome contre les comportements incontrôlés (boucles infinies, exfiltration). Si un seuil est dépassé, le token passe automatiquement en `SUSPENDED` et toutes les requêtes suivantes avec ce token retournent `403`.

```typescript
// POST /ai/tokens/{id}/heartbeat/ — utilise Authorization: AgentBearer <token>
// Sans heartbeat dans l'intervalle imparti, le backend suspend automatiquement l'agent.
tx.ai.sendHeartbeat(tokenId: number): Promise<{ status: 'ok' }>

// Si l'API retourne {suspended_reason: 'RATE_LIMIT'} ou {suspended_reason: 'ANOMALY'},
// le SDK émet l'événement 'agent:circuit_open'
```

#### Human in the Loop (HITL)

Certaines actions (configurées via `TENXYTE_AIRS_CONFIRMATION_REQUIRED`) retournent `202 Accepted` au lieu de `200` et mettent l'exécution en attente de validation humaine.

```typescript
// Le SDK détecte automatiquement les réponses 202 et émet l'événement 'agent:awaiting_approval'
tx.on('agent:awaiting_approval', (approval: {
  action_id: string;           // ID de l'AgentPendingAction
  confirmation_token: string;  // Token à transmettre à l'humain
  permission: string;          // Ex: "users.delete"
  endpoint: string;            // Endpoint qui a déclenché le HITL
  payload: unknown;            // Données soumises à validation
  expires_at: string;          // Durée de validité (défaut: 10 min)
}) => {
  notifyHuman(approval); // Slack, email, UI de validation...
});

// GET /ai/pending-actions/ — lister les actions en attente de validation
tx.ai.listPendingActions(): Promise<AgentPendingAction[]>

// POST /ai/pending-actions/confirm/ — body: { token: confirmationToken }
// ⚠️ Le token est passé dans le BODY (champ "token"), pas dans l'URL
tx.ai.confirmPendingAction(confirmationToken: string): Promise<{ status: 'confirmed' }>

// POST /ai/pending-actions/deny/ — body: { token: confirmationToken }
tx.ai.denyPendingAction(confirmationToken: string): Promise<{ status: 'denied' }>
```

#### Traçabilité Forensic — `X-Prompt-Trace-ID`

Permet de lier chaque action backend à un prompt LLM précis dans les `AuditLog`. Le SDK injecte ce header automatiquement si un `traceId` est actif.

```typescript
// Définir le trace ID courant (lié au prompt qui a initié la séquence d'actions)
tx.ai.setTraceId(traceId: string): void   // Injecte X-Prompt-Trace-ID sur toutes les requêtes
tx.ai.clearTraceId(): void

// Exemple d'usage dans un agent
tx.ai.setTraceId(crypto.randomUUID());
await tx.user.getProfile();    // AuditLog liera cette action au traceId
await tx.rbac.listRoles();     // idem
tx.ai.clearTraceId();
```

#### Budget Tracking

> ⚠️ **Tenxyte ne calcule pas le coût LLM.** Il est agnostique au modèle. C'est **votre code** qui doit convertir les tokens en USD selon la grille tarifaire du provider (Anthropic, Google, OpenAI…), puis reporter ce montant à Tenxyte. Tenxyte se charge uniquement de l'accumulation et de la suspension automatique en cas de dépassement.

```typescript
// Table de tarifs à maintenir côté intégrateur (exemple)
const MODEL_PRICING: Record<string, { input: number; output: number }> = {
  'claude-sonnet-4-5': { input: 3.00,  output: 15.00 }, // $ / million tokens
  'gemini-1.5-pro':    { input: 3.50,  output: 10.50 },
  'gpt-4o':            { input: 5.00,  output: 15.00 },
};

function calculateCostUsd(model: string, promptTokens: number, completionTokens: number): number {
  const p = MODEL_PRICING[model] ?? { input: 0, output: 0 };
  return (promptTokens / 1_000_000) * p.input + (completionTokens / 1_000_000) * p.output;
}

// POST /ai/tokens/{id}/report-usage/ — Authorization: AgentBearer <token>
// En cas de budget dépassé → HTTP 403 { error: "Budget exceeded", status: "suspended" }
// Le token est automatiquement suspendu côté backend.
const cost = calculateCostUsd('claude-sonnet-4-5', 1200, 450); // ~$0.010

tx.ai.reportUsage(tokenId: number, usage: {
  cost_usd: number;           // Montant calculé par votre code
  prompt_tokens: number;      // Pour audit/log uniquement
  completion_tokens: number;  // Pour audit/log uniquement
}): Promise<
  | { status: 'ok' }
  | { error: 'Budget exceeded'; status: 'suspended' }  // HTTP 403 si budget dépassé
>

// En cas de dépassement, Tenxyte suspend automatiquement le token :
// → token.status            = 'SUSPENDED'
// → token.suspended_reason  = 'BUDGET_EXCEEDED'
// → toutes les requêtes suivantes avec ce token → 403
```

#### Résumé des types AIRS

```typescript
interface AgentTokenSummary {
  id: number;
  agent_id: string;
  status: 'ACTIVE' | 'SUSPENDED' | 'REVOKED' | 'EXPIRED';
  expires_at: string;
  created_at: string;
  organization: string | null;   // Slug de l'org, ou null
  current_request_count: number;
}

interface AgentPendingAction {
  id: number;
  agent_id: string;
  permission: string;            // Ex: "users.delete"
  endpoint: string;
  payload: unknown;
  confirmation_token: string;
  expires_at: string;
  created_at: string;
}
```


---

## 7. Système d'Événements

`TenxyteClient` étend un `EventEmitter` léger. Les événements permettent aux couches supérieures (React Provider, Vue Plugin, Vanilla JS) de réagir aux changements de session sans coupler leur logique au SDK.

```typescript
// Abonnement — tx.on() retourne une fonction de désabonnement
const unsub = tx.on('session:created', (user: TenxyteUser) => {
  // Appelé après tout login réussi (email, phone, social, magic link, WebAuthn)
  renderApp(user);
});
unsub(); // Désabonne

tx.on('session:expired', () => {
  // Le refresh a échoué (401 sur /auth/refresh/) — session irrécupérable
  window.location.href = '/login';
});

tx.on('session:logged_out', () => {
  // logout() ou logoutAll() appelé explicitement — distinct de session:expired
  window.location.href = '/login';
});

tx.on('token:refreshed', (tokens: { access: string; refresh: string }) => {
  // L'intercepteur a rafraîchi le JWT avec succès (transparent pour l'utilisateur)
  externalStore.setTokens(tokens);
});

tx.on('session:restored', (user: TenxyteUser) => {
  // Appelé au démarrage si un refresh_token valide a été trouvé dans le storage
  console.log(`Session restaurée pour ${user.email}`);
});

tx.on('auth:error', (error: TenxyteAuthError) => {
  // Erreur d'authentification non-récupérable (token blacklisté, compte suspendu)
  errorReporter.capture(error);
});

tx.on('org:switched', (slug: string) => {
  // tx.b2b.switchOrganization() appelé — X-Org-Slug injecté sur toutes les requêtes
  router.replace({ query: { org: slug } });
});

tx.on('org:cleared', () => {
  // tx.b2b.clearOrganization() appelé — X-Org-Slug retiré
  router.replace({ query: {} });
});

tx.on('agent:awaiting_approval', (approval: {
  action_id: string;           // ID de l'AgentPendingAction
  confirmation_token: string;  // Token à transmettre à l'humain
  permission: string;          // Ex: "users.delete"
  endpoint: string;            // Endpoint qui a déclenché le HITL
  payload: unknown;
  expires_at: string;
}) => {
  // Réponse 202 reçue — action en attente de validation humaine (HITL)
  notifyHuman(approval);
});

tx.on('agent:circuit_open', (info: {
  agent_id: string;
  suspended_reason: 'RATE_LIMIT' | 'ANOMALY' | 'BUDGET_EXCEEDED' | 'MANUAL';
}) => {
  // Le backend a suspendu l'agent (→ 403 sur les requêtes suivantes avec ce token)
  // ⚠️ PAS un 503 — le token passe à status SUSPENDED, les requêtes retournent 403
  logger.warn(`Agent ${info.agent_id} suspendu : ${info.suspended_reason}`);
});

tx.on('agent:budget_exceeded', (info: {
  agent_id: string;
  token_id: number;
  cost_usd_used: number;
  budget_limit_usd: number;
}) => {
  // reportUsage() a reçu un 403 — budget LLM dépassé, token automatiquement suspendu
});

tx.on('agent:token_revoked', (tokenId: number) => {
  // revokeAgentToken() ou revokeAllAgentTokens() ont été appelés
  // Utile pour nettoyer le store React/Vue
});

// Abonnement unique (se désabonne automatiquement après le premier déclenchement)
tx.once('session:restored', (user) => renderApp(user));

// Désabonnement manuel
const handler = (user: TenxyteUser) => { /* ... */ };
tx.on('session:restored', handler);
tx.off('session:restored', handler);
```

### Tableau des événements

| Événement | Payload | Déclencheur |
|---|---|---|
| `session:created` | `TenxyteUser` | Login réussi (toute méthode) |
| `session:expired` | — | Refresh échoué (401 sur `/auth/refresh/`) |
| `session:logged_out` | — | `logout()` ou `logoutAll()` explicite |
| `token:refreshed` | `{ access, refresh }` | Intercepteur a rafraîchi le JWT avec succès |
| `session:restored` | `TenxyteUser` | Session chargée depuis le storage au démarrage |
| `auth:error` | `TenxyteAuthError` | Erreur d'auth non-récupérable |
| `org:switched` | `string` (slug) | `tx.b2b.switchOrganization()` |
| `org:cleared` | — | `tx.b2b.clearOrganization()` |
| `agent:awaiting_approval` | `ApprovalRequest` | Réponse `202` reçue — action en attente HITL |
| `agent:circuit_open` | `{ agent_id, suspended_reason }` | Token suspendu → `403` (pas `503`) |
| `agent:budget_exceeded` | `{ agent_id, token_id, cost_usd_used, budget_limit_usd }` | `reportUsage()` retourne 403 |
| `agent:token_revoked` | `number` (tokenId) | `revokeAgentToken()` ou `revokeAllAgentTokens()` |


---

## 8. Helper `DeviceInfo`

Le champ `device_info` est utilisé par le backend Tenxyte pour la gestion des sessions et des limites par appareil (voir `docs/security.md#session--device-limits`). Le SDK fournit un utilitaire pour construire cette chaîne automatiquement depuis le navigateur.

> **Fallback automatique :** Si `device_info` n'est pas fourni, le backend le reconstruit depuis le header `User-Agent` HTTP via `build_device_info_from_user_agent()`. Il n'est donc **pas obligatoire** dans les appels navigateur standard — mais le fournir manuellement garantit une identification précise.

```typescript
import { buildDeviceInfo } from '@tenxyte/js-core/utils';

// Génère automatiquement depuis navigator.userAgent + screen info
const deviceInfo = buildDeviceInfo();
// → "v=1|os=windows;osv=11|device=desktop|arch=x64|app=tenxyte;appv=1.0.0|runtime=chrome;rtv=122|tz=Europe/Paris"

// Personnalisé (utile en Node.js / SSR)
const deviceInfo = buildDeviceInfo({
  os: 'linux',
  osVersion: 'ubuntu22.04',   // → osv=ubuntu22.04
  device: 'server',
  arch: 'x64',
  app: 'my-app',
  appVersion: '2.1.0',        // → appv=2.1.0
  runtime: 'node',
  runtimeVersion: process.version,   // → rtv=v20.11.0
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
});

// Passer au login
await tx.auth.loginWithEmail(email, password, { deviceInfo });
```

**Format de la chaîne (v1) :**

> Séparateurs : `|` entre catégories, `;` entre sous-clés d'une même catégorie, `=` entre clé et valeur.
> Exemple complet : `v=1|os=windows;osv=11|device=desktop|arch=x64|app=tenxyte;appv=1.0.0|runtime=chrome;rtv=122|tz=Europe/Paris`

| Clé | Sous-clés | Description | Valeurs valides |
|---|---|---|---|
| `v` | — | Version du format (obligatoire) | `1` |
| `os` | `osv` | Système d'exploitation + version | `windows`, `android`, `ios`, `macos`, `linux`, `chromeos` |
| `device` | — | Type d'appareil | `desktop`, `mobile`, `tablet`, `server`, `api-client`, `bot` |
| `arch` | — | Architecture CPU | `x64`, `arm64`, `arm`, `x86` |
| `app` | `appv` | Nom + version de l'application cliente | Ex: `app=tenxyte;appv=1.0.0` |
| `runtime` | `rtv` | Navigateur ou runtime + version | `chrome`, `firefox`, `safari`, `edge`, `opera`, `node`, `postman`, `curl`, `insomnia`, `httpie` |
| `tz` | — | Timezone IANA | Ex: `Europe/Paris` |

> **Règle de comparaison (nouveaux appareils) :** Le backend compare `os`, `device`, `arch`, `app`, `runtime` pour décider si c'est un nouvel appareil (alerte email). Les versions (`osv`, `appv`, `rtv`) et `tz` sont **ignorées** lors de cette comparaison.



---

## 9. Interfaces TypeScript (`types/`)

Les types sont générés depuis l'OpenAPI schema via `openapi-typescript`, puis manuellement enrichis. Voici les interfaces centrales à connaître :

```typescript
// --- TenxyteUser (docs/schemas.md#User) ---
interface TenxyteUser {
  id: string;                    // UUID
  email: string | null;
  phone_country_code: string | null;
  phone_number: string | null;
  first_name: string;
  last_name: string;
  is_email_verified: boolean;
  is_phone_verified: boolean;
  is_2fa_enabled: boolean;
  roles: string[];               // Codes des rôles ex: ['admin', 'viewer']
  permissions: string[];         // Codes des permissions (directes + via rôles)
  created_at: string;            // ISO 8601
  last_login: string | null;
}

// --- TokenPair (docs/schemas.md#TokenPair) ---
interface TokenPair {
  access_token: string;          // JWT Bearer
  refresh_token: string;
  token_type: 'Bearer';
  expires_in: number;            // Durée de vie de l'access_token en secondes
  device_summary: string | null; // Ex: "desktop — windows 11 — chrome 122" (null si device_info absent)
}

// --- TenxyteError (docs/schemas.md#ErrorResponse) ---
interface TenxyteError {
  error: string;                 // Message humain
  code: TenxyteErrorCode;        // Identifiant machine
  details?: Record<string, string[]> | string; // Erreurs par champ ou message libre
  retry_after?: number;          // Présent sur 429 et 423
}

// Codes d'erreur machine connus (non-exhaustif)
type TenxyteErrorCode =
  // Auth
  | 'LOGIN_FAILED' | 'INVALID_CREDENTIALS'
  | 'ACCOUNT_LOCKED' | 'ACCOUNT_BANNED'
  | '2FA_REQUIRED' | 'ADMIN_2FA_SETUP_REQUIRED'
  | 'TOKEN_EXPIRED' | 'TOKEN_BLACKLISTED' | 'REFRESH_FAILED'
  | 'PERMISSION_DENIED'
  | 'SESSION_LIMIT_EXCEEDED' | 'DEVICE_LIMIT_EXCEEDED'
  | 'RATE_LIMITED'
  | 'INVALID_OTP' | 'OTP_EXPIRED'
  | 'INVALID_PROVIDER' | 'SOCIAL_AUTH_FAILED'
  | 'VALIDATION_URL_REQUIRED' | 'INVALID_TOKEN'
  // User / Account
  | 'CONFIRMATION_REQUIRED' | 'PASSWORD_REQUIRED' | 'INVALID_PASSWORD'
  | 'INVALID_DEVICE_INFO'
  // B2B / Organizations
  | 'ORG_NOT_FOUND' | 'NOT_ORG_MEMBER' | 'NOT_OWNER'
  | 'ALREADY_MEMBER' | 'MEMBER_LIMIT_EXCEEDED'
  | 'HAS_CHILDREN' | 'CIRCULAR_HIERARCHY' | 'LAST_OWNER_REQUIRED'
  | 'INVITATION_EXISTS' | 'INVALID_ROLE'
  // AIRS — Agent errors
  | 'AGENT_NOT_FOUND' | 'AGENT_SUSPENDED' | 'AGENT_REVOKED' | 'AGENT_EXPIRED'
  | 'BUDGET_EXCEEDED' | 'RATE_LIMIT_EXCEEDED' | 'HEARTBEAT_MISSING' | 'AIRS_DISABLED';

// --- Organization (docs/schemas.md#Organization) ---
interface Organization {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  metadata: Record<string, unknown> | null;
  is_active: boolean;
  max_members: number;           // 0 = illimité
  member_count: number;
  created_at: string;
  updated_at: string;
  // ⚠️ parent est un objet, pas un simple entier
  parent: { id: number; name: string; slug: string } | null;
  children: Array<{ id: number; name: string; slug: string }>;
  user_role: string | null;         // Rôle du user courant dans cette org
  user_permissions: string[];       // Permissions effectives dans cette org
}

// --- PaginatedResponse ---
interface PaginatedResponse<T> {
  count: number;
  page: number;
  page_size: number;
  total_pages: number;
  next: string | null;
  previous: string | null;
  results: T[];
}
```

---

## 10. Roadmap du Dépôt

### Phase 1 : Fondation Architecturale & Moteur HTTP (Semaines 1-2)
- Initialisation du projet (TypeScript, Tsup pour le build ESM/CommonJS, Vitest pour les tests).
- Génération des interfaces TS (User, TokenPair) depuis l'OpenAPI schema existant via **`openapi-typescript`**.
- Architecture du client HTTP (wrapper Fetch natif avec le système d'intercepteurs pour gèrer la rotation JWT).
- **Intercepteurs Contextuels :** Implémentation du système injectant `X-Org-Slug` et `X-Prompt-Trace-ID` sur les requêtes sortantes.
- Développement des trois stratégies de stockage (`storage/`).
- Implémentation du helper `buildDeviceInfo()`.

### Phase 2 : Modules d'Authentification Core & RBAC (Semaines 2-3)
- Développement complet du module `auth.ts` (Login email/phone, Register, Logout, Refresh, Magic Link, Social).
- **Complexité critique à gérer :** File d'attente (Queue) des requêtes simultanées. Si 4 appels réseau partent en même temps pendant que le token est expiré, le SDK doit bloquer les 3 derniers appels, effectuer *un seul* refresh, puis libérer les 4 appels avec le nouveau token commun.
- Implémentation du système d'événements (`EventEmitter`).
- Modules `user.ts` (profil) et **`user.admin` (endpoints back-office : ban, lock, list avec pagination)**.
- Module `rbac.ts` pour la gestion des rôles.

### Phase 3 : Sécurité Avancée, B2B et AIRS (Semaines 4-5)
- Module `security.ts` complet : 2FA/TOTP, OTP, Password management.
- Intégration WebAuthn : encapsulation de `navigator.credentials.create` / `get` pour simplifier les Passkeys.
- Module `b2b.ts` (Organisations, invitations, gestion des membres).
- Module `ai.ts` (AIRS) : `AgentToken`, Circuit Breaker + heartbeat, HITL (`202` → event), Budget tracking.

### Phase 4 : Documentation & Tests (Semaine 6)
- Rédaction d'un `README.md` exhaustif avec exemples de code.
- TSDoc sur toutes les méthodes publiques pour l'autocomplétion IntelliSense dans VSCode.
- Mise en place de GitHub Actions (Lint, Tests, Publish sur npm.js).
- Dossier `examples/vanilla-ts/` démontrant l'usage sans framework.

---

### Conclusion

Le SDK `@tenxyte/js-core` est la véritable "colonne vertébrale" de l'écosystème front-end de Tenxyte. En déplaçant la charge cognitive — gestion sécurisée de JWT, refresh token cyclique, parsing d'erreurs, injection de headers, DeviceInfo, événements de session, RBAC synchrone — dans cette librairie robuste, les futurs composants (comme `@tenxyte/html-components`) n'auront plus qu'à se soucier de l'UI. Le respect de ce plan garantit une Developer Experience (DX) optimale et alignée aux standards de production de l'API backend.
